module.exports = {
    database: {
        url: "mongodb+srv://adminUser:Irelandtoamerica@cluster0.7auld.mongodb.net/PhoneStore(RESTful)?retryWrites=true&w=majority"
        // url: "mongodb://adminUser:Irelandtoamerica@localhost:27017/test"

    }
}