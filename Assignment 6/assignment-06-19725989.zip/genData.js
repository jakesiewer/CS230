        // CSO Baby Names of Ireland (https://www.cso.ie/en/interactivezone/visualisationtools/babynamesofireland/)
        var bNames = 
        `Conor
        Daniel
        Adam
        Liam
        Tadhg
        Luke
        Charlie
        Darragh
        Harry
        Oisín
        Michael
        Alex
        Fionn
        Cillian
        Thomas
        Jamie
        Patrick
        Rían
        Finn
        Seán
        Oliver
        Ryan
        Dylan
        Matthew
        Ben
        Bobby
        John
        Leo
        Cian
        Aaron
        Max
        Ethan
        Alexander
        Jake
        Tom
        Jacob
        Alfie
        David
        Senan
        Oscar
        Sam
        Callum
        Mason
        Ollie
        Aidan
        Theo
        William
        Leon
        Joseph
        Tommy
        Joshua
        Lucas
        Evan
        Donnacha
        Logan
        Luca
        Samuel
        Nathan
        Cathal
        Shay
        Archie
        Jayden
        George
        Kai
        Andrew
        Louis
        Danny
        Rory
        Theodore
        Freddie
        Eoin
        Benjamin
        Billy
        Hugo
        Muhammad
        Ronan
        Robert
        Arthur
        Kayden
        Christopher
        Henry
        Frankie
        Dara
        Kyle
        Ruairí
        Edward
        Isaac
        Martin
        Odhran
        Eli
        Mark
        Anthony
        Josh
        Zach
        Joey
        Odhrán
        Kevin
        Tadgh
        Jaxon
        Scott
        Sonny
        Tomás
        Cormac
        Peter
        Sean
        Eoghan
        Brody
        Shane
        Killian
        Tiernan
        Sebastian
        Carter
        Hunter
        Daithí
        Ciarán
        Rian
        Teddy
        Tyler
        Arlo
        Gabriel
        Jackson
        Eric
        Cody
        Éanna
        Lorcan
        Alan
        Filip
        Joe
        Elliot
        Rhys
        Oran
        Calvin
        Nicholas
        Blake
        Harrison
        Paddy
        Brian
        Caleb
        Louie
        Harvey
        Cole
        Páidí
        Séan
        Reuben
        Denis
        Ted
        Iarlaith
        Jason
        Donagh
        Elliott
        Riley
        Iarla
        Lewis
        Jordan
        Antoni
        Elijah
        Cooper
        Paul
        Hugh
        Rowan
        Daire
        Gerard
        Keelan
        Kian
        Jonathan
        Jude
        Lukas
        Jakub
        Zack
        Johnny
        Stephen
        Niall
        Charles
        Felix
        Levi
        Bradley
        Fiachra
        Conn
        Zac
        Cameron
        Kacper
        Milo
        Dáire
        Dáithí
        Robbie
        Olly
        Caolán
        Owen
        Corey
        Oskar
        Conall
        Jan
        Jonah
        Robin
        Mateo
        Adrian
        Shea
        Toby
        Diarmuid
        Myles
        Leonardo
        Ned
        Grayson
        Séamus
        Dean
        Jesse
        Zachary
        Dominic
        Pádraig
        Ruadhán
        Colm
        Richard
        Philip
        Frank
        Will
        Dan
        Christian
        Keegan
        Matteo
        Aodhán
        Gearóid
        Reece
        Marcel
        Franciszek
        Parker
        Ian
        Noel
        Conan
        Rocco
        Aleksander
        Darius
        Casey
        Jaxson
        Kieran
        Timothy
        Naoise
        Peadar
        Matei
        Kaiden
        Fíonn
        Ross
        Colin
        Lennon
        Emmet
        Luka
        Ali
        Mikey
        Maximilian
        Aiden
        Damian
        Art
        Harley
        Finley
        Daragh
        Connor
        Dominik
        Austin
        Caelan
        Jimmy
        Flynn
        Hudson
        Cían
        Mícheál
        Tiarnán
        Calum
        Lee
        Tristan
        Marcus
        Donal
        Donncha
        Bernard
        Lochlann
        Maksymilian
        Stefan
        Nathaniel
        Julian
        Cayden
        Beau
        Elias
        Lachlan
        Ezra
        Gavin
        Seamus
        Brendan
        Szymon
        Vincent
        Francis
        Ruben
        Ibrahim
        Tobias
        Faolán
        Brandon
        Darren
        Simon
        Jay
        Caolan
        Hayden
        Victor
        Mikolaj
        Alexandru
        Mohamed
        Andrei
        Andy
        Caiden
        Jace
        Cuán
        Eóin
        Micheál
        Oisin
        Justin
        Brooklyn
        Kealan
        Frederick
        Seth
        Dawson
        Lochlan
        Odin
        Beauden
        Barry
        Maxim
        Jim
        Roman
        Ahmad
        Luan
        Bruno
        Ralph
        Tymon
        Jasper
        Enzo
        Miles
        Rua
        Ewan
        Ivan
        Troy
        Pearse
        Ferdia
        Jeremiah
        Wiktor
        Diego
        Artur
        Olaf
        Leighton
        Lorenzo
        Culann
        Jayce
        Otis
        Eóghan
        Sé
        Dawid
        Morgan
        Mohammad
        Tony
        Nikodem
        Mohammed
        Nicolas
        Cuan
        Malachy
        Caden
        Rafael
        Ellis
        Alec
        Barra
        Paudie
        Lenny
        Reggie
        Shéa
        Tomas
        Dillon
        Declan
        Kane
        Ashton
        Donnchadh
        Bill
        Albert
        Fabian
        Cristian
        Ayaan
        Quinn
        Brayden
        Kyron
        Tommie
        Tymoteusz
        Ayan
        Brogan
        Carson
        Mylo
        Omar
        Spencer
        Zain
        Nico
        Zion
        Ignacy
        Ruadh
        Gael
        Cúan
        Dónal
        Seán Óg
        Séimí
        Padraig
        Patryk
        Mateusz
        Gary
        Euan
        Olan
        Marco
        Ultan
        Natan
        Oliwier
        Chris
        Piotr
        Tomasz
        Benas
        Eryk
        Domhnall
        Thady
        Axel
        Emanuel
        Rohan
        Asher
        Fiach
        Ailbe
        Bodhi
        Brodie
        Zayn
        Bogdan
        Hamish
        Matias
        Remy
        River
        Albie
        Caoimhín
        Kyren
        Lorcán
        Ódhran
        Micheal
        Tiarnan
        Michal
        Davin
        Jeremy
        Kajus
        Hubert
        Hamza
        Pedro
        Leonard
        Ajay
        Matt
        Maximus
        Raphael
        Syed
        Eduard
        Milan
        Rio
        Wyatt
        Emmett
        Freddy
        Tajus
        Yusuf
        Jenson
        Kody
        Teodor
        Óisín
        Senán
        Steven
        Damien
        Eamon
        Neil
        Eamonn
        Joel
        Roan
        Ahmed
        Laurence
        Warren
        Erik
        Karol
        Pauric
        Emil
        Mike
        Miguel
        Rayan
        Abdul
        Dennis
        Jonas
        Terence
        Cain
        Kristian
        Kyran
        Marko
        Eden
        Kaylum
        Lochlainn
        Lucca
        Braxton
        Arijus
        Karson
        Rayyan
        Avery
        Kayson
        Croí
        Fionán
        Pádraic
        Séadna
        Ace
        Ciaran
        Ruairi
        Marc
        Riain
        Emmanuel
        Travis
        Raymond
        Bartosz
        Bailey
        Glenn
        Jerry
        Aron
        Gregory
        Turlough
        Abel
        Eddie
        Krzysztof
        Xavier
        Wojciech
        Markus
        Regan
        Ricky
        Amir
        Kylan
        Luis
        Mustafa
        Nataniel
        Viktor
        Malik
        Rion
        Walter
        Zane
        Aronas
        Alessio
        Darach
        Heath
        Koby
        Mannix
        Markas
        Phoenix
        Rares
        Cruz
        Iosua
        John-Paul
        Marley
        Seamie
        Vlad
        Jordi
        Koa
        Olivers
        Lugh
        Mj
        Fionnán
        Maitiú
        Ólan
        Ultán
        Seanán
        Oakley
        Daithi
        Karl
        Bryan
        Pierce
        Kamil
        Olivier
        Mathew
        Conal
        Zak
        Aran
        Nikita
        Preston
        Roy
        Igor
        Devin
        Mario
        Abdullah
        Andre
        Feidhlim
        Maksim
        Nojus
        Devon
        Gerry
        Maurice
        Stanislaw
        Byron
        Cal
        Dominick
        Dominykas
        Aryan
        Callan
        Christy
        Con
        Cullen
        Danielius
        Fred
        Hassan
        Kaleb
        Kalvin
        Anas
        Beniamin
        Ephraim
        Ruan
        Timmy
        Alistair
        Erick
        Abraham
        Bobbie
        Bruce
        Coby
        Davi
        Dorian
        Evanas
        Haris
        Hughie
        Macdara
        Miley
        Moise
        Nikolas
        Richie
        Benny
        Constantin
        Dalton
        Herkus
        Iarfhlaith
        Kenny
        Kobi
        Kylian
        Musa
        Noa
        Timas
        Tudor
        Rico
        Karter
        Ari
        Henryk
        Zayan
        Kaiser
        Kit
        Páraic
        Rónán
        Jax
        Craig
        Shaun
        Matas
        Clayton
        Kenneth
        Tim
        Saul
        Daryl
        Gareth
        Maxwell
        Seanan
        Cailum
        Larry
        Emilis
        Jody
        Keenan
        Aedan
        Allan
        Fynn
        Jaiden
        Raul
        Alfred
        Angelo
        Cahir
        Chulainn
        Culainn
        Giovanni
        Guy
        Jia
        Kajetan
        Lincoln
        Milosz
        Orin
        Pavel
        Quin
        Zayd
        Barney
        Borys
        Dexter
        Ezekiel
        Franklin
        Aarav
        Aodh
        Kasper
        Ksawery
        Layton
        Rodrigo
        Rogan
        Sonnie
        Tommy Lee
        Tommy-Lee
        Youssef
        Zaid
        Zakaria
        Azlan
        Caolin
        Dario
        Eyad
        Gabriels
        Gene
        Idris
        Ishaan
        Jj
        Jonathon
        Kevins
        Lughaidh
        Mathias
        Mohamad
        Santiago
        Setanta
        Timur
        Valentin
        Vladimir
        Yahya
        Yaseen
        Coen
        Denver
        Mieszko
        Vihaan
        Alby
        Colby
        Damir
        Thiago
        Tyson
        Yousuf
        Clark
        Donnie
        Cobi
        Jakov
        Kiaan
        Advik
        Aodán
        Azaan
        Bernardo
        Bradán
        Cadán
        Clay
        Óran
        Rónan
        Ruán
        Seánie
        Sunny
        Théo
        Ruaidhrí
        Lawson
        Kaison
        Laoch
        Yazan
        Orán
        Pádhraic
        T J
        Teidí
        Cúán
        Denny
        Benett
        Aris
        Boston
        Brín
        Glen
        Enda
        Aodhan
        Fintan
        Padraic
        Desmond
        Finlay
        Rossa
        Antonio
        Zachariah
        Diarmaid
        Kilian
        Dion
        Finian
        Kornel
        Marcos
        Trevor
        Terry
        Carlos
        Damon
        Jared
        Kaden
        Malachi
        Russell
        Sami
        Solomon
        Wesley
        Aleks
        Anton
        Dwayne
        Enrico
        Erikas
        Felim
        Gabrielius
        Jarlath
        Jerome
        Kallum
        Lennox
        Roberto
        Rui
        Samson
        Taha
        Cohen
        Don
        Geordan
        Isaiah
        Johan
        Jon
        Kade
        Keagan
        Kurt
        Manus
        Micah
        Remi
        Roger
        Theodor
        Tiago
        Torin
        Xander
        Alejandro
        Aleksandr
        Amos
        Blaise
        Caine
        Dante
        Elvis
        Eunan
        Harris
        Jakob
        Jamal
        Joris
        Adomas
        Aj
        Arjun
        Artem
        Asa
        Ashley
        Bowie
        Casper
        Colton
        Cuinn
        Denas
        Domas
        Douglas
        Fletcher
        Franek
        Jensen
        Korey
        Lucian
        Malcolm
        Matej
        Neitas
        Nolan
        Rex
        Rylan
        Rylee
        Safwan
        Sebastien
        Steve
        Teo
        Tobiasz
        Umar
        Antony
        Arnold
        Augustas
        Ayman
        Cezary
        Connie
        Darby
        Dhruv
        Dominiks
        Donald
        Finbar
        Isac
        Israel
        Jozef
        Kaelan
        Kenzo
        Kodi
        Lleyton
        Marius
        Matheus
        Mihai
        Miracle
        Quentin
        Reginald
        Reid
        Roland
        Sameer
        Sidney
        T.J.
            Timotei
        Usman
        Yassin
        Ammar
        Archer
        Axl
        Breffni
        Arham
        Kobe
        Rob
        Sawyer
        Affan
        Jad
        Judah
        Kason
        Ziggy
        Bryson
        Cade
        Cillían
        Conán
        Éamonn
        Reyansh
        Rí
        Ríain
        Rohaan
        Younis
        Llewyn
        Malek
        Séadhna
        Seb
        Reign
        Reon
        Knox
        Vincenzo
        Rián
        Magnus
        Ríoghan
        Ronán
        Klayton
        Mikaeel
        Samy
        C J
        Alonzo
        Cónán
        Daimhín
        Evaan
        Feidhelm
        Féilim
        Beckett
        Bríon
        Afonso
        Forrest
        Eliezer
        Dómhnall
        Jem
        Casian`.split(/\n/);

        // CSO Baby Names of Ireland (https://www.cso.ie/en/interactivezone/visualisationtools/babynamesofireland/)
        var gNames = 
        `Emily
        Grace
        Fiadh
        Sophie
        Hannah
        Amelia
        Ava
        Ellie
        Ella
        Mia
        Lucy
        Emma
        Lily
        Olivia
        Chloe
        Aoife
        Caoimhe
        Molly
        Anna
        Sophia
        Holly
        Freya
        Saoirse
        Kate
        Sadie
        Robyn
        Katie
        Ruby
        Evie
        Éabha
        Cara
        Sarah
        Isabelle
        Isla
        Alice
        Leah
        Sadhbh
        Eva
        Erin
        Róisín
        Zoe
        Sofia
        Zara
        Willow
        Charlotte
        Lauren
        Jessica
        Faye
        Ciara
        Clodagh
        Millie
        Isabella
        Eve
        Niamh
        Maya
        Layla
        Ada
        Rosie
        Abigail
        Julia
        Clara
        Maisie
        Amy
        Maria
        Aria
        Alannah
        Annie
        Harper
        Aoibhín
        Emilia
        Amber
        Bonnie
        Mila
        Heidi
        Ailbhe
        Bella
        Abbie
        Ivy
        Aoibheann
        Rose
        Sienna
        Elizabeth
        Georgia
        Rebecca
        Laura
        Ellen
        Méabh
        Alexandra
        Kayla
        Isabel
        Hollie
        Mary
        Áine
        Aisling
        Hazel
        Rachel
        Tara
        Evelyn
        Megan
        Doireann
        Daisy
        Hanna
        Lara
        Mollie
        Maeve
        Sara
        Lilly
        Luna
        Victoria
        Hailey
        Hayley
        Poppy
        Fíadh
        Zoey
        Penny
        Pippa
        Ayla
        Ayda
        Nina
        Annabelle
        Penelope
        Indie
        Alanna
        Maja
        Paige
        Lola
        Naoise
        Cora
        Matilda
        Elsie
        Laoise
        Nora
        Lexi
        Eleanor
        Hallie
        Lottie
        Aoibhe
        Ruth
        Lena
        Phoebe
        Nicole
        Eimear
        Jane
        Síofra
        Siún
        Brooke
        Mya
        Gracie
        Summer
        Tess
        Eliza
        Caitlin
        Alison
        Darcie
        Esmé
        Madison
        Lucia
        Maggie
        Callie
        Muireann
        Beth
        Kathleen
        Tessa
        Croía
        Aoibhinn
        Jasmine
        Isobel
        Juliette
        Savannah
        Riley
        Caragh
        Kara
        Stella
        Liliana
        Ariana
        Florence
        Darcy
        Esme
        Ríona
        Zuzanna
        Bridget
        Nadia
        Gabriela
        Aurora
        Éala
        Róise
        Kayleigh
        Cassie
        Elena
        Anastasia
        Nevaeh
        Alicia
        Aaliyah
        Allie
        Scarlett
        Naomi
        Margaret
        Maia
        Elise
        Farrah
        Katelyn
        Shauna
        Orla
        Aimee
        Vanessa
        Alana
        Natalia
        Rhea
        Skye
        April
        Alicja
        Nancy
        Mae
        Arabella
        Keeva
        Aoibh
        Robin
        Pearl
        Eden
        Remi
        Taylor
        Alisha
        Catherine
        Casey
        Nessa
        Lacey
        Thea
        Iris
        Maddison
        Tilly
        Bláithín
        Lydia
        Zofia
        Nell
        Amelie
        Teagan
        Alyssa
        Helena
        Juliet
        Lia
        Beatrice
        Cadhla
        Fia
        Edie
        Harley
        Violet
        Oliwia
        Jade
        Melissa
        Sally
        Elle
        Leila
        Aisha
        Gabriella
        Addison
        Maryam
        Elodie
        Frankie
        Gráinne
        Alex
        Diana
        Daria
        Kyra
        Ana
        Lana
        Lillie
        Norah
        Belle
        Quinn
        Éadaoin
        Orlaith
        Erica
        Faith
        Libby
        Lillian
        Lyla
        Harriet
        Arya
        Cali
        Ellie-Mae
        Nova
        Skylar
        Aoibhínn
        Abby
        Jennifer
        Michaela
        Ali
        Claire
        Yasmin
        Dearbhla
        Lucie
        Piper
        Bláthnaid
        Clíodhna
        Úna
        Eabha
        Sorcha
        Andrea
        Kelsey
        Rosa
        Francesca
        Aliyah
        Klara
        Mabel
        Lila
        Bailey
        Emmie
        Kaia
        Nela
        Skyler
        Roisín
        Sinéad
        Danielle
        Aleksandra
        Amanda
        Bronagh
        Darcey
        Ema
        Hope
        Antonia
        Saibh
        Juno
        Margot
        Síomha
        Moya
        Stephanie
        Christina
        Martha
        Carly
        Marie
        Maebh
        Ria
        Alisa
        Mariam
        Miriam
        Evelina
        Elisa
        Connie
        Billie
        Liadh
        Pola
        May
        Avery
        Priya
        Ariella
        Myla
        Louise
        Joanna
        Ally
        Annabel
        Cleo
        Eloise
        Vivienne
        Dara
        Gloria
        Kali
        Eliana
        Zahra
        Maisy
        Maci
        Croíadh
        Heather
        Claudia
        Aideen
        Ann
        Elisha
        Bethany
        Joy
        Sadbh
        Meghan
        Andreea
        Marta
        Arianna
        Halle
        Iseult
        Ayesha
        Myah
        Aya
        Emelia
        Kylie
        Aurelia
        Alba
        Harlow
        Indy
        Kenzie
        Khloe
        Lilah
        Saorlaith
        Valentina
        Adeline
        Dani
        Haniya
        Stevie
        Seoidín
        Shannon
        Jodie
        Kelly
        Wiktoria
        Jenna
        Ashley
        Karolina
        Sasha
        Fatima
        Helen
        Keela
        Natalie
        Beibhinn
        Meadhbh
        Weronika
        Erika
        Imogen
        Angelina
        Winnie
        Amira
        Aida
        Milana
        Autumn
        Marcelina
        Reina
        Rylee
        Michelle
        Leona
        Fiona
        Meabh
        Carla
        Kaitlyn
        Brianna
        Kacey
        Nikola
        Samantha
        Linda
        Sandra
        Serena
        Veronica
        Eileen
        Johanna
        Lauryn
        Madeleine
        Louisa
        Laragh
        Milena
        Izabella
        Paula
        Bianca
        Alessia
        Annalise
        Olive
        Ceoladh
        Edith
        Ryleigh
        Sonia
        Anaya
        Bowie
        Vada
        Eibhlín
        Esmée
        Tori
        Gabrielle
        Julie
        Angel
        Lexie
        Lea
        Una
        Neasa
        Demi
        Karina
        Esther
        Pia
        Emilija
        Leyla
        Martina
        Anne
        Daniela
        Rosemary
        Jessie
        Kyla
        Maura
        Seren
        Mai
        Polly
        Kornelia
        Selena
        Delia
        Ellie-May
        Giulia
        Kitty
        Dakota
        Ella-Mae
        Lily-Mae
        Maddie
        Melody
        Sofija
        Blake
        June
        Philippa
        Caitlín
        Órlaith
        Réiltín
        Zoë
        Síne
        Alaia
        Abbey
        Emer
        Patricia
        Charley
        Ailish
        Paulina
        Alexa
        Caoilinn
        Eilish
        Emilie
        Jamie
        Greta
        Makayla
        Mary-Kate
        Adele
        Christine
        Kaya
        Miya
        Eryn
        Lina
        Amina
        Elisabeth
        Gianna
        Irene
        Izabela
        Kaylee
        Lily-Rose
        Aifric
        Alma
        Bobbi
        Ellie-Mai
        Gaia
        Lois
        Alia
        Dorothy
        Drew
        Georgie
        Lilianna
        Melisa
        Aubrey
        Ida
        Kyah
        Rayna
        Stefania
        Everleigh
        Everly
        Wynter
        Chloé
        Mairéad
        Nicola
        Lisa
        Rachael
        Chantelle
        Sabrina
        Laila
        Charlie
        Melanie
        Caitlyn
        Klaudia
        Deborah
        Angela
        Stacey
        Nia
        Tianna
        Zainab
        Teresa
        Celine
        Nelly
        Saorla
        Aliya
        Judith
        Lili
        Neala
        Paris
        Alise
        Amna
        Anya
        Leia
        Mackenzie
        Selina
        Winifred
        Amalia
        Adah
        Adelina
        Agnes
        Alayna
        Amara
        Amaya
        Ella-Rose
        Indi
        Joni
        Liana
        Macie
        Melania
        Noor
        Rebeca
        Rowan
        Syeda
        Ayra
        Beatrix
        Fallon
        Freyja
        Noreen
        Vayda
        Harleigh
        Winter
        Aibhín
        Béibhinn
        Bríd
        Cáit
        Éirinn
        Íde
        Máire
        Nainsí
        Nóra
        Órla
        Réaltín
        Sibéal
        Érin
        Shona
        Keira
        Aoibhin
        Martyna
        Kirsten
        Katherine
        Tia
        Caroline
        Gabija
        Jorja
        Daniella
        India
        Susan
        Clare
        Enya
        Caoilainn
        Adriana
        Kiara
        Madeline
        Samara
        Kimberly
        Vanesa
        Alexia
        Milly
        Aoileann
        Hayleigh
        Kira
        Hana
        Livia
        Alva
        Anais
        Darci
        Dora
        Gwen
        Kaja
        Maud
        Rosanna
        Wendy
        Alina
        Alix
        Allison
        Ameila
        Anastazja
        Khadija
        Kiya
        Lavinia
        Aiza
        Arwen
        Aubree
        Averie
        Barbara
        Celeste
        Eibhlin
        Eshaal
        Ines
        Jasmina
        Josie
        Kalina
        Leja
        Miley
        Minnie
        Talia
        Theodora
        Yasmina
        Bella-Rose
        Brooklyn
        Delilah
        Eila
        Emmi
        Gia
        Ioana
        Lukne
        Marianna
        Myra
        Nel
        Raina
        Serah
        Tillie
        Yara
        Ellie mae
        Adaline
        Effie
        Faya
        Paisley
        Tuiren
        Aodhla
        Essie
        Aimée
        Ariyah
        Ayat
        Clíona
        Evelin
        Mirha
        Renée
        Fiádh
        Leanne
        Chelsea
        Nadine
        Avril
        Josephine
        Carrie
        Kamila
        Lorna
        Simone
        Dawn
        Jenny
        Kathryn
        Sive
        Gabriele
        Kaci
        Tiffany
        Magdalena
        Mikayla
        Alexandria
        Antonina
        Katy
        Fionnuala
        Jana
        Jess
        Katrina
        Philomena
        Estera
        Iga
        Joyce
        Julianna
        Kimberley
        Larissa
        Patricija
        Sofie
        Yusra
        Camelia
        Carmen
        Carolina
        Emmanuella
        Honor
        Lainey
        Alexis
        Audrey
        Bria
        Ebony
        Emile
        Hailie
        Honey
        Lidia
        Adela
        Adelaide
        Amelia-Rose
        Amirah
        Anabelle
        Ela
        Elia
        Elina
        Ellie-Rose
        Emmy
        Isha
        Jannat
        Kaiya
        Karlie
        Kendall
        Kourtney
        Kyrah
        Lily Mae
        Lyra
        Malwina
        Mara
        Marnie
        Miah
        Migle
        Moira
        Nika
        Reagan
        Soraya
        Thalia
        Treasa
        Vivien
        Afric
        Alena
        Ariah
        Atene
        Athena
        Betty
        Constance
        Darla
        Diya
        Eman
        Fatimah
        Flora
        Giorgia
        Jayda
        Kady
        Kaelyn
        Kora
        Leen
        Liepa
        Lilli
        Liv
        Maisey
        Marwa
        Meadow
        Mina
        Mira
        Miruna
        Olivija
        Oonagh
        Poppie
        Raya
        Remy
        Rena
        Riadh
        Roxanne
        Shelby
        Sommer
        Teodora
        Zoya
        Noa
        Meara
        Romi
        Harlee
        Esmai
        Saileog
        Sloane
        Córa
        Erín
        Júlia
        Lilith
        Lylah
        Reya
        Ríadh
        Rua
        Seána
        Shóna
        Líle
        Siana
        Mealla
        Sia
        Rylie
        Peigí
        Mollaí
        Lucía
        Seóna
        Aylah
        Alys
        Cíara
        Céala
        Damaris
        Blossom
        Féile
        Aadhya
        Éila
        Éire
        Sinead
        Gemma
        Abi
        Keelin
        Kellie
        Cliona
        Tegan
        Karen
        Sharon
        Kiera
        Alesha
        Shania
        Deirdre
        Joanne
        Kasey
        Toni
        Dominika
        Orlagh
        Caoilfhionn
        Kayley
        Kerrie
        Noelle
        Valerie
        Genevieve
        Julianne
        Noemi
        Zarah
        Bernadette
        Meg
        Princess
        Tamara
        Teegan
        Agata
        Brigid
        Denise
        Kaitlin
        Mary Kate
        Rhiannon
        Rita
        Sylvia
        Teigan
        Theresa
        Aela
        Aleena
        Elsa
        Marina
        Michalina
        Tiana
        Celina
        Destiny
        Elaina
        Haley
        Iman
        Isolde
        Olwyn
        Rebeka
        Samira
        Sefora
        Tabitha
        Ailis
        Alissa
        Astrid
        Bebhinn
        Caela
        Cecelia
        Ekaterina
        Eunice
        Evanna
        Frances
        Izzy
        Kallie
        Luiza
        Mallaidh
        Matylda
        Adina
        Amaia
        Amelija
        Arisha
        Asia
        Ayah
        Bianka
        Blanka
        Camilla
        Caoileann
        Cassidy
        Cindy
        Ella May
        Ella Rose
        Fae
        Gaja
        Hafsa
        Ina
        Inaaya
        Izabelle
        Lilla
        Luisa
        Luka
        Macy
        Manuela
        Marika
        Milla
        Molly Mae
        Petra
        Peyton
        Pixie
        Raisa
        Riah
        Shayla
        Susanna
        Sylvie
        Teja
        Tierna
        Urszula
        Viktoria
        Zoja
        Allegra
        Anabia
        Ananya
        Andra
        Anika
        Anna Rose
        Annabella
        Arina
        Beatriz
        Blair
        Bobbie
        Caelyn
        Dalia
        Darya
        Elianna
        Emilee
        Emily-Rose
        Emmeline
        Esmay
        Estela
        Feena
        Hanorah
        Ilinca
        Indiana
        Iqra
        Kaitlynn
        Karly
        Kiyah
        Laya
        Lilly-May
        Lori
        Luana
        Malika
        Marin
        Meadbh
        Mona
        Montana
        Nella
        Pennie
        Radha
        Raven
        Rawan
        Rida
        Riya
        Roseanne
        Salome
        Sana
        Shae
        Suzie
        Tabita
        Tasneem
        Trinity
        Viola
        Zaina
        Zosia
        Esmae
        Joanie
        Alayah
        Della
        Perrie
        Naya
        Nola
        Ailís
        Aodha
        Bébhinn
        Brídín
        Brónagh
        Clódagh
        Éile
        Eilís
        Ríonach
        Roísín
        Síle
        Siobhán
        Xenia
        Mayla
        Rhéa
        Rheia
        Léana
        Mayar
        Zara-Rose
        Zimal
        Rafaela
        Saylor
        Mei
        Sofía
        Teona
        Theadora
        Kenzi
        Kataleya
        Neansaí
        Lyanna
        Marlowe
        Raiya
        Veda
        Mahnoor
        Selin
        Maram
        Melany
        Yuval
        Areen
        Éada
        Ava Grace
        Ériu
        Aviana
        Alaya
        Aibhilín
        Ecaterina
        Bláthín
        Bodhi
        Anna May
        Alondra
        Éadha
        Eimíle
        Aífe
        Aliana
        Amelia Rose
        Críoa
        Adia
        Croí
        Dáire
        Dallas
        Anays
        Ivy-Rose`.split(/\n/);

        // Top 100 Irish Surnames (https://www.swilson.info/topsurnames.php)
        var sNames = 
        `Murphy
        Kelly
        Sullivan
        Walsh
        Smith
        O'Brien
        Byrne
        Ryan
        Connor
        O'Neill
        Reilly
        Doyle
        McCarthy
        Gallagher
        Doherty
        Kennedy
        Lynch
        Murray
        Quinn
        Moore
        McLaughlin
        Carroll
        Connolly
        Daly
        Connell
        Wilson
        Dunne
        Brennan
        Burke
        Collins
        Campbell
        Clarke
        Johnston
        Hughes
        Farrell
        Fitzgerald
        Brown
        Martin
        Maguire
        Nolan
        Flynn
        Thompson
        Callaghan
        O'Donnell
        Duffy
        Mahony
        Boyle
        Healy
        Shea
        White
        Sweeney
        Hayes
        Kavanagh
        Power
        McGrath
        Moran
        Brady
        Stewart
        Casey
        Foley
        Fitzpatrick
        Leary
        McDonnell
        McMahon
        Donnelly
        Regan
        Donovan
        Burns
        Flanagan
        Mullan
        Barry
        Kane
        Robinson
        Cunningham
        Griffin
        Kenny
        Sheehan
        Ward
        Whelan
        Lyons
        Reid
        Graham
        Higgins
        Cullen
        Keane
        King
        Maher
        McKenna
        Bell
        Scott
        Hogan
        Keeffe
        Magee
        McNamara
        McDonald
        McDermott
        Moloney
        Rourke
        Buckley
        Dwyer`.split(/\n/);

        var titles =
        `Mx
        Mr
        Mrs
        Ms
        Miss
        Dr
        Other`.split(/\n/);

        var emails =
        `@redmail.ie
        @greenmail.ie
        @bluemail.ie
        @yellowmail.ie
        @pinkmail.ie
        @orangemail.ie
        @silvermail.ie
        @graymail.ie
        @purplemail.ie
        @magentamail.ie`.split(/\n/);

        // https://data.gov.ie/dataset/dublin-city-roads-and-streets
        var streets =
        `street_name
        ABBEY PARK
        ABBEY STREET LOWER
        ABBEY STREET MIDDLE
        OLD ABBEY STREET
        ABBEY STREET UPPER
        ABBEYFIELD
        ABBEYFIELD
        ABBEYFIELD
        ABBOTSTOWN AVENUE
        ABBOTSTOWN DRIVE
        ABBOTSTOWN ROAD
        ABERCORN ROAD
        ABERCORN TERRACE
        ABERDEEN STREET
        ACCOMMODATION WALK
        ACCOMMODATION WALK
        ACHILL ROAD
        ADAIR LANE
        ADAM COURT
        ADARE AVENUE
        ADARE DRIVE
        ADARE GREEN
        ADARE PARK
        ADARE ROAD
        ADDISON PLACE
        ADDISON ROAD
        ADELAIDE ROAD
        ADRIAN AVENUE
        AIDEEN AVENUE
        AIDEEN DRIVE
        AIDEEN PLACE
        AIKENHEAD TERRACE
        AILESBURY DRIVE
        AILESBURY GARDENS
        AILESBURY GARDENS
        AILESBURY GROVE
        AILESBURY MEWS
        AILESBURY PARK
        AILESBURY ROAD
        AILESBURY ROAD
        AILESBURY LANE
        AIRFIELD COURT
        AIRFIELD PARK
        AIRFIELD ROAD
        ALBANY ROAD
        ALBANY ROAD
        ALBERT COLLEGE AVENUE
        ALBERT COLLEGE CRESCENT
        ALBERT COLLEGE DRIVE
        ALBERT COLLEGE GROVE
        ALBERT COLLEGE LAWN
        ALBERT COLLEGE PARK
        ALBERT COURT EAST
        ALBERT PLACE EAST
        ALBERT PLACE WEST
        ALBERT TERRACE
        ALDBOROUGH PARADE
        ALDBOROUGH PLACE
        ALDBOROUGH SQUARE
        ALDRIN WALK
        ALEXANDRA TERRACE
        ALEXANDER TERRACE
        ALEXANDRA TERRACE
        ALFIE BYRNE ROAD
        ALL SAINTS DRIVE
        ALL SAINTS PARK
        ALL SAINTS PARK
        ALL SAINTS ROAD
        ALLINGHAM STREET
        ALMA TERRACE
        ALMEIDA AVENUE
        AMIENS STREET
        ANGLESEA ROAD
        ANGLESEA ROW
        ANGLESEA STREET
        ANNA VILLA
        ANNADALE AVENUE
        ANNADALE CRESCENT
        ANNADALE DRIVE
        ANNADALE DRIVE
        ANNALY ROAD
        ANNALY ROAD
        ANNAMOE DRIVE
        ANNAMOE PARADE
        ANNAMOE PARK
        ANNAMOE ROAD
        ANNAMOE TERRACE
        ANNAMOE TERRACE
        ANNE'S LANE
        ANNE STREET NORTH
        ANNE STREET SOUTH
        ANNER ROAD
        ANNESLEY AVENUE
        ANNESLEY BRIDGE ROAD
        ANNESLEY PARK
        ANNESLEY PLACE
        APPIAN WAY
        APOLLO WAY
        ARBOUR HILL
        ARBOUR PLACE
        ARBOUR TERRACE
        ARBUTUS AVENUE
        ARBUTUS PLACE
        ARD NA MEALA
        ARDPATRICK ROAD
        ARD RI ROAD
        ARD RI PLACE
        ARDAGH ROAD
        ARDARA AVENUE
        ARDBEG CRESCENT
        ARDBEG DRIVE
        ARDBEG PARK
        ARDBEG ROAD
        ARDCOLLUM AVENUE
        ARDEE ROAD
        ARDEE STREET
        ARDEE STREET
        ARDILAUN ROAD
        ARDILAUN ROAD
        ARDLEA ROAD
        ARDMORE AVENUE
        ARDMORE CLOSE
        ARDMORE CRESCENT
        ARDMORE DRIVE
        ARDMORE GROVE
        ARDMORE PARK
        ARGYLE ROAD
        ARKLOW STREET
        ARMAGH ROAD
        ARMAGH ROAD
        ARMSTRONG STREET
        ARMSTRONG WALK
        ARNOTT STREET
        ARRAN QUAY
        ARRAN ROAD
        ARRAN STREET EAST
        ARRAN STREET WEST
        ARRANMORE AVENUE
        ARRANMORE ROAD
        ARTANE CASTLE SERVICE ROAD
        ASDILL'S ROW
        ASH STREET
        ASHBROOK
        ASHBROOK
        ASHCROFT
        ASHDALE AVENUE
        ASHDALE GARDENS
        ASHDALE PARK
        ASHDALE ROAD
        ASHFIELD AVENUE
        ASHFIELD PARK
        ASHFIELD ROAD
        ASHFIELD ROAD
        ASHFORD COTTAGES
        ASHFORD PLACE
        ASHFORD STREET
        ASHINGTON AVENUE
        ASHINGTON CLOSE
        ASHINGTON COURT
        ASHINGTON CRESCENT
        ASHINGTON DALE
        ASHINGTON GARDENS
        ASHINGTON GREEN
        ASHINGTON GROVE
        ASHINGTON HEATH
        ASHINGTON MEWS
        ASHINGTON PARK
        ASHINGTON RISE
        ASHLING CLOSE
        ASHTOWN GROVE
        ASHTOWN ROAD
        ASHWORTH PLACE
        ASTON PLACE
        ASTON QUAY
        ATHLUMNEY VILLAS
        AUBURN AVENUE
        AUBURN ROAD
        AUBURN STREET
        AUBURN VILLAS
        AUBURN WALK
        AUGHAVANNAGH ROAD
        AUGHRIM COURT
        AUGHRIM LANE
        AUGHRIM PLACE
        AUGHRIM STREET
        AUGHRIM STREET
        AULDEN GRANGE
        AUNGIER LANE
        AUNGIER PLACE
        AUNGIER STREET
        AUSTINS COTTAGES
        AVE MARIA ROAD
        AVENUE ROAD
        AVONDALE AVENUE
        AVONDALE PARK
        AVONDALE ROAD
        AYREFIELD AVENUE
        AYREFIELD COURT
        AYREFIELD DRIVE
        AYREFIELD GROVE
        AYREFIELD PARK
        AYREFIELD PLACE
        AYREFIELD ROAD
        BACHELORS WALK
        BACHELORS WAY
        BACK LANE
        BAGGOT CLOSE
        BAGGOT COURT
        BAGGOT LANE
        BAGGOT ROAD
        BAGGOT ROAD
        BAGGOT STREET LOWER
        BAGGOT STREET LOWER
        BAGGOT STREET LOWER
        BAGGOT STREET UPPER
        BAGGOT STREET UPPER
        BAGGOTRATH PLACE
        BAILEY'S ROW
        BALBUTCHER DRIVE
        BALBUTCHER LANE
        BALBUTCHER WAY
        BALCURRIS GARDENS
        BALCURRIS ROAD
        BALFE AVENUE
        BALFE ROAD
        BALFE ROAD EAST
        BALFE STREET
        BALLS LANE
        BALLSBRIDGE AVENUE
        BALLSBRIDGE PARK
        BALLSBRIDGE TERRACE
        BALLYBOGGAN ROAD
        BALLYBOUGH AVENUE
        BALLYBOUGH COTTAGES
        BALLYBOUGH COURT
        BALLYBOUGH LANE
        BALLYBOUGH ROAD
        BALLYFERMOT AVENUE
        BALLYFERMOT CRESCENT
        BALLYFERMOT DRIVE
        BALLYFERMOT PARADE
        BALLYFERMOT ROAD
        BALLYFERMOT ROAD
        BALLYFERMOT ROAD
        BALLYFERMOT ROAD
        BALLYGALL AVENUE
        BALLYGALL CRESCENT
        BALLYGALL CRESCENT
        BALLYGALL PARADE
        BALLYGALL PLACE
        BALLYGALL ROAD EAST
        BALLYGALL ROAD EAST
        BALLYGALL ROAD WEST
        BALLYGALL ROAD WEST
        BALLYGALL ROAD WEST
        BALLYHOY AVENUE
        BALLYMUN ROAD
        BALLYMUN ROAD
        BALLYNEETY ROAD
        BALLYSHANNON AVENUE
        BALLYSHANNON AVENUE
        BALLYSHANNON ROAD
        BALLYSHANNON ROAD
        BANGOR DRIVE
        BANGOR ROAD
        BANGOR ROAD
        BANN ROAD
        BANNAVILLE
        BANNOW ROAD
        BANNOW ROAD
        BANTRY ROAD
        BARGY ROAD
        BARNAMORE CRESCENT
        BARNAMORE GROVE
        BARNAMORE PARK
        BARRACK LANE
        BARRACK LANE
        BARRON PLACE
        BARROW ROAD
        BARROW STREET
        BARROW STREET
        BARRY AVENUE
        BARRY CLOSE
        BARRY DRIVE
        BARRY GREEN
        BARRY PARK
        BARRY ROAD
        BARRYSCOURT ROAD
        BARRYSCOURT ROAD
        BARRYSCOURT ROAD
        BASIN STREET LOWER
        BASIN STREET UPPER
        BASS PLACE
        BATH AVENUE
        BATH AVENUE GARDENS
        BATH AVENUE PLACE
        BATH LANE
        BATH STREET
        BAYMOUNT PARK
        BAYVIEW AVENUE
        BEACH AVENUE
        BEACH DRIVE
        BEACH ROAD
        BEAUMONT CRESCENT
        BEAUMONT GROVE
        BEAUMONT ROAD
        BEAUMONT ROAD
        BEAUMONT ROAD
        BEAUVALE PARK
        BEAVER CLOSE
        BEAVER ROW
        BEAVER STREET
        BEDFORD LANE
        BEDFORD ROW
        BEECH HILL AVENUE
        BEECH HILL DRIVE
        BEECH HILL ROAD
        BEECHLAWN AVENUE
        BEECHLAWN GREEN
        BEECHLAWN GROVE
        BEECHBROOK GROVE
        BEECHDALE MEWS
        BEECHLAWN CLOSE
        BEECHLAWN GROVE
        BEECHMOUNT COURT
        BEECHPARK AVENUE
        BEECHPARK COURT
        BEECHWOOD AVENUE LOWER
        BEECHWOOD AVENUE UPPER
        BEECHWOOD PARK
        BEECHWOOD ROAD
        BEGGAR'S BUSH COURT
        BELCAMP GARDENS
        BELCAMP GREEN
        BELCAMP GROVE
        BELCAMP GROVE
        BELCAMP LANE
        BELCLARE AVENUE
        BELCLARE CRESCENT
        BELCLARE DRIVE
        BELCLARE GREEN
        BELCLARE GROVE
        BELCLARE LAWNS
        BELCLARE PARK
        BELCLARE TERRACE
        BELCLARE WAY
        BELGRAVE AVENUE
        BELGRAVE PLACE
        BELGRAVE ROAD
        BELGRAVE SQUARE EAST
        BELGRAVE SQUARE NORTH
        BELGRAVE SQUARE SOUTH
        BELGRAVE SQUARE WEST
        BELGROVE LAWN
        BELGROVE PARK
        BELGROVE ROAD
        BELGROVE ROAD
        BELLA AVENUE
        BELLA PLACE
        BELLA STREET
        BELLEVILLE AVENUE
        BELLEVUE AVENUE
        BELLEVUE PARK AVENUE
        BELLEVUE PARK INDUSTRIAL ESTATE
        BELLMANS WALK
        BELLS LANE
        BELMONT AVENUE
        BELMONT COURT
        BELMONT GARDENS
        BELMONT PARK
        BELMONT PARK
        BELMONT PLACE
        BELMONT VILLAS
        BELTON PARK AVENUE
        BELTON PARK GARDENS
        BELTON PARK ROAD
        BELTON PARK ROAD
        BELTON PARK VILLAS
        BELVIDERE AVENUE
        BELVIDERE COURT
        BELVEDERE PLACE
        BELVIDERE ROAD
        BELVIEW
        BEN EDAIR ROAD
        BENBULBIN AVENUE
        BENBULBIN ROAD
        BENBURB STREET
        BENBURB STREET
        BENBURB STREET
        BENEAVIN COURT
        BENEAVIN DRIVE
        BENEAVIN PARK
        BENEAVIN ROAD
        BENMADIGAN ROAD
        BENSON STREET
        BERESFORD AVENUE
        BERESFORD GREEN
        BERESFORD LANE
        BERESFORD LAWN
        BERESFORD PLACE
        BERESFORD STREET
        BERKELEY AVENUE
        BERKELEY PLACE
        BERKELEY ROAD
        BERKELEY STREET
        BERRYFIELD CRESCENT
        BERRYFIELD DRIVE
        BERRYFIELD ROAD
        BESSBOROUGH AVENUE
        BESSBOROUGH PARADE
        BETHESDA PLACE
        BETTYGLEN
        BETTYSTOWN AVENUE
        BIGGER ROAD
        BISHOP STREET
        BLACK STREET
        BLACKBERRY LANE
        BLACKDITCH DRIVE
        BLACKDITCH ROAD
        BLACKDITCH ROAD
        BLACKHALL PARADE
        BLACKHALL PLACE
        BLACKHALL STREET
        BLACKHEATH AVENUE
        BLACKHEATH COURT
        BLACKHEATH DRIVE
        BLACKHEATH GARDENS
        BLACKHEATH GROVE
        BLACKHEATH PARK
        BLACKHORSE AVENUE
        BLACKHORSE AVENUE
        BLACKHORSE GROVE
        BLACKPITTS
        BLACKPITTS
        BLACKWATER ROAD
        BLADDER ALLEY
        BLARNEY PARK
        BLESSINGTON COURT
        BLESSINGTON LANE
        BLESSINGTON PLACE
        BLESSINGTON PLACE
        BLESSINGTON STREET
        BLESSINGTON STREET
        BLOOMFIELD AVENUE
        BLOOMFIELD AVENUE
        BLOOMFIELD COTTAGES
        BLOOMFIELD PARK
        BLOOMFIELD PARK
        BLUEBELL AVENUE
        BLUEBELL AVENUE
        BLUEBELL AVENUE
        BLUEBELL LANE
        BLUEBELL ROAD
        BLUEBELL ROAD
        BLUNDEN DRIVE
        BLUNDEN DRIVE
        BLYTHE AVENUE
        BOARDMANS LANE
        BOLTON STREET
        BOLTON STREET
        BOND STREET
        BONHAM STREET
        BONHAM STREET
        BOOLAVOGUE ROAD
        BORRIS COURT
        BOTANIC AVENUE
        BOTANIC PARK
        BOTANIC ROAD
        BOTANIC ROAD
        BOTANIC VILLAS
        BOW BRIDGE
        BOW LANE EAST
        BOW LANE WEST
        BOW STREET
        BOW STREET
        BOYNE LANE
        BOYNE ROAD
        BOYNE STREET
        BOYNE STREET
        BRABAZON PLACE
        BRABAZON SQUARE
        BRABAZON STREET
        BRACKEN'S LANE
        BRAINBORO TERRACE
        BRAITHWAITE STREET
        THE BRAMBLINGS
        BRANAVILLA
        BRANDON ROAD
        BREGIA ROAD
        BREMEN AVENUE
        BREMEN GROVE
        BREMEN ROAD
        BRENDAN ROAD
        BRIAN AVENUE
        BRIAN BORU AVENUE
        BRIAN BORU STREET
        BRIAN BORU STREET
        BRIAN ROAD
        BRIAN ROAD
        BRIAN TERRACE
        BRIARFIELD GROVE
        BRIARFIELD ROAD
        BRIARFIELD ROAD
        BRIARFIELD VILLAS
        BRICKFIELD DRIVE
        BRICKFIELD LANE
        BRIDE CLOSE
        BRIDE ROAD
        BRIDE STREET
        BRIDE STREET
        BRIDE STREET NEW
        BRIDGE STREET
        BRIDGE STREET LOWER
        BRIDGE STREET UPPER
        BRIDGEFOOT STREET
        BRIDGEFOOT STREET
        BRIGHTON AVENUE
        BRIGHTON AVENUE
        BRIGHTON GARDENS
        BRIGHTON GREEN
        BRIGHTON ROAD
        BRIGHTON SQUARE EAST
        BRIGHTON SQUARE SOUTH
        BRIGHTON SQUARE WEST
        BRITAIN PLACE
        BRITAIN PLACE
        LITTLE BRITAIN STREET
        BRITAIN QUAY
        BROADSTONE
        BROADSTONE AVENUE
        BROADSTONE PLACE
        BROOKFIELD
        BROOKFIELD
        BROOKFIELD
        BROOKFIELD ROAD
        BROOKFIELD STREET
        BROOKVALE ROAD
        BROOKVILLE CRESCENT
        BROOKVILLE
        BROOKVILLE PARK
        BROOKVILLE PARK
        BROOKWOOD AVENUE
        BROOKWOOD AVENUE
        BROOKWOOD CRESCENT
        BROOKWOOD DRIVE
        BROOKWOOD GLEN
        BROOKWOOD GROVE
        BROOKWOOD HEIGHTS
        BROOKWOOD LAWN
        BROOKWOOD MEADOW
        BROOKWOOD PARK
        BROOKWOOD RISE
        BROOKWOOD ROAD
        BROOKWOOD ROAD
        BROOMBRIDGE CLOSE
        BROOMBRIDGE ROAD
        BROWN STREET NORTH
        BROWN STREET SOUTH
        BRUNSWICK PLACE
        BRUNSWICK STREET NORTH
        BRUNSWICK STREET NORTH
        BRUNSWICK STREET NORTH
        BRUNSWICK VILLAS
        BUCKINGHAM STREET LOWER
        BUCKINGHAM STREET UPPER
        BUCKINGHAM STREET UPPER
        BULFIN GARDENS
        BULFIN ROAD
        BULFIN ROAD
        BULL ALLEY STREET
        BUNRATTY AVENUE
        BUNRATTY DRIVE
        BUNRATTY ROAD
        BUNRATTY ROAD
        BUNTING ROAD
        BURGESS LANE
        BURGH QUAY
        BURKE PLACE
        BURLEIGH COURT
        BURLINGTON GARDENS
        BURLINGTON ROAD
        BUSHES LANE
        BUSHFIELD AVENUE
        BUSHFIELD PLACE
        BUSHFIELD SQUARE
        BUSHFIELD TERRACE
        BUSHY PARK GARDENS
        BUSHY PARK ROAD
        BUSHY PARK ROAD
        BUTT BRIDGE
        BYRNE'S LANE
        BYRNES LANE WEST
        CABRA DRIVE
        CABRA GROVE
        CABRA PARK
        CABRA ROAD
        CABRA ROAD
        CADOGAN ROAD
        CALDERWOOD AVENUE
        CALDERWOOD GROVE
        CALDERWOOD ROAD
        CALEDON ROAD
        CAMAC CLOSE
        CAMAC COURT
        CAMAC PARK
        CAMBRIDGE AVENUE
        CAMBRIDGE PARK
        CAMBRIDGE ROAD
        CAMBRIDGE ROAD
        CAMBRIDGE STREET
        CAMBRIDGE TERRACE
        CAMBRIDGE VILLAS
        CAMDEN BUILDINGS
        CAMDEN COURT
        CAMDEN LOCK
        CAMDEN PLACE
        CAMDEN ROW
        CAMDEN STREET LOWER
        CAMDEN STREET UPPER
        CAMDEN VILLAS
        CAMERON SQUARE
        CAMERON STREET
        CAMPBELL'S COURT
        CAMPBELL'S PLACE
        CAMPBELLS ROW
        CANAL ROAD
        CANAL TERRACE
        CANON LILLIS AVENUE
        CAPEL STREET
        CAPEL STREET
        CAPPAGH AVENUE
        CAPPAGH DRIVE
        CAPPAGH ROAD
        CAPPAGH ROAD
        CAPPAGH ROAD
        CAPTAINS AVENUE
        CAPTAINS DRIVE
        CAPTAINS ROAD
        CAPTAINS ROAD
        CARAGH ROAD
        CARBERRY ROAD
        CARDIFF CASTLE ROAD
        CARDIFF LANE
        CARDIFFSBRIDGE AVENUE
        CARDIFFSBRIDGE GROVE
        CARDIFFSBRIDGE ROAD
        CARDS LANE
        CARLETON ROAD
        CARLINGFORD PARADE
        CARLINGFORD ROAD
        CARLISLE AVENUE
        CARLISLE COURT
        CARLISLE STREET
        CARMAN'S HALL
        CARNA ROAD
        CARNDONAGH DRIVE
        CARNDONAGH LAWN
        CARNDONAGH PARK
        CARNDONAGH ROAD
        CARNDONAGH ROAD
        CARNEW STREET
        CARNLOUGH ROAD
        CARNLOUGH ROAD
        CAROLINE ROW
        CARRAROE AVENUE
        CARRICK TERRACE
        CARRICKFOYLE TERRACE
        CARRIG ROAD
        CARRIGALLEN DRIVE
        CARRIGALLEN PARK
        CARRIGALLEN ROAD
        CARROLLS COURT
        CARROW ROAD
        CASEMENT CLOSE
        CASEMENT DRIVE
        CASEMENT GREEN
        CASEMENT GROVE
        CASEMENT PARK
        CASEMENT ROAD LOWER
        CASEMENT ROAD
        CASEMENT ROAD
        CASHEL AVENUE
        CASHEL ROAD
        CASHEL ROAD
        CASHEL ROAD
        CASIMIR AVENUE
        CASIMIR COURT
        CASIMIR ROAD
        CASINO PARK
        CASINO ROAD
        CASTILLA PARK
        CASTLE AVENUE
        CASTLE COURT
        CASTLE GROVE
        CASTLE GROVE
        CASTLE MARKET
        CASTLE ROAD
        CASTLE STREET
        CASTLE TERRACE
        CASTLEFORBES ROAD
        CASTLEKEVIN ROAD
        CASTLETIMON AVENUE
        CASTLETIMON DRIVE
        CASTLETIMON GARDENS
        CASTLETIMON GREEN
        CASTLETIMON PARK
        CASTLETIMON ROAD
        CASTLETIMON ROAD
        CASTLETIMON ROAD
        CASTLEVIEW
        CASTLEWOOD AVENUE
        CASTLEWOOD PARK
        CASTLEWOOD PLACE
        CASTLEWOOD TERRACE
        CATHAL BRUGHA STREET
        CATHEDRAL LANE
        CATHEDRAL STREET
        CATHEDRAL VIEW COURT
        CATHEDRAL VIEW WALK
        CATHERINE COURT
        CATHERINE LANE EAST
        CATHERINE LANE NORTH
        CATHERINE LANE NORTH
        CATHERINE STREET
        CAUSEWAY ROAD
        CAVENDISH ROW
        CEANNT FORT
        CECIL AVENUE
        CECILIA STREET
        CEDAR COURT
        CEDAR PARK
        CEDAR WALK
        CEDARWOOD AVENUE
        CEDARWOOD CLOSE
        CEDARWOOD GREEN
        CEDARWOOD GROVE
        CEDARWOOD PARK
        CEDARWOOD RISE
        CEDARWOOD ROAD
        CEDARWOOD ROAD
        CELESTINE AVENUE
        CELTIC PARK AVENUE
        CELTIC PARK ROAD
        CHAMBER STREET
        CHAMPIONS AVENUE
        CHANCERY LANE
        CHANCERY LANE
        CHANCERY PLACE
        CHANCERY STREET
        CHANEL AVENUE
        CHANEL GROVE
        CHANEL ROAD
        CHAPEL AVENUE
        CHAPEL LANE
        CHAPELIZOD BY PASS
        CHAPELIZOD COURT
        CHAPELIZOD HILL ROAD
        CHAPELIZOD ROAD
        CHAPELIZOD ROAD
        CHARLEMONT
        CHARLEMONT BRIDGE
        CHARLEMONT MALL
        CHARLEMONT PARADE
        CHARLEMONT PLACE
        CHARLEMONT PLACE
        CHARLEMONT ROAD
        CHARLEMONT STREET
        CHARLES LANE
        CHARLES STREET GREAT
        CHARLES STREET WEST
        CHARLESTON AVENUE
        CHARLESTON ROAD
        CHARLEVILLE AVENUE
        CHARLEVILLE CLOSE
        CHARLEVILLE MALL
        CHARLEVILLE ROAD
        CHARLEVILLE ROAD
        CHARLEVILLE ROAD
        CHARLOTTE WAY
        CHATHAM ROW
        CHATHAM STREET
        CHELMSFORD AVENUE
        CHELMSFORD CLOSE
        CHELMSFORD LANE
        CHELMSFORD ROAD
        CHELSEA GARDENS
        CHELTENHAM PLACE
        CHERRY ORCHARD AVENUE
        CHERRY ORCHARD CRESCENT
        CHERRY ORCHARD DRIVE
        CHERRY ORCHARD GREEN
        CHERRY ORCHARD GROVE
        CHERRYFIELD AVENUE LOWER
        CHERRYFIELD AVENUE UPPER
        CHERRYMOUNT CRESCENT
        CHERRYMOUNT GROVE
        CHERRYMOUNT PARK
        CHESTER ROAD
        CHRISTCHURCH PLACE
        CHURCH GARDENS
        CHURCH AVENUE WEST
        CHURCH AVENUE
        CHURCH AVENUE
        CHURCH AVENUE
        CHURCH AVENUE
        CHURCH AVENUE
        CHURCH AVENUE SOUTH
        CHURCH GARDENS
        CHURCH LANE
        CHURCH LANE
        CHURCH LANE SOUTH
        CHURCH PARK AVENUE
        CHURCH PARK COURT
        CHURCH PARK DRIVE
        CHURCH PARK LAWN
        CHURCH PARK WAY
        CHURCH PLACE
        CHURCH ROAD
        CHURCH ROAD
        CHURCH ROAD
        CHURCH ROW
        CHURCH STREET
        CHURCH STREET
        CHURCH STREET EAST
        CHURCH STREET NEW
        CHURCH STREET
        CHURCH STREET UPPER
        CHURCH TERRACE
        CHURCH TERRACE
        CHURCH TERRACE
        CHURCHGATE AVENUE
        CHURCHILL TERRACE
        CIAN PARK
        CILL EANNA
        NORTH CIRCULAR ROAD
        NORTH CIRCULAR ROAD
        NORTH CIRCULAR ROAD
        SOUTH CIRCULAR ROAD
        SOUTH CIRCULAR ROAD
        CITY QUAY
        CLADDAGH GREEN
        CLADDAGH ROAD
        CLANAWLEY ROAD
        CLANAWLEY ROAD
        CLANBOY ROAD
        CLANBRASSIL CLOSE
        CLANBRASSIL STREET LOWER
        CLANBRASSIL STREET UPPER
        CLANBRASSIL STREET UPPER
        CLANBRASSIL TERRACE
        CLANCARTHY ROAD
        CLANCY AVENUE
        CLANCY ROAD
        CLANDONAGH ROAD
        CLANHUGH ROAD
        CLANHUGH ROAD
        CLANMAHON ROAD
        CLANMAURICE ROAD
        CLANMOYLE ROAD
        CLANRANALD ROAD
        CLANREE ROAD
        CLANWILLIAM PLACE
        CLANWILLIAM SQUARE
        CLARE LANE
        CLARE PARK VILLAS
        CLARE ROAD
        CLARE ROAD
        CLARE STREET
        CLAREMONT AVENUE
        CLAREMONT CLOSE
        CLAREMONT COURT
        CLAREMONT CRESCENT
        CLAREMONT DRIVE
        CLAREMONT LAWN
        CLAREMONT PARK
        CLAREMONT ROAD
        CLARENCE MANGAN ROAD
        CLARENCE MANGAN SQUARE
        CLARENCE PLACE GREAT
        CLARENCE STREET GREAT NORTH
        CLARENDON MARKET
        CLARENDON ROW
        CLARENDON ROW
        CLARENDON STREET
        CLARENDON STREET
        CLAREVILLE COURT
        CLAREVILLE GROVE
        CLAREVILLE ROAD
        CLAREVILLE ROAD
        CLARKES TERRACE
        CLAUDE ROAD
        CLEGGAN AVENUE
        CLEGGAN PARK
        CLEGGAN ROAD
        CLIFDEN DRIVE
        CLIFTON MEWS
        CLIFDEN ROAD
        CLIFTONVILLE ROAD
        CLINCHS COURT
        CLOGHER ROAD
        CLOGHER ROAD
        CLOGHER ROAD
        CLONARD ROAD
        CLONARD ROAD
        CLONFERT ROAD
        CLONLARA ROAD
        CLONLIFFE AVENUE
        CLONLIFFE GARDENS
        CLONLIFFE ROAD
        CLONMACNOISE GROVE
        CLONMACNOISE ROAD
        CLONMACNOISE ROAD
        CLONMACNOISE ROAD
        CLONMACNOISE ROAD
        CLONMEL ROAD
        CLONMEL STREET
        CLONMELLON GROVE
        CLONMORE ROAD
        CLONMORE TERRACE
        CLONROSSE COURT
        CLONROSSE DRIVE
        CLONROSSE PARK
        CLONSHAUGH AVENUE
        CLONSHAUGH CLOSE
        CLONSHAUGH CRESCENT
        CLONSHAUGH DRIVE
        CLONSHAUGH GREEN
        CLONSHAUGH GROVE
        CLONSHAUGH HEIGHTS
        CLONSHAUGH HEIGHTS
        CLONSHAUGH LAWN
        CLONSHAUGH MEADOW
        CLONSHAUGH PARK
        CLONSHAUGH PARK
        CLONSHAUGH RISE
        CLONSHAUGH ROAD
        CLONSHAUGH WALK
        CLONSKEAGH ROAD
        CLONSKEAGH ROAD
        CLONTARF PARK
        CLONTARF PARK
        CLONTARF ROAD
        CLONTARF ROAD
        CLONTURK AVENUE
        CLONTURK GARDENS
        CLONTURK PARK
        CLOONLARA CRESCENT
        CLOONLARA DRIVE
        CLOONLARA ROAD
        CLOVERHILL DRIVE
        CLOVERHILL ROAD
        CLOVERHILL ROAD
        CLOYNE ROAD
        CLUNE ROAD
        CLUNE ROAD
        CLYDE LANE
        CLYDE ROAD
        COBURG PLACE
        COKE LANE
        COLBERT'S FORT
        COLDCUT ROAD
        COLEPARK AVENUE
        COLEPARK DRIVE
        COLEPARK GREEN
        COLEPARK ROAD
        COLERAINE STREET
        COLES LANE
        COLLEGE GREEN
        COLLEGE MANOR
        COLLEGE STREET
        COLLIERS AVENUE
        COLLINS AVENUE
        COLLINS AVENUE EAST
        COLLINS AVENUE EXTENSION
        COLLINS AVENUE WEST
        COLLINS DRIVE
        COLLINS GREEN
        COLLINS PARK
        COLLINS PLACE
        COLLINS ROW
        COMERAGH ROAD
        COMMONS STREET
        COMYN PLACE
        CON COLBERT ROAD
        CON COLBERT ROAD
        CONNAUGHT PARADE
        CONNAUGHT STREET
        CONNOLLY AVENUE
        CONNOLLY GARDENS
        CONOR CLUNE ROAD
        CONQUER HILL AVENUE
        CONQUER HILL ROAD
        CONQUER HILL ROAD
        CONSTITUTION HILL
        CONVENT AVENUE
        CONVENT CLOSE
        CONVENT PLACE
        CONYNGHAM ROAD
        CONYNGHAM ROAD
        COOK STREET
        COOK STREET
        COOLATREE CLOSE
        COOLATREE PARK
        COOLATREE ROAD
        COOLEEN AVENUE
        COOLEVIN ROAD
        COOLEY ROAD
        COOLEY ROAD
        COOLGARIFF ROAD
        COOLGARIFF ROAD
        COOLGREENA CLOSE
        COOLGREENA ROAD
        COOLOCK DRIVE
        COOLOCK DRIVE
        COOLOCK DRIVE
        COOLOCK LANE
        COOLOCK LANE OLD
        COOLRUA DRIVE
        COOMBE COURT
        COPE STREET
        COPE STREET
        COPELAND AVENUE
        COPELAND GROVE
        COPPER ALLEY
        COPPINGER ROW
        CORK HILL
        CORK HILL
        CORK STREET
        CORMAC TERRACE
        CORN EXCHANGE PLACE
        CORNMARKET
        CORNMARKET
        JAMES JOYCE STREET
        CORRIB ROAD
        COSTELLO'S COTTAGES
        COULSON AVENUE
        COULTRY AVENUE
        COULTRY CRESCENT
        COULTRY DRIVE
        COULTRY GARDENS
        COULTRY GROVE
        COULTRY LAWN
        COULTRY PARK
        COULTRY ROAD
        COULTRY WAY
        OLD COUNTY ROAD
        COWPER DOWNS
        COWPER DRIVE
        COWPER GARDENS
        COWPER MEWS
        COWPER ROAD
        COWPER ROAD
        COWPER ROAD
        COWPER STREET
        COWPER STREET
        COWPER VILLAGE
        CRAIGFORD AVENUE
        CRAIGFORD DRIVE
        CRAMPTON COURT
        CRAMPTON COURT
        CRAMPTON QUAY
        CRANE LANE
        CRANE STREET
        CRANFIELD PLACE
        CRANMER LANE
        CRANOGUE ROAD
        CRANOGUE CLOSE
        CRAWFORD AVENUE
        CRAWFORD TERRACE
        CREIGHTON STREET
        CREMONA ROAD
        CREMORE AVENUE
        CREMORE CRESCENT
        CREMORE DRIVE
        CREMORE DRIVE
        CREMORE HEIGHTS
        CREMORE LAWN
        CREMORE PARK
        CREMORE ROAD
        CREMORE VILLAS
        CREMORNE
        CRESCENT GARDENS
        CRESCENT PLACE
        CRESCENT VILLAS
        THE CRESCENT
        CRESTFIELD AVENUE
        CRESTFIELD CLOSE
        CRESTFIELD DRIVE
        CRESTFIELD PARK
        CRESTFIELD ROAD
        CROAGHPATRICK ROAD
        CROFTWOOD CRESCENT
        CROFTWOOD DRIVE
        CROFTWOOD GARDENS
        CROFTWOOD GREEN
        CROFTWOOD GROVE
        CROFTWOOD PARK
        CROKE PARK
        CROMCASTLE AVENUE
        CROMCASTLE CLOSE
        CROMCASTLE DRIVE
        CROMCASTLE GREEN
        CROMCASTLE PARK
        CROMCASTLE ROAD
        CROMWELLS QUARTERS
        CROMWELLS QUARTERS
        CROMWELLS FORT ROAD
        CROSS LANE SOUTH
        CROSSTICK ALLEY
        CROTTY AVENUE
        CROW STREET
        CROWN ALLEY
        CROYDON GARDENS
        CROYDON GREEN
        CROYDON PARK AVENUE
        CROYDON PARK AVENUE
        CRUMLIN ROAD
        CUALA ROAD
        CUCKOO LANE
        CUCKOO LANE
        CUFFE LANE
        CUFFE STREET
        CULLENSWOOD GARDENS
        CULLENSWOOD PARK
        CULLENSWOOD ROAD
        CUMBERLAND COURT
        CUMBERLAND ROAD
        CUMBERLAND STREET NORTH
        CUMBERLAND STREET SOUTH
        CURLEW ROAD
        CURRACLOE DRIVE
        CURVED STREET
        CURZON STREET
        CUSTOM HOUSE QUAY
        CYMRIC ROAD
        D'OLIER STREET
        DALCASSIAN DOWNS
        DALYMOUNT
        DALYMOUNT
        DAME COURT
        DAME LANE
        DAME STREET
        DANE ROAD
        DANESWELL ROAD
        DANIEL STREET
        DANIELI DRIVE
        DANIELI ROAD
        DARGLE ROAD
        DARGLE ROAD
        DARLEY STREET
        DARLEY'S TERRACE
        DARLING ESTATE
        DARNDALE SERVICE ROAD
        DARNDALE ESTATE ROAD NO. 01
        DARNDALE ESTATE ROAD NO. 02
        DARNDALE ESTATE ROAD NO. 03
        DARNDALE ESTATE ROAD NO. 04
        DARNDALE ESTATE ROAD NO. 05
        DARNDALE ESTATE ROAD NO. 06
        DARNDALE ESTATE ROAD NO. 07
        DARNDALE ESTATE ROAD NO. 08
        DARNDALE ESTATE ROAD NO. 09
        DARNDALE ESTATE ROAD NO. 10
        DARNDALE ESTATE ROAD NO. 11
        DARNDALE ESTATE ROAD NO. 12
        DARNDALE ESTATE ROAD NO. 13
        DARTMOUTH LANE
        DARTMOUTH PLACE
        DARTMOUTH ROAD
        DARTMOUTH ROAD
        DARTMOUTH SQUARE EAST
        DARTMOUTH SQUARE NORTH
        DARTMOUTH SQUARE SOUTH
        DARTMOUTH SQUARE WEST
        DARTMOUTH TERRACE
        DARTMOUTH WALK
        DARTRY COTTAGES
        DARTRY PARK
        DARTRY ROAD
        DAVID PARK
        DAVID ROAD
        DAVIS PLACE
        DAVITT ROAD
        DAWSON COURT
        DAWSON LANE
        DAWSON LANE
        DAWSON STREET
        DE BURGH ROAD
        DE COURCY SQUARE
        DE VALERA PLACE
        DEAN STREET
        DEAN SWIFT GREEN
        DEAN SWIFT ROAD
        DEAN SWIFT SQUARE
        DEANSTOWN AVENUE
        DEANSTOWN AVENUE
        DEANSTOWN DRIVE
        DEANSTOWN GREEN
        DEANSTOWN PARK
        DEANSTOWN ROAD
        DECIES ROAD
        DELVILLE ROAD
        DELVIN ROAD
        THE DEMESNE
        THE DEMESNE
        DENMARK STREET GREAT
        DENZILLE LANE
        DERMOT O'HURLEY AVENUE
        DERRAVARAGH ROAD
        DERRY DRIVE
        DERRY PARK
        DERRY ROAD
        DERRYNANE GARDENS
        DERRYNANE PARADE
        DESMOND STREET
        DEVENISH ROAD
        DEVERELL PLACE
        DEVERY'S LANE
        DEVLIN'S PLACE
        DEVOY ROAD
        DIGGES LANE
        DIGGES STREET UPPER
        DILLON PLACE SOUTH
        DINGLE ROAD
        DISTILLERY ROAD
        DODDER TERRACE
        DODDER VIEW COTTAGES
        DOLLYMOUNT AVENUE
        DOLLYMOUNT GROVE
        DOLLYMOUNT PARK
        DOLLYMOUNT RISE
        DOLPHIN AVENUE
        DOLPHIN COURT
        DOLPHIN ROAD
        DOLPHIN ROAD
        DOLPHIN ROAD
        DOLPHINS BARN
        DOLPHINS BARN BRIDGE
        DOLPHINS BARN STREET
        DOMINICK LANE
        DOMINICK LANE
        DOMINICK PLACE
        DOMINICK STREET LOWER
        DOMINICK STREET UPPER
        DONAGHMEDE AVENUE
        DONAGHMEDE DRIVE
        DONAGHMEDE PARK
        DONAGHMEDE ROAD
        DONARD ROAD
        DONNELLAN AVENUE
        DONNYBROOK CASTLE
        DONNYBROOK COURT
        DONNYBROOK CLOSE
        DONNYBROOK MANOR
        DONNYBROOK ROAD
        DONNYCARNEY ROAD
        DONORE AVENUE
        DONORE AVENUE
        DONORE AVENUE
        DONORE AVENUE
        DONORE AVENUE
        DONORE ROAD
        DONORE TERRACE
        DONOVAN LANE
        DOON AVENUE
        DOON COURT
        DORIS STREET
        DORSET LANE
        DORSET PLACE
        DORSET PLACE
        DORSET STREET LOWER
        DORSET STREET UPPER
        DORSET STREET UPPER
        DOWLAND ROAD
        DOWLING'S COURT
        DOWNPATRICK ROAD
        DOWTH AVENUE
        DRAPIER GREEN
        DRAPIER ROAD
        DRAPIER ROAD
        DRIMNAGH ROAD
        DROMARD ROAD
        DROMARD TERRACE
        DROMAWLING ROAD
        DROMBAWN AVENUE
        DROMEEN AVENUE
        DROMLEE CRESCENT
        DROMNANANE PARK
        DROMNANANE ROAD
        DROMORE ROAD
        DRUMALEE AVENUE
        DRUMALEE COURT
        DRUMALEE DRIVE
        DRUMALEE GROVE
        DRUMALEE PARK
        DRUMALEE ROAD
        DRUMCLIFFE DRIVE
        DRUMCLIFFE ROAD
        DRUMCONDRA PARK
        DRUMCONDRA ROAD LOWER
        DRUMCONDRA ROAD LOWER
        DRUMCONDRA ROAD UPPER
        DRUMFINN AVENUE
        DRUMFINN PARK
        DRUMFINN ROAD
        DRUMMOND PLACE
        DRURY STREET
        DUFFERIN AVENUE
        DUKE LANE LOWER
        DUKE LANE UPPER
        DUKE STREET
        DUNARD AVENUE
        DUNARD COURT
        DUNARD DRIVE
        DUNARD PARK
        DUNARD ROAD
        DUNARD WALK
        DUNDANIEL ROAD
        DUNDANIEL ROAD
        DUNDRUM ROAD
        DUNLUCE ROAD
        DUNMANUS COURT
        DUNMANUS ROAD
        DUNNE STREET
        DUNNE STREET
        DUNREE PARK
        DUNSEVERICK ROAD
        DUNSINK AVENUE
        DUNSINK DRIVE
        DUNSINK DRIVE
        DUNSINK DRIVE
        DUNSINK GARDENS
        DUNSINK GREEN
        DUNSINK PARK
        DUNSINK ROAD
        DUNSINK ROAD
        DUNVILLE AVENUE
        DUNVILLE AVENUE
        DURHAM ROAD
        DURHAM ROAD
        DURROW ROAD
        EAGLE HILL AVENUE
        EAGLE PARK
        EARL PLACE
        EARL STREET NORTH
        EARL STREET SOUTH
        EARL STREET SOUTH
        EARLS COURT
        EARLSFORT TERRACE
        EARLSFORT TERRACE
        EAST ROAD
        EAST ROAD
        EAST ROAD
        EAST WALL ROAD
        EASTMORELAND LANE
        EASTMORELAND PLACE
        EASTMORELAND PLACE
        EATON ROAD
        EATON SQUARE
        EBENEZER TERRACE
        EBLANA VILLAS
        ECCLES COURT
        ECCLES PLACE
        ECCLES STREET
        ECHLIN STREET
        EDEN QUAY
        EDEN TERRACE
        EDENMORE AVENUE
        EDENMORE CRESCENT
        EDENMORE DRIVE
        EDENMORE GARDENS
        EDENMORE GREEN
        EDENMORE GREEN
        EDENMORE GROVE
        EDENMORE GROVE
        EDENMORE PARK
        EDENMORE PARK
        EDENVALE ROAD
        EFFRA ROAD
        EGLINTON PARK
        EGLINTON PARK
        EGLINTON ROAD
        EGLINTON SQUARE
        EGLINTON TERRACE
        EGLINTON TERRACE
        EKLAD CLOSE
        EKLAD PARK
        ELGIN ROAD
        ELIZABETH STREET
        ELLENFIELD ROAD
        ELLESMERE AVENUE
        ELLIS QUAY
        ELLIS STREET
        ELM MOUNT AVENUE
        ELM MOUNT CLOSE
        ELM MOUNT COURT
        ELM MOUNT CRESCENT
        ELM MOUNT DRIVE
        ELM MOUNT GROVE
        ELM MOUNT HEIGHTS
        ELM MOUNT LAWN
        ELM MOUNT PARK
        ELM MOUNT RISE
        ELM MOUNT ROAD
        ELM MOUNT VIEW
        ELMPARK AVENUE
        ELM PARK
        ELM PARK TERRACE
        ELM ROAD
        ELMDALE CRESCENT
        ELMDALE DRIVE
        ELMDALE PARK
        ELMFIELD AVENUE
        ELMFIELD CLOSE
        ELMFIELD COURT
        ELMFIELD CRESCENT
        ELMFIELD DRIVE
        ELMFIELD GREEN
        ELMFIELD GROVE
        ELMFIELD LAWN
        ELMFIELD PARK
        ELMFIELD RISE
        ELMFIELD VALE
        ELMFIELD WALK
        ELMFIELD WAY
        ELMWOOD AVENUE LOWER
        ELMWOOD AVENUE UPPER
        ELTON COURT
        ELTON DRIVE
        ELTON PARK
        ELTON WALK
        ELY PLACE
        ELY PLACE
        ELY PLACE UPPER
        EMERALD COTTAGES
        EMERALD PLACE
        EMERALD SQUARE
        EMERALD STREET
        EMERALD TERRACE
        EMMET ROAD
        EMMET ROAD
        EMMET STREET
        EMMET STREET
        EMOR STREET
        EMORVILLE AVENUE
        EMPRESS PLACE
        EMPRESS PLACE
        ENAVILLE AVENUE
        ENAVILLE ROAD
        ENGINE ALLEY
        ENNAFORT AVENUE
        ENNAFORT COURT
        ENNAFORT DRIVE
        ENNAFORT GROVE
        ENNAFORT PARK
        ENNAFORT ROAD
        ENNEL AVENUE
        ENNEL DRIVE
        ENNEL PARK
        ENNIS GROVE
        ENNISKERRY ROAD
        ERNE PLACE
        ERNE PLACE LITTLE
        ERNE PLACE LOWER
        ERNE PLACE LOWER
        ERNE STREET LOWER
        ERNE STREET UPPER
        ERNE TERRACE FRONT
        ERNE TERRACE REAR
        ERRIGAL GARDENS
        ERRIGAL ROAD
        ERRIGAL ROAD
        ERRIS ROAD
        ESMOND AVENUE
        ESPOSITO ROAD
        ESSEX GATE
        ESSEX QUAY
        ESSEX STREET EAST
        ESSEX STREET WEST
        ESTATE AVENUE
        ESTATE COTTAGES
        ESTATE COTTAGES
        ESTATE COTTAGES
        EUGENE STREET
        EUSTACE BRIDGE
        EUSTACE STREET
        EVERTON AVENUE
        EWINGTON LANE
        EXCHANGE COURT
        EXCHANGE STREET LOWER
        EXCHANGE STREET LOWER
        EXCHANGE STREET UPPER
        EXCHEQUER STREET
        FADE STREET
        FAIRFIELD AVENUE
        FAIRFIELD AVENUE
        FAIRFIELD PARK
        FAIRFIELD PARK
        FAIRFIELD ROAD
        FAIRLAWN PARK
        FAIRLAWN ROAD
        FAIRVIEW
        FAIRVIEW AVENUE LOWER
        FAIRVIEW AVENUE UPPER
        FAIRVIEW GREEN
        FAIRVIEW PASSAGE
        FAIRVIEW STRAND
        FAIRVIEW TERRACE
        FAITH AVENUE
        FALCARRAGH ROAD
        FARNEY PARK
        FARNHAM CRESCENT
        FARNHAM DRIVE
        FARNHAM DRIVE
        FARRELL'S LANE
        FATHER KITT COURT
        FATHER MATTHEW SQUARE
        FAUGHART ROAD
        FAUSSAGH AVENUE
        FAUSSAGH AVENUE
        FAUSSAGH ROAD
        FENIAN STREET
        FERGUS ROAD
        FERGUSON ROAD
        FERGUSON ROAD
        FERNDALE AVENUE
        FERNDALE ROAD
        FERNS ROAD
        FERNVALE DRIVE
        FERRARD ROAD
        FERRYCARRIG AVENUE
        FERRYCARRIG DRIVE
        FERRYCARRIG GREEN
        FERRYCARRIG PARK
        FERRYCARRIG ROAD
        FERRYMANS CROSSING
        FERTULLAGH ROAD
        FIELD AVENUE
        RIALTO COTTAGES-FIFTH AVENUE
        FINDLATER PLACE
        FINDLATER STREET
        FINGAL PLACE
        FINGAL STREET
        FINGLAS PARK
        FINGLAS PLACE
        FINGLAS PLACE
        FINGLAS ROAD
        FINGLASWOOD ROAD
        FINGLASWOOD ROAD
        FINN STREET
        FIRST AVENUE
        FIRST AVENUE
        FISHAMBLE STREET
        FITZGERALD STREET
        FITZGIBBON LANE
        FITZGIBBON STREET
        FITZMAURICE ROAD
        FITZPATRICK'S COTTAGES
        FITZROY AVENUE
        FITZWILLIAM COURT
        FITZWILLIAM LANE
        FITZWILLIAM PLACE
        LITTLE FITZWILLIAM PLACE
        FITZWILLIAM PLACE NORTH
        FITZWILLIAM QUAY
        FITZWILLIAM QUAY
        FITZWILLIAM SQUARE EAST
        FITZWILLIAM SQUARE NORTH
        FITZWILLIAM SQUARE SOUTH
        FITZWILLIAM SQUARE WEST
        FITZWILLIAM STREET
        FITZWILLIAM STREET
        FITZWILLIAM STREET LOWER
        FITZWILLIAM STREET UPPER
        FLEET STREET
        FLEET STREET
        FLEMING PLACE
        FLEMING ROAD
        FLORENCE STREET
        FOLEY STREET
        FONTENOY STREET
        FORBES LANE
        FORBES STREET
        FORTESCUE LANE
        FORTFIELD GARDENS
        FORTFIELD ROAD
        FORTFIELD ROAD
        FORTFIELD TERRACE
        FORTFIELD TERRACE
        FORTH ROAD
        FORTVIEW AVENUE
        FOSTER PLACE NORTH
        FOSTER PLACE
        FOSTER TERRACE
        FOUNTAIN PLACE
        RIALTO COTTAGES-FOURTH AVENUE
        FOURTH AVENUE
        FOWNES STREET LOWER
        FOWNES STREET UPPER
        FOWNES STREET UPPER
        FOX'S LANE
        FOXFIELD AVENUE
        FOXFIELD CRESCENT
        FOXFIELD DRIVE
        FOXFIELD GREEN
        FOXFIELD GROVE
        FOXFIELD HEIGHTS
        FOXFIELD LAWN
        FOXFIELD PARK
        FOXFIELD ROAD
        FOXFIELD SAINT JOHN
        FOXHILL AVENUE
        FOXHILL CLOSE
        FOXHILL COURT
        FOXHILL CRESCENT
        FOXHILL DRIVE
        FOXHILL GREEN
        FOXHILL GROVE
        FOXHILL LAWN
        FOXHILL PARK
        FOXHILL WAY
        FOYLE ROAD
        FRANCIS STREET
        FRANK SHERWIN BRIDGE
        FRANKFORT AVENUE
        FRANKFORT COTTAGES
        FREDERICK COURT
        FREDERICK LANE NORTH
        FREDERICK STREET NORTH
        FREDERICK STREET SOUTH
        FREDERICK WALK
        FRENCHMAN'S LANE
        FRIARY AVENUE
        FRIARY GROVE
        FUMBALLY LANE
        FURRY PARK ROAD
        GAELIC STREET
        CHERRY ORCHARD PARADE
        CHERRY ORCHARD PARK
        GALLANSTOWN LANE
        CHERRY ORCHARD PARADE
        CHERRY ORCHARD WAY
        GALLAUN ROAD
        GALMOY ROAD
        GALTYMORE CLOSE
        GALTYMORE DRIVE
        GALTYMORE PARK
        GALTYMORE ROAD
        GALTYMORE ROAD
        GALTYMORE ROAD
        GANDON CLOSE
        GARDEN LANE
        GARDEN LANE
        GARDEN LANE
        GARDEN TERRACE
        GARDEN VIEW
        GARDINER LANE
        GARDINER PLACE
        GARDINER ROW
        GARDINER STREET LOWER
        GARDINER STREET MIDDLE
        GARDINER STREET UPPER
        GARRYNURE
        GARRYOWEN ROAD
        GARTAN AVENUE
        GARTER COURT
        GARVILLE AVENUE
        GARVILLE AVENUE UPPER
        GARVILLE DRIVE
        GARVILLE PLACE
        GARVILLE ROAD
        GEOFFREY KEATING ROAD
        GEORGE'S HILL
        GEORGE'S LANE
        GEORGE'S PLACE
        GEORGE'S QUAY
        GEORGE'S ROAD
        NORTH GREAT GEORGE'S STREET
        GEORGE'S STREET GREAT SOUTH
        GEORGES WHARF
        GERALD STREET
        GERALDINE STREET
        GILBERT ROAD
        GILFORD AVENUE
        GILFORD COURT
        GILFORD DRIVE
        GILFORD PARK
        GILFORD PINES
        GILFORD ROAD
        GILFORD TERRACE
        GLANDORE ROAD
        GLASANAON COURT
        GLASANAON PARK
        GLASANAON ROAD
        GLASANAON ROAD
        GLASAREE ROAD
        GLASILAWN AVENUE
        GLASILAWN AVENUE
        GLASILAWN ROAD
        GLASMEEN ROAD
        GLASMEEN ROAD
        GLASNAMANA PLACE
        GLASNAMANA ROAD
        GLASNEVIN HILL
        GLASNEVIN AVENUE
        GLASNEVIN COURT
        GLASNEVIN COURT
        GLASNEVIN DOWNS
        GLASNEVIN DRIVE
        GLASNEVIN PARK
        GLASNEVIN WOODS
        GLENAAN ROAD
        GLENARD AVENUE
        GLENARM AVENUE
        GLENAULIN DRIVE
        GLENAULIN PARK
        GLENAVY PARK
        GLENAYLE ROAD
        GLENAYR ROAD
        GLENBEIGH PARK
        GLENBEIGH ROAD
        GLENBEIGH ROAD
        GLENBROOK ROAD
        GLENCAR ROAD
        GLENCORP ROAD
        GLENCLOY ROAD
        GLENDALOUGH ROAD
        GLENDHU PARK
        GLENDHU ROAD
        GLENDINNING LANE
        GLENDUN ROAD
        GLENEALY ROAD
        GLENEALY ROAD
        GLENFARNE ROAD
        GLENFARNE ROAD
        GLENGARRIFF PARADE
        GLENARRIFF ROAD
        GLENGARRIFF CRESCENT
        GLENHILL AVENUE
        GLENHILL COURT
        GLENHILL DRIVE
        GLENHILL GROVE
        GLENHILL ROAD
        GLENHILL VILLAS
        GLENMALURE PARK
        GLENMALURE SQUARE
        GLENMORE ROAD
        GLENSHESK ROAD
        GLENTIES DRIVE
        GLENTIES DRIVE
        GLENTIES PARK
        GLENTIES PARK
        GLENTOW ROAD
        GLENWOOD ROAD
        GLENWOOD ROAD
        GLENTWORTH PARK
        GLIN AVENUE
        GLIN CRESCENT
        GLIN DRIVE
        GLIN GROVE
        GLIN PARK
        GLIN ROAD
        GLIN ROAD
        GLOUCESTER LANE
        GLOUCESTER PLACE
        GLOUCESTER PLACE LOWER
        GLOUCESTER PLACE UPPER
        GLOUCESTER PLACE UPPER
        GLOUCESTER STREET SOUTH
        GLOVERS ALLEY
        GLOVERS ALLEY
        GODFREY PLACE
        GOFTON HALL
        GOLDEN LANE
        GOLDEN LANE
        GOLDENBRIDGE AVENUE
        GOLDENBRIDGE AVENUE
        GOLDEN BRIDGE GARDENS
        GOLDENBRIDGE TERRACE
        GOLDENBRIDGE WALK
        GOLDSMITH STREET
        GORDON STREET
        GORDON PLACE
        GORTBEG AVENUE
        GORTBEG DRIVE
        GORTBEG PARK
        GORTBEG ROAD
        GORTMORE AVENUE
        GORTMORE DRIVE
        GORTMORE PARK
        GORTMORE ROAD
        GRACE PARK AVENUE
        GRACE PARK COURT
        GRACE PARK GARDENS
        GRACE PARK HEIGHTS
        GRACE PARK MEADOWS
        GRACE PARK ROAD
        GRACE PARK ROAD
        GRACE PARK ROAD
        GRACE PARK ROAD
        GRACE PARK TERRACE
        GRACE PARK TERRACE
        GRACEFIELD AVENUE
        GRACEFIELD COURT
        GORSEFIELD COURT
        GRACEFIELD ROAD
        GRACEFIELD ROAD
        GRACE PARK LAWNS
        GRAFTON STREET
        GRAFTON STREET
        GRAHAM'S COURT
        GRAHAM'S ROW
        GRAIGUE COURT
        GRANBY LANE
        GRANBY PLACE
        GRANBY ROW
        GRAND CANAL BANK
        GRAND CANAL PLACE
        GRAND CANAL QUAY
        GRAND CANAL QUAY
        GRAND CANAL STREET LOWER
        GRAND CANAL STREET UPPER
        GRAND CANAL VIEW
        GRAND PARADE
        GRANGE ABBEY CRESCENT
        GRANGE ABBEY DRIVE
        GRANGE ABBEY GROVE
        GRANGE PARK AVENUE
        GRANGE PARK CLOSE
        GRANGE PARK CRESCENT
        GRANGE PARK DRIVE
        GRANGE PARK GREEN
        GRANGE PARK GROVE
        GRANGE PARK RISE
        GRANGE PARK ROAD
        GRANGE PARK ROAD
        GRANGE PARK VIEW
        GRANGE PARK WALK
        GRANGE ROAD
        GRANGE ROAD
        GRANGEGORMAN LOWER
        GRANGEGORMAN UPPER
        GRANGEGORMAN UPPER
        GRANGEMORE AVENUE
        GRANGEMORE COURT
        GRANGEMORE CRESCENT
        GRANGEMORE DRIVE
        GRANGEMORE GROVE
        GRANGEMORE LAWN
        GRANGEMORE PARK
        GRANGEMORE RISE
        GRANGEMORE ROAD
        GRANITE PLACE
        GRANITE TERRACE
        GRANTHAM PLACE
        GRANTHAM PLACE
        GRANTHAM STREET
        GRANTS ROW
        GRANTS ROW
        GRATTAN COURT EAST
        GRATTAN COURT WEST
        GRATTAN CRESCENT
        GRATTAN PARADE
        GRATTAN PLACE
        GRATTAN STREET
        GRAY SQUARE
        GRAY STREET
        GREAT WESTERN AVENUE
        GREAT WESTERN SQUARE EAST
        GREAT WESTERN SQUARE NORTH
        GREAT WESTERN SQUARE SOUTH
        GREAT WESTERN SQUARE WEST
        GREAT WESTERN VILLAS
        GREEK STREET
        GREEN STREET
        GREEN STREET
        GREEN STREET EAST
        GREEN STREET EAST
        LITTLE GREEN STREET
        GREENCASTLE AVENUE
        GREENCASTLE AVENUE
        GREENCASTLE CRESCENT
        GREENCASTLE DRIVE
        GREENCASTLE PARADE
        GREENCASTLE PARK
        GREENCASTLE ROAD
        GREENCASTLE ROAD
        GREENDALE AVENUE
        GREENDALE COURT
        GREENDALE ROAD
        GREENFIELD CRESCENT
        GREENFIELD PARK
        GREENFIELD PLACE
        GREENLEA AVENUE
        GREENLEA DRIVE
        GREENLEA GROVE
        GREENLEA PARK
        GREENLEA ROAD
        GREENMOUNT AVENUE
        GREENMOUNT COURT
        GREENMOUNT LANE
        GREENMOUNT LAWNS
        GREENMOUNT ROAD
        GREENMOUNT SQUARE
        GREENORE TERRACE
        GREENVILLE AVENUE
        GRENVILLE LANE
        GREENVILLE PARADE
        GRENVILLE STREET
        GREENVILLE TERRACE
        GREENWICH COURT
        GREENWOOD AVENUE
        GREENWOOD CLOSE
        GREENWOOD COURT
        GREENWOOD DRIVE
        GREENWOOD LAWN
        GREENWOOD PARK
        GREENWOOD WALK
        GREENWOOD WAY
        GRIFFITH AVENUE
        GRIFFITH AVENUE
        GRIFFITH AVENUE
        GRIFFITH CLOSE
        GRIFFITH COURT
        GRIFFITH DOWNS
        GRIFFITH DRIVE
        GRIFFITH LAWNS
        GRIFFITH PARADE
        GRIFFITH ROAD
        GRIFFITH ROAD
        GRIFFITH ROAD
        GRIFFITH WALK
        GROSVENOR COURT
        GROSVENOR LANE
        GROSVENOR LODGE
        GROSVENOR PARK
        GROSVENOR PLACE
        GROSVENOR PLACE
        GROSVENOR ROAD
        GROSVENOR ROAD
        GROSVENOR SQUARE
        GROSVENOR VILLAS
        GROVE AVENUE
        GROVE AVENUE
        GROVE COURT
        GROVE LANE
        GROVE PARK
        GROVE PARK AVENUE
        GROVE PARK CRESCENT
        GROVE PARK DRIVE
        GROVE PARK ROAD
        GROVE ROAD
        GROVE ROAD
        GROVE WOOD
        GUILD STREET
        GUILDFORD PLACE
        GULISTAN COTTAGES
        GULISTAN PLACE
        GULISTAN TERRACE
        GURTEEN AVENUE
        GURTEEN PARK
        GURTEEN ROAD
        HADDINGTON PLACE
        HADDINGTON ROAD
        HADDON PARK
        HADDON ROAD
        HAGAN'S COURT
        HALLIDAY ROAD
        HALLIDAY SQUARE
        HALPIN'S ROW
        HALSTON STREET
        HALSTON STREET
        HAMILTON COURT
        HAMILTON ROW
        HAMILTON STREET
        HAMMOND LANE
        HAMMOND STREET
        HAMPSTEAD AVENUE
        HAMPSTEAD COURT
        HAMPSTEAD PARK
        HAMPTON COURT
        HAMPTON GREEN
        HANBURY LANE
        HANNAVILLE PARK
        HANOVER LANE
        HANOVER LANE
        HANOVER QUAY
        HANOVER QUAY
        HANOVER SQUARE
        HANOVER STREET EAST
        HANOVER STREET EAST
        HANOVER STREET WEST
        HANOVER STREET WEST
        HARBOUR COURT
        HARBOURMASTER PLACE
        HARBOURMASTER STREET
        HARCOURT LANE
        HARCOURT ROAD
        HARCOURT ROW
        HARCOURT STREET
        HARCOURT STREET
        HARCOURT STREET
        HARCOURT TERRACE
        HARCOURT TERRACE LANE
        HARDEBECK AVENUE
        HARDIMAN ROAD
        HARDWICKE LANE
        HARDWICKE PLACE
        HARDWICKE STREET
        HARMAN STREET
        HARMONSTOWN ROAD
        HARMONSTOWN ROAD
        HARMONSTOWN ROAD
        HARMONY AVENUE
        HARMONY ROW
        HAROLD'S CROSS COTTAGES
        HAROLD ROAD
        HAROLD'S CROSS ROAD
        HAROLD'S CROSS ROAD
        HAROLDVILLE AVENUE
        HARRINGTON COURT
        HARRINGTON STREET
        HARRISON ROW
        HARRY STREET
        HARTY AVENUE
        HARTY COURT
        HARTY COURT
        HARTY PLACE
        HASTINGS STREET
        HATCH LANE
        HATCH PLACE
        HATCH STREET LOWER
        HATCH STREET UPPER
        HATTER'S LANE
        HAVELOCK PLACE
        HAVELOCK SQUARE
        HAVELOCK SQUARE
        HAVELOCK TERRACE
        HAVERTY ROAD
        HAWKINS STREET
        HAWTHORN AVENUE
        HAWTHORN TERRACE
        HAYMARKET
        HAZEL PARK
        HAZEL ROAD
        HAZELBROOK DRIVE
        HAZELBROOK ROAD
        HAZELCROFT GARDENS
        HAZELCROFT PARK
        HAZELCROFT ROAD
        HAZELWOOD COURT
        HAZELWOOD DRIVE
        HAZELWOOD GROVE
        HAZELWOOD PARK
        HEALTHFIELD ROAD
        HEALY STREET
        HENDRICK LANE
        HENDRICK PLACE
        HENDRICK STREET
        HENRIETTA LANE
        HENRIETTA PLACE
        HENRIETTA PLACE
        HENRIETTA STREET
        HENRY PLACE
        HENRY STREET
        HERBERT AVENUE
        HERBERT COTTAGES
        HERBERT LANE
        HERBERT PARK
        HERBERT PARK
        HERBERT PARK LANE
        HERBERT PLACE
        HERBERT PLACE
        HERBERT ROAD
        HERBERT STREET
        HERBERTON DRIVE
        HERBERTON PARK
        HERBERTON BRIDGE
        HERBERTON ROAD
        HERBERTON ROAD
        HEUSTON SQUARE
        HEYTESBURY LANE
        HEYTESBURY STREET
        ROYAL HIBERNIAN WAY
        HIBERNIAN AVENUE
        HIGH PARK
        HIGH STREET
        HIGHFIELD GROVE
        HIGHFIELD ROAD
        HIGHFIELD ROAD
        HILL STREET
        HILLCREST PARK
        HOEY'S COURT
        HOGAN AVENUE
        HOGAN COURT
        HOGAN PLACE
        HOLLES PLACE
        HOLLES ROW
        HOLLES STREET
        HOLLY ROAD
        HOLLYBANK AVENUE LOWER
        HOLLYBANK AVENUE UPPER
        HOLLYBANK ROAD
        HOLLYBROOK COURT DRIVE
        HOLLYBROOK GROVE
        HOLLYBROOK PARK
        HOLLYBROOK ROAD
        HOLYCROSS AVENUE
        HOLYCROSS COTTAGES
        HOLYROOD PARK
        HOLYWELL AVENUE
        HOLYWELL CRESCENT
        HOLYWELL ROAD
        HOME VILLAS
        HOME FARM PARK
        HOME FARM ROAD
        HOMELEE
        HOPE AVENUE
        HOPE STREET
        HOSPITAL LANE
        HOTEL YARD
        HOWARD STREET
        HOWTH JUNCTION COTTAGES
        HOWTH ROAD
        HOWTH ROAD
        HOWTH ROAD
        HOWTH VIEW PARK
        HUBAND BRIDGE
        HUBAND ROAD
        HUGHES ROAD EAST
        HUGHES ROAD NORTH
        HUGHES ROAD SOUTH
        HUME STREET
        HUXLEY CRESCENT
        HYACINTH STREET
        IMAAL ROAD
        INAGH ROAD
        INCHICORE PARADE
        INCHICORE ROAD
        INCHICORE SQUARE EAST
        INCHICORE SQUARE NORTH
        INCHICORE SQUARE SOUTH
        INCHICORE SQUARE WEST
        INCHICORE TERRACE NORTH
        INCHICORE TERRACE SOUTH
        INFIRMARY ROAD
        INGRAM ROAD
        INNISFALLEN PARADE
        INISHMAAN ROAD
        INNS QUAY
        INVER ROAD
        INVERMORE GROVE
        INVERNESS ROAD
        IONA CRESCENT
        IONA DRIVE
        IONA PARK
        IONA ROAD
        IONA VILLAS
        IRISHTOWN LANE
        IRISHTOWN ROAD
        IRVINE COTTAGES
        IRVINE TERRACE
        IRWIN COURT
        IRWIN STREET
        ISLAND STREET
        ISLAND VILLA
        ISOLDA ROAD
        IVAR STREET
        IVEAGH GARDENS
        IVEAGH GARDENS
        IVELEARY ROAD
        IVERAGH ROAD
        IVERAGH ROAD
        IVY TERRACE
        "JAMES'S STREET
        JAMES'S STREET"
        JAMES LARKIN ROAD
        JAMES'S PLACE EAST
        JAMES STREET EAST
        JAMES STREET NORTH
        JAMESTOWN AVENUE
        JAMESTOWN COURT
        JAMESTOWN INDUSTRIAL CENTRE
        JAMESTOWN ROAD
        JAMESTOWN ROAD
        JANEVILLE
        JEROME CONNOR PLACE
        JERVIS LANE LOWER
        JERVIS STREET
        JOHN DILLON STREET
        JOHN FIELD ROAD
        JOHN MC CORMACK BRIDGE
        JOHN MCCORMACK AVENUE
        SAINT JOHN'S STREET
        JOHN STREET NORTH
        JOHN STREET WEST
        JOHN'S LANE WEST
        JOHN STREET SOUTH
        JOHNS LANE EAST
        JOHNSON'S COURT
        JOHNSON'S PLACE
        JOHNSTOWN PARK
        JONES'S ROAD
        JONES'S ROAD
        JOSEPHINE AVENUE
        JOY STREET
        JOYCE ROAD
        KANES COURT
        KEARN'S PLACE
        KEEGANS COTTAGES
        KEEPER ROAD
        KEEPER ROAD
        KELLS ROAD
        KELLY'S LANE
        KELLYS ROW
        KELLYS ROW
        KEMPTON AVENUE
        KEMPTON COURT
        KEMPTON GREEN
        KEMPTON GROVE
        KEMPTON HEATH
        KEMPTON LAWN
        KEMPTON PARK
        KEMPTON RISE
        KEMPTON VIEW
        KEMPTON WAY
        KENILWORTH LANE
        KENILWORTH PARK
        KENILWORTH PARK
        KENILWORTH ROAD
        KENILWORTH SQUARE EAST
        KENILWORTH SQUARE NORTH
        KENILWORTH SQUARE SOUTH
        KENILWORTH SQUARE WEST
        KENMARE PARADE
        KERLOGUE ROAD
        KEVIN STREET LOWER
        KEVIN STREET UPPER
        KICKHAM ROAD
        KILBARRACK AVENUE
        KILBARRACK GARDENS
        KILBARRACK GROVE
        KILBARRACK ROAD
        KILBARRON AVENUE
        KILBARRON DRIVE
        KILBARRON PARK
        KILBARRON ROAD
        KILBARRON ROAD
        KILBRIDE ROAD
        KILDARE PARK
        KILDARE PLACE
        KILDARE ROAD
        KILDARE ROAD
        KILDARE ROAD
        KILDARE STREET
        KILDONAN AVENUE
        KILDONAN DRIVE
        KILDONAN ROAD
        KILDONAN ROAD
        KILFENORA DRIVE
        KILFENORA ROAD
        KILKIERAN ROAD
        KILKIERAN COURT
        KILLALA ROAD
        KILLALA ROAD
        KILLAN ROAD
        KILLARNEY AVENUE
        KILLARNEY PARADE
        KILLARNEY STREET
        KILLARY GROVE
        KILLEEN ROAD
        KILLEEN ROAD
        KILLESTER AVENUE
        KILLESTER AVENUE
        KILLESTER AVENUE
        KILLESTER COURT
        KILLESTER PARK
        KILMAINHAM LANE
        KILMORE AVENUE
        KILMORE CLOSE
        KILMORE CRESCENT
        KILMORE DRIVE
        KILMORE DRIVE
        KILMORE ROAD
        KILMORE ROAD
        KILMORE ROAD
        KILMORE ROAD
        KILMORONEY CLOSE
        KILNAMANAGH ROAD
        KILSHANE ROAD
        KILSHANE ROAD
        KILWORTH ROAD
        KIMMAGE GROVE
        KIMMAGE ROAD LOWER
        KIMMAGE ROAD LOWER
        KIMMAGE ROAD WEST
        KINAHAN STREET
        KINCORA AVENUE
        KINCORA COURT
        KINCORA DRIVE
        KINCORA GROVE
        KINCORA PARK
        KINCORA ROAD
        KING STREET NORTH
        KING STREET NORTH
        KINGRAM PLACE
        KINGS AVENUE
        KINGS INNS STREET
        KINGS INNS STREET
        KINGSBRIDGE
        KINGSLAND PARADE
        KINVARA AVENUE
        KINVARA DRIVE
        KINVARA GROVE
        KINVARA PARK
        KINVARA ROAD
        KIPPURE PARK
        KIRWAN STREET
        KIRWAN STREET COTTAGES
        KNOCKNAREA AVENUE
        KNOCKNAREA ROAD
        KNOWTH COURT
        KYLEMORE AVENUE
        KYLEMORE DRIVE
        KYLEMORE PARK NORTH
        KYLEMORE PARK SOUTH
        KYLEMORE PARK WEST
        KYLEMORE ROAD
        KYLEMORE ROAD
        KYLEMORE ROAD
        LA TOUCHE BRIDGE
        LA TOUCHE COURT
        LA TOUCHE DRIVE
        LA TOUCHE ROAD
        LA TOUCHE ROAD
        LAD LANE
        LADYS LANE
        LAGAN ROAD
        LAKELANDS PARK
        LALLY ROAD
        LALLY ROAD
        LAMB ALLEY
        LAMBAY ROAD
        LANDEN ROAD
        LANDEN ROAD
        LANGRISHE PLACE
        LANSDOWNE LANE
        LANSDOWNE PARK
        LANSDOWNE PARK
        LANSDOWNE ROAD
        LANSDOWNE ROAD
        LANSDOWNE ROAD
        LANSDOWNE VALLEY
        LANDSDOWNE VALLEY PARK
        LANSDOWNE VILLAGE
        LARACOR GARDENS
        LARAGH CLOSE
        LARAGH GROVE
        LARCH GROVE
        LARKFIELD AVENUE
        LARKFIELD GARDENS
        LARKFIELD GROVE
        LARKFIELD PARK
        LARKHILL ROAD
        LARKHILL ROAD
        LAUNDRY LANE
        LAURELTON
        LAVARNA GROVE
        LAVARNA ROAD
        LAVERTY COURT
        LAVISTA AVENUE
        LAWRENCE GROVE
        LE FANU DRIVE
        LE FANU ROAD
        LE FANU ROAD
        LE VERE TERRACE
        LEA CRESCENT
        LEA ROAD
        LEAHY'S TERRACE
        LEE ROAD
        LEESON CLOSE
        LEESON LANE
        LEESON PARK
        LEESON PARK AVENUE
        LEESON PLACE
        LEESON STREET LOWER
        LEESON STREET UPPER
        LEESON VILLAGE
        LEICESTER AVENUE
        LEIGHLIN ROAD
        LEIN GARDENS
        LEIN GARDENS
        LEIN PARK
        LEIN ROAD
        LEINSTER AVENUE
        LANSDOWNE HALL
        LEINSTER LANE
        LEINSTER MARKET
        LEINSTER PLACE
        LEINSTER ROAD
        LEINSTER ROAD WEST
        LEINSTER SQUARE
        LEINSTER STREET EAST
        LEINSTER STREET NORTH
        LEINSTER STREET SOUTH
        LEITRIM PLACE
        LEIX ROAD
        LEMON STREET
        LENNON'S COTTAGES
        LENNOX PLACE
        LENNOX STREET
        LENNOX TERRACE
        LENTISK LAWN
        LEO AVENUE
        LEO STREET
        LESLIE'S BUILDINGS
        LEUKOS ROAD
        LIBERTY LANE
        LIFFEY STREET LOWER
        LIFFEY STREET SOUTH
        LIFFEY STREET WEST
        LIME STREET
        LIMEKILN LANE
        LIMEWOOD AVENUE
        LIMEWOOD PARK
        LIMEWOOD ROAD
        LINCOLN LANE
        LINCOLN PLACE
        LINDSAY ROAD
        LINENHALL PARADE
        LINENHALL STREET
        LINENHALL TERRACE
        LISBURN STREET
        LISCANNOR ROAD
        LISLE ROAD
        LISMEEN GROVE
        LISMORE ROAD
        LISSADEL AVENUE
        LISSADEL COURT
        LISSADEL DRIVE
        LISSADEL ROAD
        LITTON LANE
        LOFTUS LANE
        LOMBARD COURT
        LOMBARD STREET EAST
        LOMBARD STREET WEST
        LOMOND AVENUE
        LONDONBRIDGE DRIVE
        LONDONBRIDGE ROAD
        LONG LANE
        LONG LANE
        LONG LANE CLOSE
        LONG MILE ROAD
        LONGFORD LANE
        LONGFORD STREET GREAT
        LONGFORD STREET LITTLE
        LONG'S PLACE
        LONGWOOD AVENUE
        LORCAN AVENUE
        LORCAN CRESCENT
        LORCAN DRIVE
        LORCAN GREEN
        LORCAN GROVE
        LORCAN O'TOOLE PARK
        LORCAN O'TOOLE PARK
        LORCAN PARK
        LORCAN ROAD
        LORCAN VILLAS
        LORD EDWARD STREET
        LORD MAYORS WALK
        LORETO ROAD
        LOTTS
        LOUGH CONN AVENUE
        LOUGH CONN DRIVE
        LOUGH CONN ROAD
        LOUGH CONN TERRACE
        LOUGH DERG ROAD
        LOUIS LANE
        LOURDES ROAD
        LOVE LANE EAST
        LOVE LANE NORTH
        LUBY ROAD
        LUCAN ROAD
        LUKE KELLY BRIDGE
        LUKE STREET
        LULLYMORE TERRACE
        LURGAN STREET
        LYNCH'S PLACE
        "LYNCH'S LANE
        LYNCH'S LANE, 
        LYNCH'S LANE, 
        LYNCH'S LANE, 
        Lynchs Lane"
        "LYNCH'S LANE
        LYNCH'S LANE, 
        LYNCH'S LANE, 
        LYNCH'S LANE, 
        Lynchs Lane"
        LYNDON GATE
        MABBOT LANE
        MABEL STREET
        MC MORROUGH ROAD
        MACKEN STREET
        MACKEN STREET
        MACKIES PLACE
        MACROOM AVENUE
        MACROOM ROAD
        MACROOM ROAD
        MADISON ROAD
        MAGENNIS PLACE
        MAGENNIS PLACE
        MAGENNIS SQUARE
        MAGENTA CRESCENT
        MAGENTA HALL
        MAIDEN ROW
        MAIN STREET
        MAIN STREET
        MALACHI PLACE
        MALACHI ROAD
        MALAHIDE ROAD
        OLD MALAHIDE ROAD
        OLD MALAHIDE ROAD
        MALLIN AVENUE
        GROVE AVENUE
        MALONE GARDENS
        MALPAS PLACE
        MALPAS STREET
        MALPAS TERRACE
        MANDERS TERRACE
        MANGERTON ROAD
        MANNIX ROAD
        MANOR DRIVE
        MANOR PLACE
        MANOR STREET
        MAOLBUILLE ROAD
        MAPLE DRIVE
        MAQUAY BRIDGE
        MARGARET PLACE
        MARGUERITE ROAD
        MARIGOLD AVENUE
        MARIGOLD COURT
        MARIGOLD CRESCENT
        MARIGOLD GROVE
        MARIGOLD PARK
        MARIGOLD ROAD
        MARINE DRIVE
        MARINO AVENUE
        MARINO COURT
        MARINO CRESCENT
        MARINO GREEN
        MARINO MART
        MARINO PARK
        MARINO PARK
        MARINO PARK AVENUE
        MARION VILLAS
        MARK STREET
        MARK STREET
        MARKET STREET SOUTH
        MARK'S ALLEY WEST
        MARK'S LANE
        MARLBOROUGH CLOSE
        MARLBOROUGH LANE
        MARLBOROUGH MEWS
        MARLBOROUGH PLACE
        MARLBOROUGH ROAD
        MARLBOROUGH ROAD
        MARLBOROUGH STREET
        MARLBOROUGH STREET
        MARMION COURT
        MARNE VILLAS
        MARROWBONE LANE
        MARROWBONE LANE CLOSE
        MARSHAL LANE
        MARSHALSEA LANE
        MARTELLO WOOD
        MARTIN SAVAGE PARK
        MARTIN STREET
        MARTIN'S ROW
        MARY STREET
        MARY STREET LITTLE
        MARYFIELD AVENUE
        MARYFIELD CRESCENT
        MARYFIELD DRIVE
        MARYFIELD WOODS
        MARY'S ABBEY
        MARY'S LANE
        MARYVILLE ROAD
        MASK AVENUE
        MASK CRESCENT
        MASK DRIVE
        MASK GREEN
        MASK ROAD
        MATT TALBOT MEMORIAL BRIDGE
        MAUNSELL PLACE
        MAXWELL COURT
        MAXWELL LANE
        MAXWELL ROAD
        MAXWELL STREET
        MAY LANE
        MAY LANE
        MAY STREET
        MAYFIELD ROAD
        MAYFIELD ROAD
        MAYFIELD ROAD EAST
        MAYOR STREET LOWER
        MAYOR STREET UPPER
        MAYOR STREET UPPER
        MAYWOOD AVENUE
        MAYWOOD CLOSE
        MAYWOOD CRESCENT
        MAYWOOD DRIVE
        MAYWOOD GROVE
        MAYWOOD LAWN
        MAYWOOD PARK
        MAYWOOD ROAD
        MC AULEY AVENUE
        MC AULEY DRIVE
        MC AULEY PARK
        MC AULEY PARK
        MC AULEY ROAD
        MC AULEY ROAD
        SAINT PETER'S AVENUE
        MC DOWELL AVENUE
        MC DOWELL AVENUE
        MCGUINNESS COTTAGES
        MCKEE AVENUE
        MCKEE AVENUE
        MCKEE PARK
        MC KEE ROAD
        MC KEE ROAD
        MC KELVEY AVENUE
        MC KELVEY AVENUE
        MC KELVEY ROAD
        MC KENNY BRIDGE
        MC MAHON STREET
        MEADE'S TERRACE
        MEADOWBANK
        MEADOWBANK
        MEATH MARKET
        MEATH PLACE
        MEATH SQUARE
        MEATH STREET
        MEETING HOUSE SQUARE
        MEETINGHOUSE LANE
        MELLOWES AVENUE
        MELLOWES BRIDGE
        MELLOWES CRESCENT
        MELLOWES PARK
        MELLOWES COURT
        MELLOWES ROAD
        MELROSE AVENUE
        MELVIN ROAD
        MEMORIAL ROAD
        MEMORIAL ROAD
        MERCER STREET LOWER
        MERCER STREET UPPER
        MERCHANT'S ARCH
        MERCHANTS QUAY
        MERCHANTS ROAD
        MERLYN DRIVE
        MERLYN PARK
        MERLYN ROAD
        MERRION CLOSE
        MERRION COURT
        MERRION PLACE
        MERRION ROAD
        MERRION ROAD
        MERRION ROW
        MERRION SQUARE EAST
        MERRION SQUARE NORTH
        MERRION SQUARE SOUTH
        MERRION SQUARE WEST
        MERRION STRAND
        MERRION STREET LOWER
        MERRION STREET UPPER
        MERRION VIEW AVENUE
        MERRION VILLAGE
        MERTON AVENUE
        MERTON AVENUE
        MERTON DRIVE
        MERTON DRIVE
        MERTON PARK
        MERTON ROAD
        MERTON ROAD
        MERVILLE AVENUE
        MESPIL ROAD
        MIDDLE THIRD
        MIDDLE THIRD
        MILITARY ROAD
        MILITARY ROAD
        MILL LANE
        MILL STREET
        MILLBOURNE AVENUE
        MILLBROOK AVENUE
        MILLBROOK DRIVE
        MILLBROOK GROVE
        MILLBROOK ROAD
        MILLBROOK ROAD
        MILLBROOK TERRACE
        MILLMOUNT AVENUE
        MILLMOUNT AVENUE
        MILLMOUNT PLACE
        MILLMOUNT TERRACE
        MILLMOUNT VILLAS
        MILLROSE ESTATE
        MILLTOWN PATH
        MILLTOWN ROAD
        MILLTOWN ROAD
        MILLWOOD COURT
        MILLWOOD PARK
        MILLWOOD VILLAS
        MISERY HILL
        MOATFIELD AVENUE
        MOATFIELD PARK
        MOATFIELD ROAD
        MOATVIEW AVENUE
        MOATVIEW AVENUE
        MOATVIEW COURT
        MOATVIEW DRIVE
        MOATVIEW DRIVE
        MOATVIEW GARDENS
        MOATVIEW GARDENS
        MOBHI COURT
        MOERAN ROAD
        MOIRA ROAD
        MOLAND PLACE
        MOLESWORTH PLACE
        MOLESWORTH STREET
        MOLYNEUX YARD
        MONASTERBOICE ROAD
        MONCK PLACE
        MONTAGUE COURT
        MONTAGUE LANE
        MONTAGUE PLACE
        MONTAGUE STREET
        MONTPELIER DRIVE
        MONTPELIER GARDENS
        MONTPELIER HILL
        MONTPELIER PARK
        MONTROSE AVENUE
        MONTROSE CLOSE
        MONTROSE COURT
        MONTROSE CRESCENT
        MONTROSE DRIVE
        MONTROSE GROVE
        MONTROSE PARK
        MOORE LANE
        MOORE STREET
        MOREHAMPTON LANE
        MOREHAMPTON ROAD
        MOREHAMPTON TERRACE
        MORGAN PLACE
        MORNING STAR AVENUE
        MORNING STAR ROAD
        MORNINGTON GROVE
        MORNINGTON ROAD
        MORNINGTON ROAD
        MORROGH TERRACE
        MOSS STREET
        MOUNT ARGUS AVENUE
        MOUNT ARGUS CLOSE
        MOUNT ARGUS COURT
        MOUNT ARGUS CRESCENT
        MOUNT ARGUS GREEN
        MOUNT ARGUS GROVE
        MOUNT ARGUS PARK
        MOUNT ARGUS ROAD
        MOUNT ARGUS TERRACE
        MOUNT ARGUS VIEW
        MOUNT ARGUS WAY
        MOUNT BROWN
        MOUNT DILLON COURT
        MOUNT DRUMMOND AVENUE
        MOUNT DRUMMOND COURT
        MOUNT DRUMMOND SQUARE
        MOUNT EDEN ROAD
        MOUNT OLIVE GROVE
        MOUNT OLIVE PARK
        MOUNT OLIVE ROAD
        MOUNT PROSPECT AVENUE
        MOUNT PROSPECT AVENUE
        MOUNT PROSPECT DRIVE
        MOUNT PROSPECT GROVE
        MOUNT PROSPECT LAWNS
        MOUNT PROSPECT PARK
        MOUNT STREET CRESCENT
        MOUNT STREET LOWER
        MOUNT STREET UPPER
        MOUNT TALLANT AVENUE
        MOUNT TALLANT AVENUE
        MOUNT TEMPLE ROAD
        MOUNTAIN VIEW AVENUE
        MOUNTAIN VIEW ROAD
        RUTLAND COURT
        MOUNTJOY LANE
        MOUNTJOY PARADE
        MOUNTJOY PLACE
        MOUNTJOY SQUARE EAST
        MOUNTJOY SQUARE NORTH
        MOUNTJOY SQUARE SOUTH
        MOUNTJOY SQUARE WEST
        MOUNTJOY STREET
        MOUNTJOY STREET MIDDLE
        MOUNTPLEASANT AVENUE LOWER
        MOUNTPLEASANT AVENUE UPPER
        OLD MOUNT PLEASANT
        MOUNTPLEASANT PARADE
        MOUNTPLEASANT PLACE
        MOUNTPLEASANT PLACE
        MOUNTPLEASANT SQUARE
        MOUNTPLEASANT TERRACE
        MOUNTPLEASANT VILLAS
        MOUNTSHANNON ROAD
        MOURNE ROAD
        MOURNE ROAD
        MOURNE ROAD
        MOYCULLEN ROAD
        MOY ELTA ROAD
        MOYLE ROAD
        MOYNE ROAD
        MUCKROSS PARADE
        MULLINAHACK
        MULROY ROAD
        MUNSTER STREET
        MURPHY'S LANE
        MURRAY COTTAGES
        MURTAGH ROAD
        MUSKERRY ROAD
        MYRA CLOSE
        MYRTLE STREET
        NAAS ROAD
        NAAS ROAD
        OLD NAAS ROAD
        NANIKIN AVENUE
        NASH STREET
        NASSAU STREET
        NAVAN ROAD
        NAVAN ROAD
        NEAGH ROAD
        NELSON STREET
        NEPHIN ROAD
        NEPHIN ROAD
        NERNEY'S COURT
        NEVILLE ROAD
        NEWGROVE ESTATE
        NEW IRELAND ROAD
        NEW ROAD
        NEW ROW
        NEW ROW SOUTH
        NEW ROW SQUARE
        NEW STREET GARDENS
        NEW STREET NORTH
        NEW STREET NORTH
        NEW STREET SOUTH
        NEWBRIDGE AVENUE
        NEWBRIDGE DRIVE
        NEWBRIDGE MEWS
        NEWBROOK AVENUE
        NEWBROOK ROAD
        NEWBROOK ROAD
        NEWBROOK ROAD
        NEWBURY AVENUE
        NEWBURY DRIVE
        NEWBURY ESTATE ROAD
        NEWBURY GROVE
        NEWBURY LAWNS
        NEWBURY PARK
        NEWBURY PARK
        NEWCOMEN AVENUE
        NEWCOMEN COURT
        NEWGRANGE ROAD
        NEWGROVE AVENUE
        NEWMARKET
        NEWMARKET STREET
        NEWPORT STREET
        NEWTOWN COTTAGES
        NEWTOWN DRIVE
        NIALL STREET
        NICHOLAS AVENUE
        NICHOLAS STREET
        NORE ROAD
        NORFOLK ROAD
        NORFOLK ROAD
        NORSEMAN PLACE
        NORTH ROAD
        NORTH ROAD
        NORTH STRAND ROAD
        NORTH STRAND ROAD
        NORTH WALL QUAY
        NORTH WALL QUAY
        NORTHBROOK AVENUE
        NORTHBROOK AVENUE LOWER
        NORTHBROOK AVENUE UPPER
        NORTHBROOK LANE
        NORTHBROOK ROAD
        NORTHBROOK TERRACE
        NORTHLAND DRIVE
        NORTHLAND GROVE
        NORTHUMBERLAND ROAD
        NORTHUMBERLAND ROAD
        NORTHUMBERLAND SQUARE
        NORTHWAY ESTATE
        NORTONS AVENUE
        NORWOOD PARK
        NOTTINGHAM STREET
        NUGGET COTTAGES
        NURNEY LAWN
        NUTLEY AVENUE
        NUTLEY LANE
        NUTLEY PARK
        NUTLEY ROAD
        NUTLEY SQUARE
        O'BRIEN ROAD
        O'BRIEN'S PLACE
        O'BRIENS TERRACE
        O'CAROLAN ROAD
        O'CONNELL AVENUE
        O'CONNELL BRIDGE
        O'CONNELL GARDENS
        O'CONNELL STREET LOWER
        O'CONNELL STREET UPPER
        O'CURRY AVENUE
        O'CURRY ROAD
        O'DALY ROAD
        O'DEVANEY GARDENS
        O'DEVANEY GARDENS
        O'DONOGHUE STREET
        O'DONOVAN ROAD
        O'DWYER ROAD
        O'HARA AVENUE
        O'HOGAN ROAD
        O'LEARY ROAD
        O'MOORE ROAD
        O'NEACHTAIN ROAD
        O'NEILL'S BUILDINGS
        QUINN AVENUE
        O'RAHILLY PARADE
        O'REILLY AVENUE
        O'REILLY AVENUE
        OAK ROAD
        OAKFIELD PLACE
        OAKLANDS CRESCENT
        OAKLANDS DRIVE
        OAKLANDS DRIVE
        OAKLANDS DRIVE
        OAKLANDS DRIVE
        OAKLANDS PARK
        OAKLANDS TERRACE
        OAKLEY PARK
        OAKLEY ROAD
        OAKPARK AVENUE
        OAKPARK CLOSE
        OAKPARK DRIVE
        OAKPARK GROVE
        OAKWOOD AVENUE
        OAKWOOD CLOSE
        OAKWOOD PARK
        OAKWOOD ROAD
        OBLATE DRIVE
        OBLATE DRIVE
        OBSERVATORY LANE
        OFFALY ROAD
        OLAF ROAD
        OLD CABRA ROAD
        OLD CABRA ROAD
        OLD COUNTY GLEN
        OLD FINGLAS ROAD
        OLD FINGLAS ROAD
        OLD KILMAINHAM
        OLDTOWN AVENUE
        OLDTOWN PARK
        OLDTOWN ROAD
        OLIVER ALLEY
        OLIVER BOND STREET
        OLIVER PLUNKETT AVENUE
        OLNEY CRESCENT
        OLNEY GROVE
        ONTARIO TERRACE
        ORANMORE CLOSE
        ORANMORE ROAD
        ORANMORE ROAD
        ORCHARD LANE
        ORCHARD LAWNS
        ORCHARD ROAD
        ORCHARD ROAD
        ORCHARD ROAD SOUTH
        ORIEL STREET LOWER
        ORIEL STREET UPPER
        ORMEAU STREET
        ORMOND PLACE
        ORMOND QUAY LOWER
        ORMOND QUAY UPPER
        ORMOND ROAD
        ORMOND ROAD
        ORMOND SQUARE
        ORMOND STREET
        ORR'S TERRACE
        ORWELL PARK
        ORWELL ROAD
        OSCAR SQUARE
        OSCAR SQUARE
        OSCAR TRAYNOR ROAD
        OSSORY ROAD
        OSTMAN PLACE
        O'SULLIVAN AVENUE
        OSWALD ROAD
        OULTON ROAD
        OUR LADY'S ROAD
        OVOCA ROAD
        OWEN'S AVENUE
        OXFORD ROAD
        OXMANTOWN LANE
        OXMANTOWN ROAD
        OLD MILL COURT
        PALACE STREET
        PALMERSTON CLOSE
        PALMERSTON COURT
        PALMERSTON GARDENS
        PALMERSTON GROVE
        PALMERSTON LANE
        PALMERSTON PARK
        PALMERSTON PARK
        PALMERSTON PLACE
        PALMERSTON ROAD
        PALMERSTON VILLAS
        PARADISE PLACE
        PARK AVENUE
        PARK AVENUE WEST
        PARK CRESCENT
        PARK DRIVE
        PARK LANE
        PARK LANE
        PARK LANE EAST
        PARK LANE EAST
        PARK LAWN
        PARK ROAD
        PARK STREET WEST
        PARK TERRACE
        PARK VIEW WEST
        PARKER HILL
        PARKGATE STREET
        PARKGATE STREET
        PARKMORE DRIVE
        PARKVIEW AVENUE
        PARKVIEW PLACE
        PARLIAMENT ROW
        PARLIAMENT STREET
        PARNELL AVENUE
        PARNELL BRIDGE
        PARNELL COURT
        PARNELL PLACE
        PARNELL ROAD
        PARNELL SQUARE EAST
        PARNELL SQUARE NORTH
        PARNELL SQUARE WEST
        PARNELL STREET
        PARNELL STREET
        PARTRIDGE TERRACE
        PARTRIDGE TERRACE
        PATRICK STREET
        PATRICKSWELL PLACE
        PATRICKSWELL PLACE
        PAUL STREET
        PEARSE GROVE
        PEARSE GROVE
        PEARSE SQUARE
        PEARSE STREET
        PEARSE STREET
        PEARSE STREET
        PEMBROKE COTTAGES
        PEMBROKE COTTAGES
        PEMBROKE GARDENS
        PEMBROKE LANE
        PEMBROKE LANE
        PEMBROKE LANE
        PEMBROKE PARK
        PEMBROKE PLACE
        PEMBROKE PLACE
        PEMBROKE ROAD
        PEMBROKE ROAD
        PEMBROKE ROW
        PEMBROKE STREET
        PEMBROKE STREET LOWER
        PEMBROKE STREET UPPER
        PENROSE STREET
        PERCY FRENCH ROAD
        PERCY LANE
        PERCY PLACE
        PETER STREET
        PETER ROW
        PETER PLACE
        PETERSONS COURT
        PETRIE ROAD
        PHIBSBOROUGH
        PHIBSBOROUGH AVENUE
        PHIBSBOROUGH AVENUE
        PHIBSBOROUGH PLACE
        PHIBSBOROUGH PLACE
        PHIBSBOROUGH ROAD
        PHILIPSBURGH AVENUE
        PHILIPSBURGH TERRACE
        PHILOMENA TERRACE
        PHOENIX STREET NORTH
        PHOENIX STREET WEST
        PIG LANE
        PIGEON HOUSE ROAD
        PIGEON HOUSE ROAD
        PIM STREET
        PIMLICO
        PIMLICO COTTAGES
        PINE ROAD
        PINEBROOK AVENUE
        PINEBROOK CRESCENT
        PINEBROOK DRIVE
        PINEBROOK GROVE
        PINEBROOK RISE
        PINEBROOK ROAD
        PINE HURST
        PINEWOOD AVENUE
        PINEWOOD CRESCENT
        PINEWOOD DRIVE
        PINEWOOD GREEN
        PINEWOOD GROVE
        PINEWOOD VILLAS
        PLEASANTS LANE
        PLEASANTS PLACE
        PLEASANTS STREET
        PLUNKETT AVENUE
        PLUNKETT AVENUE
        PLUNKETT CRESCENT
        PLUNKETT DRIVE
        PLUNKETT GREEN
        PLUNKETT GREEN
        PLUNKETT GROVE
        PLUNKETT ROAD
        PLUNKETT ROAD
        PODDLE PARK
        POOLBEG STREET
        POOLBEG STREET
        POOLE STREET
        POPLAR ROW
        BALBUTCHER LANE
        PORTSIDE COURT
        PORTLAND CLOSE
        PORTLAND COURT
        PORTLAND PLACE
        PORTLAND ROW
        PORTLAND SQUARE
        PORTLAND STREET WEST
        PORTLAND STREET NORTH
        PORTMAHON DRIVE
        PORTOBELLO HARBOUR
        PORTOBELLO ROAD
        PORTOBELLO ROAD
        POWER'S SQUARE
        POWER'S COURT
        PREBEND STREET
        PRESTON STREET
        PRICES LANE
        PRICE'S LANE
        PRIESTFIELD COTTAGES
        PRIESTFIELD DRIVE
        PRIMROSE AVENUE
        PRIMROSE STREET
        PRINCE ARTHUR TERRACE
        PRINCE OF WALES TERRACE
        PRINCE'S STREET NORTH
        PRINCE'S STREET NORTH
        PRINCE'S STREET SOUTH
        PRIORSWOOD ROAD
        PRIORY EAST
        PRIORY NORTH
        PRIORY ROAD
        PRIORY ROAD
        PRIORY WEST
        PROBY'S LANE
        PROSPECT AVENUE
        PROSPECT LANE
        PROSPECT ROAD
        PROSPECT SQUARE
        PROSPECT WAY
        PROTESTANT ROW
        PROUD'S LANE
        PROUD'S LANE
        PRUSSIA STREET
        PUMP ALLEY
        PURSER GARDENS
        PYRO VILLAS
        QUARRY ROAD
        QUARRY ROAD
        QUEEN STREET
        QUINNS LANE
        RAFTERS LANE
        RAFTERS LANE
        RAFTERS ROAD
        RAFTERS ROAD
        RAGLAN LANE
        RAGLAN ROAD
        RAHEEN DRIVE
        RAHEEN PARK
        RAHENY COURT
        HOWTH ROAD
        RAHENY PARK
        RAHENY ROAD
        RAILWAY AVENUE
        RAILWAY AVENUE
        RAILWAY COTTAGES
        RAILWAY STREET
        RAILWAY TERRACE
        RAINSFORD AVENUE
        RAINSFORD STREET
        RALEIGH SQUARE
        RAMILLIES ROAD
        RAMLEH CLOSE
        RAMLEH PARK
        RAMPART LANE
        RANELAGH
        RANELAGH AVENUE
        RANELAGH AVENUE
        RANELAGH ROAD
        RAPHOE ROAD
        RATHDOWN AVENUE
        RATHDOWN COURT
        RATHDOWN CRESCENT
        RATHDOWN DRIVE
        RATHDOWN PARK
        RATHDOWN PARK
        RATHDOWN ROAD
        RATHDOWN VILLAS
        RATHDRUM ROAD
        RATHFARNHAM ROAD
        RATHGAR AVENUE
        RATHGAR PARK
        RATHGAR PLACE
        RATHGAR ROAD
        RATHLIN ROAD
        RATHMINES AVENUE
        RATHMINES CLOSE
        RATHMINES PARK
        RATHMINES ROAD LOWER
        RATHMINES ROAD UPPER
        RATHMORE PARK
        RATHMORE VILLAS
        RATHVALE AVENUE
        RATHVALE DRIVE
        RATHVALE GROVE
        RATHVALE PARK
        RATHVILLY DRIVE
        RATHVILLY PARK
        RATHVILLY ROAD
        RATOATH AVENUE
        RATOATH DRIVE
        RATOATH ESTATE
        RATOATH ROAD
        RATOATH ROAD
        RATOATH ROAD
        RATRA PARK
        RATRA ROAD
        RAVENSDALE CLOSE
        RAVENSDALE DRIVE
        RAVENSDALE PARK
        RAVENSDALE ROAD
        RAVENSDALE ROAD
        RAYMOND STREET
        RED COW LANE
        REDMOND'S HILL
        RIBH AVENUE
        RIBH ROAD
        REGINALD SQUARE
        REGINALD STREET
        REHOBOTH AVENUE
        REHOBOTH PLACE
        REILLY'S AVENUE
        REILLYS COTTAGES
        REUBEN AVENUE
        REUBEN STREET
        RIALTO BUILDINGS
        RIALTO DRIVE
        RIALTO PARK
        RIALTO STREET
        RICHELIEU PARK
        RICHMOND AVENUE
        RICHMOND AVENUE SOUTH
        RICHMOND AVENUE SOUTH
        RICHMOND COTTAGES
        RICHMOND CRESCENT
        RICHMOND ESTATE
        RICHMOND HILL
        RICHMOND LANE
        RICHMOND MEWS
        RICHMOND PARADE
        RICHMOND PLACE
        RICHMOND PLACE SOUTH
        RICHMOND ROAD
        RICHMOND ROW
        RICHMOND STREET NORTH
        RICHMOND STREET SOUTH
        RICHMOND VILLAS
        RICHVIEW PARK
        RING STREET
        RING TERRACE
        RINGSEND PARK
        RINGSEND ROAD
        RIVER ROAD
        RIVERSDALE AVENUE
        RIVERSDALE GROVE
        RIVERSIDE AVENUE
        RIVERSIDE CRESCENT
        RIVERSIDE DRIVE
        RIVERSIDE GROVE
        RIVERSIDE PARK
        RIVERSIDE ROAD
        ROBERT EMMET BRIDGE
        ROBERT PLACE
        ROBERT STREET
        ROBERT STREET
        ROCK LANE
        ROGER'S LANE
        ROOSEVELT COTTAGES
        ROPEWALK PLACE
        RORY O'MORE BRIDGE
        ROSARY ROAD
        ROSARY TERRACE
        ROSE GLEN AVENUE
        ROSECOURT WAY
        ROSEDALE TERRACE
        ROSEGLEN ROAD
        ROSEMOUNT AVENUE
        ROSEMOUNT ROAD
        ROSEVALE COURT
        ROSS ROAD
        ROSS ROAD
        ROSS STREET
        ROSS STREET
        ROSSMORE AVENUE
        ROSSMORE DRIVE
        ROSSMORE ROAD
        ROSTREVOR ROAD
        ROSTREVOR TERRACE
        ROSTREVOR TERRACE
        ROTHE ABBEY
        ROWSERSTOWN LANE
        ROYAL CANAL BANK
        ROYAL CANAL TERRACE
        ROYSE ROAD
        ROYSTON
        RUGBY ROAD
        RUGBY VILLAS
        RUGBY VILLAS
        RUSSELL AVENUE
        RUSSELL AVENUE EAST
        RUSSELL STREET
        RUTLAND AVENUE
        RUTLAND AVENUE
        RUTLAND COTTAGES
        RUTLAND GROVE
        RUTLAND PLACE NORTH
        RUTLAND PLACE
        RUTLAND PLACE
        RUTLAND STREET LOWER
        RUTLEDGE COTTAGES
        RUTLEDGE TERRACE
        RYANS COTTAGES
        RYDERS ROW
        SACKVILLE AVENUE
        SACKVILLE GARDENS
        SACKVILLE PLACE
        SAINT AGNES PARK
        SAINT AGNES PARK
        SAINT AGNES ROAD
        SAINT AGNES ROAD
        SAINT AIDAN'S PARK
        SAINT AIDAN'S PARK AVENUE
        SAINT AIDAN'S PARK ROAD
        SAINT ALBAN'S PARK
        SAINT ALBAN'S PARK
        SAINT ALBANS ROAD
        SAINT ALPHONSUS AVENUE
        SAINT ALPHONSUS ROAD LOWER
        SAINT ALPHONSUS ROAD UPPER
        SAINT ANDREW LANE
        SAINT ANDREW STREET
        SAINT ANNE'S COURT
        SAINT ANNE'S AVENUE
        SAINT ANNE'S DRIVE
        SAINT ANNE'S ROAD
        SAINT ANNE'S ROAD SOUTH
        SAINT ANNE'S TERRACE
        SAINT ANTHONY'S ROAD
        SAINT ANTHONY'S ROAD
        SAINT ASSAM'S AVENUE
        SAINT ASSAM'S DRIVE
        SAINT ASSAM'S PARK
        SAINT ASSAM'S ROAD EAST
        SAINT ASSAM'S ROAD WEST
        SAINT ATTRACTA ROAD
        SAINT AUDOENS ARCH
        SAINT AUDOEN'S TERRACE
        SAINT AUGUSTINE STREET
        SAINT AUGUSTINE STREET
        SAINT BARNABAS GARDENS
        SAINT BENEDICT'S GARDENS
        SAINT BRENDANS AVENUE
        SAINT BRENDAN'S COTTAGES
        SAINT BRENDANS DRIVE
        SAINT BRENDANS PARK
        SAINT BRENDANS ROAD
        SAINT BRENDANS TERRACE
        SAINT BRICIN'S PARK
        SAINT BRIGID'S AVENUE
        SAINT BRIGID'S COTTAGES
        SAINT BRIGIDS COURT
        SAINT BRIGID'S CRESCENT
        SAINT BRIGID'S DRIVE
        SAINT BRIGID'S ROAD
        SAINT BRIGID'S ROAD
        SAINT BRIGID'S ROAD LOWER
        SAINT BRIGID'S ROAD UPPER
        SAINT BROC'S COTTAGES
        SAINT CANICES PARK
        SAINT CANICES ROAD
        SAINT CANICES ROAD
        SAINT CATHERINE'S AVENUE
        SAINT CATHERINE'S LANE WEST
        SAINT CLARE'S AVENUE
        SAINT CLEMENTS ROAD
        SAINT COLUMBAS ROAD LOWER
        SAINT COLUMBAS ROAD UPPER
        SAINT DAVID'S PARK
        SAINT DAVID'S WOOD
        SAINT DAVIDS
        SAINT DAVID'S TERRACE
        SAINT DAVID'S TERRACE
        SAINT DECLAN'S ROAD
        SAINT DECLAN'S TERRACE
        SAINT DONAGH'S CRESCENT
        SAINT DONAGH'S PARK
        SAINT DONAGH'S ROAD
        SAINT EITHNE ROAD
        SAINT ENDAS ROAD
        SAINT FINBAR ROAD
        SAINT FINTAN ROAD
        SAINT FINTAN TERRACE
        SAINT FRANCIS SQUARE
        SAINT GABRIEL'S ROAD
        SAINT GEORGES AVENUE
        SAINT GEORGES VILLAS
        SAINT HELENA'S COURT
        SAINT HELENA'S DRIVE
        SAINT HELENA'S ROAD
        SAINT IGNATIUS AVENUE
        SAINT IGNATIUS ROAD
        SAINT ITA'S ROAD
        SAINT JAMES'S AVENUE
        SAINT JAMES'S AVENUE
        SAINT JAMES'S PLACE
        SAINT JAMES'S TERRACE
        SAINT JAMES'S TERRACE
        SAINT JAMES WALK
        SAINT JARLATH ROAD
        SAINT JOHNS
        SAINT JOHN'S AVENUE
        SAINT JOHNS ROAD
        SAINT JOHN'S ROAD WEST
        SAINT JOHNS WOOD
        SAINT JOSEPH'S AVENUE
        SAINT JOSEPH'S AVENUE
        SAINT JOSEPH'S PARADE
        SAINT JOSEPH'S PLACE
        SAINT JOSEPH'S PLACE
        SAINT JOSEPH'S ROAD
        SAINT JOSEPHS SQUARE
        SAINT JOSEPHS SQUARE
        SAINT JOSEPH STREET
        SAINT JOSEPHS TERRACE
        SAINT JOSEPHS TERRACE
        SAINT JOSEPHS VILLAS
        SAINT KEVIN'S AVENUE
        SAINT KEVIN'S COTTAGES
        SAINT KEVIN'S COTTAGES
        SAINT KEVIN'S GARDENS
        SAINT KEVIN'S GARDENS
        SAINT KEVIN'S PARADE
        SAINT KEVIN'S PARK
        SAINT KEVIN'S ROAD
        SAINT LAURENCE PLACE EAST
        SAINT LAURENCE PLACE
        SAINT LAURENCE ROAD
        SAINT LAURENCE ROAD
        SAINT LAWRENCE ROAD
        SAINT MAGDALEN TERRACE
        SAINT MALACHY ROAD
        SAINT MARGARET'S AVENUE
        SAINT MARGARETS AVENUE
        SAINT MARGARETS AVENUE
        SAINT MARGARET'S ROAD
        SAINT MARGARET'S ROAD
        SAINT MARGARET'S TERRACE
        SAINT MARTIN'S DRIVE
        SAINT MARTIN'S PARK
        SAINT MARY'S ROAD
        SAINT MARY'S AVENUE NORTH
        SAINT MARYS AVENUE WEST
        SAINT MARYS CRESCENT
        SAINT MARYS DRIVE
        SAINT MARY'S LANE
        SAINT MARYS PARK
        SAINT MARY'S PLACE NORTH
        SAINT MARY'S ROAD NORTH
        SAINT MARY'S ROAD
        SAINT MARY'S ROAD NORTH
        SAINT MARY'S TERRACE
        SAINT MARY'S TERRACE
        SAINT MICHAEL'S CLOSE
        SAINT MICHAELS HILL
        SAINT MICHAELS PLACE
        SAINT MICHAEL'S ROAD
        SAINT MICHAELS TERRACE
        SAINT MICHAN'S PLACE
        SAINT MICHAN'S STREET
        SAINT MOBHI BOITHIRIN
        SAINT MOBHI DRIVE
        SAINT MOBHI DRIVE
        SAINT MOBHI GROVE
        SAINT MOBHI ROAD
        SAINT NICHOLAS PLACE
        CHURCH LANE
        SAINT PAPPIN GREEN
        SAINT PAPPIN ROAD
        SAINT PAPPIN ROAD
        SAINT PAPPIN ROAD
        SAINT PATRICK'S PLACE
        SAINT PATRICK'S AVENUE
        SAINT PATRICK'S CLOSE
        SAINT PATRICK'S PARADE
        SAINT PATRICK'S ROAD
        SAINT PATRICK'S TERRACE
        SAINT PATRICK'S TERRACE
        SAINT PATRICK'S VILLAS
        SAINT PETER'S CLOSE
        SAINT PETERS COURT
        SAINT PETERS LANE
        SAINT PETERS ROAD
        SAINT PHILOMENA'S ROAD
        SAINT STEPHENS GREEN EAST
        SAINT STEPHENS GREEN NORTH
        SAINT STEPHENS GREEN NORTH
        SAINT STEPHENS GREEN SOUTH
        SAINT STEPHENS GREEN WEST
        SAINT TERESA PLACE
        SAINT TERESA'S ROAD
        SAINT TERESA ROAD
        SAINT TERESA'S LANE
        SAINT THOMAS ROAD
        THOMAS LANE
        SAINT VINCENT STREET NORTH
        SAINT VINCENT STREET WEST
        SALLYMOUNT AVENUE
        SALLYMOUNT GARDENS
        SALLYMOUNT TERRACE
        SAMPSONS LANE
        SIMPSONS LANE
        SANDFORD AVENUE
        SANDFORD AVENUE
        SANDFORD CLOSE
        SANDFORD GARDENS
        SANDFORD GARDENS
        SANDFORD PARK
        SANDFORD ROAD
        SANDFORD ROAD
        SANDFORD TERRACE
        SANDWITH STREET LOWER
        SANDWITH STREET UPPER
        SANDYHILL AVENUE
        SANDYHILL GARDENS
        SANDYMOUNT AVENUE
        SANDYMOUNT CASTLE DRIVE
        SANDYMOUNT CASTLE PARK
        SANDYMOUNT CASTLE ROAD
        SANDYMOUNT COURT
        SANDYMOUNT GREEN
        SANDYMOUNT GREEN
        SANDYMOUNT ROAD
        SANTRY AVENUE
        SANTRY BY-PASS
        SANTRY COURT
        SANTRY VILLAS
        SARSFIELD QUAY
        SARSFIELD ROAD
        SARSFIELD ROAD
        SARSFIELD STREET
        SAUL ROAD
        SCHOOL AVENUE
        SCHOOL STREET
        SCHOOLHOUSE LANE
        SCHOOLHOUSE LANE
        SCHOOLHOUSE LANE EAST
        SCHOOLHOUSE LANE WEST
        SCRIBBLESTOWN LANE
        SEACOURT ESTATE
        SEAFIELD AVENUE
        SEAFIELD AVENUE
        SEAFIELD DOWNS
        SEAFIELD GROVE
        SEAFIELD ROAD EAST
        SEAFIELD ROAD EAST
        SEAFIELD ROAD WEST
        SEAFORT AVENUE
        SEAFORT AVENUE
        SEAFORT COTTAGES
        SEAFORT GARDENS
        SEAFORT TERRACE
        SEAFORT TERRACE
        SEAFORT VILLAS
        SEAMUS ENNIS ROAD
        SEAN HEUSTON BRIDGE
        SEAN MAC DERMOTT STREET LOWER
        SEAN MAC DERMOTT STREET UPPER
        SEAN MOORE ROAD
        SEAN O' CASEY AVENUE
        SEAPARK DRIVE
        SEAPARK ROAD
        SEAPARK ROAD
        SEAVIEW AVENUE
        SEAVIEW AVENUE
        SEAVIEW AVENUE NORTH
        SEAVIEW TERRACE
        RIALTO COTTAGES-SECOND AVENUE
        SECOND AVENUE
        SELSKAR TERRACE
        SERPENTINE AVENUE
        SERPENTINE PARK
        SERPENTINE ROAD
        SERPENTINE TERRACE
        SETANTA PLACE
        SEVEN OAKS
        SEVEN OAKS
        RIALTO COTTAGES-SEVENTH AVENUE
        SEVILLE PLACE
        SEVILLE TERRACE
        SHAMROCK COTTAGES
        SHAMROCK PLACE
        SHAMROCK PLACE
        SHAMROCK STREET
        SHAMROCK TERRACE
        SHAMROCK VILLAS
        SHANARD AVENUE
        SHANARD AVENUE
        SHANARD ROAD
        SHANBOLEY ROAD
        SHANBOLEY ROAD
        SHANDON CRESCENT
        SHANDON DRIVE
        SHANDON GARDENS
        SHANDON PARK
        SHANDON PARK
        SHANDON ROAD
        SHANGAN AVENUE
        SHANGAN CRESCENT
        SHANGAN GARDENS
        SHANGAN GREEN
        SHANGAN PARK
        SHANGAN ROAD
        SHANGANAGH ROAD
        SHANGLAS ROAD
        SHANID ROAD
        SHANLISS AVENUE
        SHANLISS WAY
        SHANLISS DRIVE
        SHANLISS GARDENS
        SHANLISS GROVE
        SHANLISS PARK
        SHANLISS ROAD
        SHANLISS WALK
        SHANLISS WAY
        SHANNON TERRACE
        SHANOWEN AVENUE
        SHANOWEN CRESCENT
        SHANOWEN DRIVE
        SHANOWEN GROVE
        SHANOWEN PARK
        SHANOWEN ROAD
        SHANOWEN ROAD
        SHANRATH ROAD
        SHANTALLA AVENUE
        SHANTALLA DRIVE
        SHANTALLA PARK
        SHANTALLA ROAD
        SHANTALLA ROAD
        SHANTALLA ROAD
        SHANVARNA ROAD
        SHAW STREET
        SHAWS LANE
        SHELBOURNE AVENUE
        SHELBOURNE LANE
        SHELBOURNE ROAD
        SHELBOURNE VILLAGE
        SHELMALIER ROAD
        SHELMARTIN AVENUE
        SHELMARTIN TERRACE
        SHERIFF STREET LOWER
        SHERIFF STREET LOWER
        SHERIFF STREET UPPER
        SHERKIN GARDENS
        SHERRARD AVENUE
        SHERRARD COURT
        SHERRARD STREET LOWER
        SHERRARD STREET UPPER
        SHIP STREET GREAT
        SHIP STREET LITTLE
        SHREWSBURY PARK
        SHREWSBURY ROAD
        SIBTHORPE LANE
        SIGURD ROAD
        SILLOGE AVENUE
        SILLOGE GARDENS
        SILLOGE ROAD
        SIMMONS PLACE
        SIMMONSCOURT AVENUE
        SIMMONSCOURT ROAD
        SIMMONSCOURT TERRACE
        SION HILL AVENUE
        SION HILL ROAD
        SIR JOHN ROGERSON'S QUAY
        SIR JOHN ROGERSON'S QUAY
        SIR JOHN ROGERSON'S QUAY
        SITRIC PLACE
        SITRIC ROAD
        RIALTO COTTAGES-SIXTH AVENUE
        SKELLY'S LANE
        SKREEN ROAD
        SLADEMORE AVENUE
        SLADEMORE CLOSE
        SLADEMORE COURT
        SLADEMORE DRIVE
        SLANE ROAD
        SLANEY CLOSE
        SLANEY ROAD
        SLANEY ROAD
        SLEMISH ROAD
        SLIEVEBLOOM PARK
        SLIEVEBLOOM ROAD
        SLIEVEMORE ROAD
        SLIEVENAMON ROAD
        SLIEVENAMON ROAD
        SMITHFIELD
        SMITH'S COTTAGES
        SOMERSET STREET
        SOMERVILLE AVENUE
        SOMERVILLE DRIVE
        SOMERVILLE GREEN
        SOMERVILLE PARK
        SOUTH BANK ROAD
        SOUTH DOCK PLACE
        SOUTH DOCK ROAD
        SOUTH DOCK ROAD
        SOUTH DOCK STREET
        SOUTH HILL
        KING STREET SOUTH
        SOUTH LOTTS ROAD
        SOUTHERN CROSS AVENUE
        SOUTHERN CROSS AVENUE
        SPA ROAD
        SPAFIELD TERRACE
        SPENCER PLACE
        SPENCER ROW
        SPENCER STREET NORTH
        SPENCER STREET SOUTH
        SPERRIN ROAD
        SPIDDAL PARK
        SPIDDAL ROAD
        SPIDDAL ROAD
        SPIRE VIEW LANE
        SPIRE VIEW
        SPITALFIELDS
        SPRING GARDEN LANE
        SPRING GARDEN STREET
        SPRINGDALE ROAD
        SPRINGDALE ROAD
        SPRINGFIELD
        STABLE LANE
        STABLE LANE
        STABLE LANE
        STABLE LANE
        STAMER STREET
        STANNAWAY AVENUE
        STANNAWAY COURT
        STANNAWAY DRIVE
        STANNAWAY ROAD
        STANNAWAY ROAD
        STANFORD GREEN
        STANHOPE STREET
        STANLEY STREET
        STATION ROAD
        STEEVEN'S LANE
        STEPHEN STREET UPPER
        STEPHEN'S LANE
        STEPHEN'S LANE
        STEPHEN'S PLACE
        STEPHEN'S PLACE
        STEPHEN'S PLACE
        STEPHENS ROAD
        THE STILES ROAD
        STILLORGAN ROAD
        STIRRUP LANE
        STIRRUP LANE
        STOKES PLACE
        STONEY ROAD
        STONEYBATTER
        STONEYBATTER
        STORE STREET
        STORMANSTOWN ROAD
        STRAND LANE
        STRAND MEWS
        STRAND ROAD
        STRAND ROAD
        STRAND STREET
        STRAND STREET GREAT
        STRAND STREET LITTLE
        STRANDVILLE AVENUE
        STRANDVILLE AVENUE
        STRANDVILLE AVENUE EAST
        STRANDVILLE AVENUE EAST
        STRANDVILLE PLACE
        STRANGFORD GARDENS
        STRANGFORD ROAD EAST
        STRANGFORD ROAD EAST
        STRASBURG TERRACE
        STRATFORD ROW
        STREAMVILLE ROAD
        STREAMVILLE ROAD
        STRONG'S COURT
        SUFFOLK STREET
        SUIR BRIDGE
        SUIR ROAD
        SULLIVAN COTTAGES
        SULLIVAN STREET
        SUMMER ARCH
        SUMMER PLACE
        SUMMER STREET NORTH
        SUMMER STREET SOUTH
        SUMMER STREET SOUTH
        SUMMERHILL
        SUMMERHILL PARADE
        SUMMERHILL PLACE
        SUMMERVILLE PARK
        SUNBURY GARDENS
        SUNDRIVE PARK
        SUNDRIVE ROAD
        SUSAN TERRACE
        SUSANVILLE ROAD
        SUSSEX ROAD
        SUSSEX TERRACE
        SWAN ALLEY
        SWAN GROVE
        SWAN PLACE
        SWAN YARD
        SWANS NEST AVENUE
        SWANS NEST ROAD
        SWANVILLE PLACE
        SWANWARD COURT
        SWEENEY'S TERRACE
        SWIFT'S ALLEY
        SWIFT'S GROVE
        SWIFT'S ROW
        SWILLY ROAD
        SWORDS ROAD
        SWORDS ROAD
        SWORDS ROAD
        SWORDS STREET
        SYBIL HILL AVENUE
        SYBIL HILL ROAD
        SYCAMORE PARK
        SYCAMORE ROAD
        SYCAMORE ROAD
        SYCAMORE STREET
        SYDENHAM ROAD
        SYDNEY PARADE AVENUE
        SYDNEY PARADE AVENUE
        SYKE'S LANE
        SYNGE LANE
        SYNGE PLACE
        SYNGE STREET
        SYNNOTT PLACE
        SYNNOTT ROW
        TAAFFES PLACE
        TALBOT ARCH
        TALBOT LANE
        TALBOT PLACE
        TALBOT STREET
        TANGIER LANE
        TARA LAWN
        TARA STREET
        TAYLOR'S LANE
        TEMPLE BAR
        TEMPLE BAR SQUARE
        TEMPLE COTTAGES
        TEMPLE GARDENS
        TEMPLE LANE
        TEMPLE LANE NORTH
        TEMPLE LANE NORTH
        TEMPLE LANE SOUTH
        TEMPLE PARK
        TEMPLE PLACE
        TEMPLE ROAD
        TEMPLE STREET
        TEMPLE STREET WEST
        TEMPLE VIEW AVENUE
        TEMPLE VIEW CLOSE
        TEMPLE VIEW COPSE
        TEMPLE VIEW COURT
        TEMPLE VIEW CRESCENT
        TEMPLE VIEW DOWNS
        TEMPLE VIEW DRIVE
        TEMPLE VIEW GREEN
        TEMPLE VIEW GROVE
        TEMPLE VIEW LAWN
        TEMPLE VIEW PARK
        TEMPLE VIEW PLACE
        TEMPLE VIEW RISE
        TEMPLE VIEW ROW
        TEMPLE VIEW SQUARE
        TEMPLE VIEW VALE
        TEMPLE VIEW WALK
        TEMPLE VIEW WAY
        TEMPLEMORE AVENUE
        TEMPLEOGUE ROAD
        TERENURE PARK
        TERENURE PLACE
        TERENURE ROAD EAST
        TERENURE ROAD NORTH
        TERENURE ROAD WEST
        THE BELFRY
        THE CLOISTERS
        THE COOMBE
        THE COURT
        THE COURT
        THE CRESCENT
        THE GLEN
        THE GROVE
        THE GROVE
        THE GROVE
        THE HAVEN
        THE HOLE IN THE WALL ROAD
        THE HOLE IN THE WALL ROAD
        THE LAURELS
        THE LAWN
        THE LAWN
        THE LAWNS
        THE MEADOWS
        THE MEWS
        THE OAKS
        THE ORCHARD
        THE PADDOCK
        THE PINES
        THE RISE
        THE RISE
        THE SQUARE
        STILES COURT
        THE SWEEPSTAKES
        THE THATCH ROAD
        THE VILLAGE
        THE WILLOWS
        THIRD AVENUE
        RIALTO COTTAGES-THIRD AVENUE
        THOMAS CLARKE HOUSE
        THOMAS COURT
        THOMAS DAVIS STREET WEST
        THOMAS DAVIS STREET SOUTH
        THOMAS MOORE ROAD
        THOMAS STREET
        THOMAS STREET
        THOMAS STREET
        THOMOND ROAD
        THOMOND ROAD
        THOMPSON COTTAGES
        THOR PLACE
        THORNCASTLE STREET
        THORNCASTLE STREET
        THORNDALE AVENUE
        THORNDALE CRESCENT
        THORNDALE DRIVE
        THORNDALE GROVE
        THORNDALE LAWN
        THORNDALE PARK
        THORNVILLE AVENUE
        THORNVILLE DRIVE
        THORNVILLE PARK
        THORNVILLE ROAD
        TINKERS COURT
        TINKERS COURT
        TIVOLI AVENUE
        TOLKA COTTAGES
        TOLKA ESTATE ROAD
        TOLKA ESTATE ROAD
        TOLKA ESTATE ROAD
        TOLKA ROAD
        TOLKA VALLEY ROAD
        EAST LINK BRIDGE
        TOLL BRIDGE ROAD
        TONGUEFIELD ROAD
        TONLEGEE AVENUE
        TONLEGEE DRIVE
        TONLEGEE ROAD
        TONLEGEE ROAD
        TONLEGEE ROAD
        TONLEGEE ROAD
        TORLOGH GARDENS
        TORLOGH PARADE
        TOURMAKEADY ROAD
        TOWER AVENUE
        TOWER VIEW COTTAGES
        TOWNSEND STREET
        TOWNSEND STREET
        TRAMWAY COTTAGES
        TRANQUILITY GROVE
        TRAYNOR PLACE
        TRIM ROAD
        TRINITY STREET
        TRINITY TERRACE
        TRITONVILLE AVENUE
        TRITONVILLE COURT
        TRITONVILLE CRESCENT
        TRITONVILLE ROAD
        TRITONVILLE ROAD
        TRITONVILLE ROAD
        TUDOR ROAD
        TURVEY AVENUE
        TUSCANY DOWNS
        TYRCONNELL PARK
        TYRCONNELL ROAD
        TYRCONNELL STREET
        TYRRELL PLACE
        ULSTER STREET
        UPPER CROSS ROAD
        USHER STREET
        USHER'S ISLAND
        USHERS LANE
        USHER'S QUAY
        VALENTIA PARADE
        VALENTIA ROAD
        VALEVIEW CRESCENT
        VALEVIEW DRIVE
        VALEVIEW GARDENS
        VALLEY PARK AVENUE
        VALLEY PARK DRIVE
        VALLEY PARK ROAD
        VAUXHALL AVENUE
        VAVASOUR SQUARE
        VENTRY DRIVE
        VENTRY PARK
        VENTRY ROAD
        VERGEMOUNT HALL
        VERGEMOUNT PARK
        VERNON AVENUE
        VERNON AVENUE
        VERNON DRIVE
        VERNON GARDENS
        VERNON GROVE
        VERNON GROVE
        VERNON GROVE
        VERNON GROVE
        VERNON PARK
        VERNON RISE
        VERNON STREET
        VERONICA TERRACE
        VERSCHOYLE COURT
        VERSCHOYLE COURT
        VERSCHOYLE PLACE
        VICAR STREET
        VICTORIA AVENUE
        VICTORIA LANE
        VICTORIA LANE
        VICTORIA QUAY
        VICTORIA ROAD
        VICTORIA ROAD
        VICTORIA ROAD
        VICTORIA STREET
        VICTORIA VILLAGE
        VICTORIA VILLAS
        VICTORIA VILLAS
        VIKING PLACE
        VIKING ROAD
        VILLA PARK AVENUE
        VILLA PARK DRIVE
        VILLA PARK GARDENS
        VILLA PARK ROAD
        VILLIERS ROAD
        SAINT VINCENT STREET SOUTH
        VIOLET HILL DRIVE
        VIOLET HILL PARK
        VIOLET HILL ROAD
        VIRGINIA DRIVE
        VIRGINIA PARK
        VIRGINIA PARK
        WADELAI GREEN
        WADELAI ROAD
        WADE'S AVENUE
        WALKERS COTTAGES
        WALKINSTOWN AVENUE
        WALKINSTOWN CRESCENT
        WALKINSTOWN DRIVE
        WALKINSTOWN GREEN
        WALKINSTOWN PARADE
        WALKINSTOWN PARK
        WALKINSTOWN ROAD
        WALLACE ROAD
        WALNUT AVENUE
        WALNUT COURT
        WALNUT LAWN
        WALNUT PARK
        WALNUT RISE
        WALSH ROAD
        WALWORTH ROAD
        NEW WAPPING STREET
        WARD'S HILL
        WARNER'S LANE
        WARREN STREET
        WARRENMOUNT
        WARRENMOUNT PLACE
        CLONTARF ROAD
        WARRINGTON LANE
        WARRINGTON PLACE
        WASDALE GROVE
        WASDALE PARK
        WASHINGTON STREET
        WATERFALL AVENUE
        WATERFALL ROAD
        WATERLOO AVENUE
        WATERLOO LANE
        WATERLOO ROAD
        WATERMILL AVENUE
        WATERMILL DRIVE
        WATERMILL DRIVE
        WATERMILL DRIVE
        WATERMILL LAWN
        WATERMILL PARK
        WATERMILL ROAD
        WATERMILL ROAD
        WATKIN'S SQUARE
        WATLING STREET
        WAVERLEY AVENUE
        WEAVER LANE
        WEAVERS CLOSE
        WEAVERS SQUARE
        WEAVERS STREET
        WELLESLEY PLACE
        WELLINGTON LANE
        WELLINGTON PLACE
        WELLINGTON PLACE NORTH
        WELLINGTON QUAY
        WELLINGTON ROAD
        WELLINGTON STREET LOWER
        WELLINGTON STREET UPPER
        WELLMOUNT AVENUE
        WELLMOUNT COURT
        WELLMOUNT CRESCENT
        WELLMOUNT DRIVE
        WELLMOUNT GREEN
        WELLMOUNT PARK
        WELLMOUNT ROAD
        WELLMOUNT ROAD
        WELLMOUNT ROAD
        WELLMOUNT ROAD
        WELLPARK AVENUE
        WERBURGH STREET
        WESLEY PLACE
        WESLEY ROAD
        WEST PARK DRIVE
        WEST ROAD
        WEST TERRACE
        WESTBOURNE ROAD
        WESTERN WAY
        WESTFIELD ROAD
        WESTHAMPTON PLACE
        WESTLAND COURT
        WESTLAND ROW
        WESTMORELAND PARK
        WESTMORELAND STREET
        WESTPARK
        WESTWOOD AVENUE
        WESTWOOD ROAD
        WEXFORD STREET
        WHITEFRIAR PLACE
        WHITEFRIAR STREET
        WHITEFRIAR STREET
        WHITE'S LANE
        WHITETHORN AVENUE
        WHITETHORN CLOSE
        WHITETHORN CRESCENT
        WHITETHORN GROVE
        WHITETHORN PARK
        WHITETHORN RISE
        WHITETHORN ROAD
        WHITTON ROAD
        WHITWORTH AVENUE
        WHITWORTH PARADE
        WHITWORTH PLACE
        WHITWORTH ROAD
        WHITWORTH ROAD
        WHITWORTH TERRACE
        WICKLOW LANE
        WICKLOW STREET
        WIGAN ROAD
        WILFIELD
        WILFIELD PARK
        WILFIELD PARK
        WILFIELD ROAD
        WILFIELD ROAD
        WILFRID ROAD
        WILFRID TERRACE
        WILLIAMS LANE
        WILLIAMS PARK
        WILLIAMS PLACE LOWER
        WILLIAMS PLACE SOUTH
        WILLIAMS PLACE SOUTH
        WILLIAMS PLACE UPPER
        WILLIAMS PLACE UPPER
        WILLIAM STREET NORTH
        SOUTH WILLIAM STREET
        WILLOW MEWS
        WILLOW PARK AVENUE
        WILLOW PARK CLOSE
        WILLOW PARK CRESCENT
        WILLOW PARK DRIVE
        WILLOW PARK GROVE
        WILLOW PARK LAWN
        WILLOW PARK ROAD
        WILLOW PARK ROAD
        WILLOW FIELD
        WILSON'S PLACE
        WILSON TERRACE
        WILTON PLACE
        WILTON TERRACE
        WINDELE ROAD
        WINDMILL AVENUE
        WINDMILL LANE
        WINDMILL PARK
        WINDMILL ROAD
        WINDMILL ROAD
        WINDSOR AVENUE
        WINDSOR PLACE
        WINDSOR PLACE
        WINDSOR ROAD
        WINDSOR TERRACE
        WINDSOR VILLAS
        WINETAVERN STREET
        WINTON AVENUE
        WINTON MEWS
        WINTON ROAD
        WOLFE TONE QUAY
        WOLFE TONE QUAY
        WOLFE TONE STREET
        WOLSELEY STREET
        WOOD LANE
        WOOD QUAY
        WOOD STREET
        WOODBANK AVENUE
        WOODBANK DRIVE
        WOODBINE CLOSE
        WOODBINE DRIVE
        WOODBINE PARK
        WOODBINE ROAD
        WOODFIELD AVENUE
        WOODFIELD PLACE
        WOODLAWN AVENUE
        WOODLAWN CLOSE
        WOODLAWN COURT
        WOODLAWN CRESCENT
        WOODLAWN DRIVE
        WOODLAWN GREEN
        WOODLAWN GROVE
        WOODLAWN PARK
        WOODLAWN RISE
        WOODLAWN VIEW
        WOODLAWN WALK
        WOODLAWN WAY
        WOODSIDE
        WOODSTOCK COURT
        WOODSTOCK GARDENS
        WOODVIEW CLOSE
        WOODVIEW PARK
        WOODVILLE COURT
        WOODVILLE ROAD
        WORMWOOD GATE
        WYNNEFIELD ROAD
        WYTELEAF GROVE
        WYTELEAF GROVE
        XAVIER AVENUE
        YARNHALL STREET
        YELLOW ROAD
        YORK AVENUE
        YORK ROAD
        YORK ROAD
        YORK STREET
        YORK STREET
        ZION ROAD
        ZION ROAD
        FINGLAS ROAD
        BALLYMUN ROAD
        GRIFFITH AVENUE
        SAINT MOBHI ROAD
        RATOATH ROAD
        BEECHLAWN WAY
        FAIRWAYS AVENUE
        FAIRWAYS GREEN
        FAIRWAYS GROVE
        FAIRWAYS PARK
        HARCOURT LODGE
        RAVENS COURT
        RANELAGH MEWS
        HADDINGTON LANE
        DOYLES LANE
        VERNON HEATH
        CHAPEL CRESCENT
        CHANCEL MEWS
        ABBEY DRIVE
        CHURCH WALK
        SPIRE VIEW
        RECTORY GREEN
        CLOISTER COURT
        CONVENT WAY
        OLD KILMAINHAM VILLAGE
        BROOKFIELD GREEN
        ROYSTON COURT
        MERCHANT SQUARE
        KENILWORTH MANOR
        REDMOND'S COURT
        BRIARFIELD WALK
        PODDLE GREEN
        SHANDON GREEN
        SHANDON MILL
        THE CRESCENT
        CHESTNUT COURT
        NEWTOWN AVENUE
        NEWTOWN PARK
        NEWTOWN WAY
        NEWTOWN CLOSE
        NEWTOWN ROAD
        KIMMAGE COURT
        BOTANIC VILLAS
        CHURCH VIEW
        CLONSHAUGH COURT
        ELMDALE CLOSE
        INNISMORE
        LEINSTER PARK
        PARK WEST AVENUE
        PODDLE CLOSE
        THE MILLS
        BELLEVILLE
        RIVERVIEW COURT
        LAURENCE BROOK
        THE STEEPLES
        ASHTOWN LODGE
        COOLOCK VILLAGE CLOSE
        SUNBURY PARK
        CONVENT LAWNS
        WALNUT WALK
        CLARE HALL AVENUE
        BOTANIC MEWS
        WINDMILL CRESCENT
        WELLMOUNT PARADE
        VINTAGE COURT
        EASTWOOD
        VERNON WOOD
        SAINT JOHNS COURT
        RAFTER'S AVENUE
        CRUMLIN PARK
        BIGGER LANE
        PODDLE CLOSE
        ABBEY COTTAGES
        CHANEL COURT
        FATHER BIDONE COURT
        ORIEL HALL
        PARK SPRINGS
        NORTHBROOK WALK
        RIVER WALK
        STONE MEWS
        CROMCASTLE CLOSE
        OUR LADY'S CLOSE
        BELVEDERE SQUARE
        ROBINSON'S COURT
        RATHMINES AVENUE COURT
        TENTERFIELDS
        LEICESTER COURT
        CRAMPTON AVENUE
        DALYMOUNT PARK LANE
        CAPPAGH GREEN
        ROSSAVEAL COURT
        ROSSAVEAL COURT
        LORCAN O'TOOLE COURT
        SAINT VINCENTS COURT
        SAINT JOHN'S COURT
        CHARLEMONT LANE
        TOLKA VALE
        SAINT LAURENCE GLEN
        SHEA'S LANE
        MOATVIEW CLOSE
        MOATVIEW TERRACE
        THE PARK
        THE GREEN
        THE CLOSE
        BEAUMONT COURT
        SAINT BRIGID'S CLOSE
        SAINT BRIGID'S GROVE
        SAINT BRIGID'S GREEN
        SAINT BRIGID'S LAWN
        ACCOMMODATION WALK
        ACCOMMODATION WALK
        ACCOMMODATION WALK
        ACCOMMODATION WALK
        ACCOMMODATION WALK
        ACCOMMODATION WALK
        PIGEON HOUSE ROAD
        OAKLEY PARK
        THE BELFRY
        MAYFIELD
        ABBEY COURT
        RICHMOND LODGE
        WALKINSTOWN CLOSE
        ABERCORN SQUARE
        ADELAIDE
        ARRAN QUAY TERRACE
        BALLSBRIDGE WOOD
        BALLYBOGGAN INDUSTRIAL ESTATE
        BAROMA
        BEATTY'S AVENUE
        BEECH HILL COURT
        BEECH HILL CRESCENT
        BEECH HILL TERRACE
        BELCAMP CRESCENT
        BELFIELD COURT
        BOYNE COURT
        BRABAZON ROW
        BROOKLAWN
        CHATHAM LANE
        CHERRY COURT
        CLONSHAUGH INDUSTRIAL ESTATE
        COGGLE'S COURT
        COLLINSWOOD
        CONVENT VIEW COTTAGES
        COW PARLOUR
        CROYDON TERRACE
        EGLINTON COURT
        EGLINTON WOOD
        FAIRFIELD COURT
        FATHER MATHEW BRIDGE
        GRATTAN BRIDGE
        GREENLEA PLACE
        GLENAULIN
        SAINT KEVIN'S COURT
        JERVIS LANE UPPER
        JOSHUA LANE
        KINGSLAND PARK AVENUE
        KIRKWOOD
        KYLE CLARE ROAD
        LAMBOURNE VILLAGE
        KNIGHTS BRIDGE
        LIFFEY STREET UPPER
        MACARTNEY BRIDGE
        MADDEN ROAD
        MADDENS COURT
        MANOR VILLAS
        MARTELLO MEWS
        MARTELLO VIEW
        MELLOWES ROAD
        MILLBROOK VILLAGE
        MUIRFIELD DRIVE
        PRIORY NORTH
        O'DONOVAN ROSSA BRIDGE
        PARK COURT
        PARK VIEW
        PARK VIEW
        PARK VIEW
        PARK WEST ROAD
        PORTOBELLO
        PORTOBELLO SQUARE
        ROYAL CANAL COURT
        SAINT GABRIELS COURT
        SAINT JOHN'S TERRACE
        SAINT LAURENCE GROVE
        SAINT LAURENCE GROVE
        SEABURY
        STEPHEN STREET LOWER
        STELLA AVENUE
        SYDENHAM COURT
        TERRACE PLACE
        THE BEECHES
        THE CLOISTERS
        TOM KELLY ROAD
        VENETIAN HALL
        WILLOW FIELD
        YEWLAND TERRACE
        EMMET COURT
        GRATTAN LODGE
        GRATTAN WOOD
        FINN EBER FORT
        BELCAMP AVENUE
        BELCAMP AVENUE
        WHARTON TERRACE
        NEWCOMEN BRIDGE
        NOEL PURCELL WALK
        THE WINDMILL
        ADAIR COURT
        THE COURTYARD
        THE ORCHARD
        ADELAIDE COURT
        HOWTH ROAD NUMBER 150
        CADOGAN COURT
        COLLINS SQUARE
        BOTANIC SQUARE
        HEATH SQUARE
        MULBERRY LANE
        CHURCH SQUARE
        CLONLIFFE SQUARE
        WINDSOR LANE
        KENNEDY COURT
        CHERRY ORCHARD COURT
        CONVENT AVENUE
        MILLTOWN AVENUE
        MERTON CRESCENT
        MERTON WALK
        PARKGATE PLACE
        DUNBUR
        CLONSHAUGH GLEN
        BELMONT SQUARE
        SOUTH BANK QUAY
        PREMIER SQUARE
        LISSADEL GREEN
        BURN SIDE
        COULTRY COURT
        COULTRY CLOSE
        DERRYNANE SQUARE
        GRACEPARK MANOR
        ROCKMEADE COURT
        FORT OSTMAN
        WOODHAZEL TERRACE
        WOODHAZEL WAY
        WOODHAZEL CLOSE
        LONGDALE TERRACE
        LONGDALE WAY
        BARNVILLE PARK
        KILLAN COURT
        KEARNS COURT
        ALL HALLOWS SQUARE
        ABBEYFIELD LAWNS
        PERCY CLOSE
        ALL SAINTS CLOSE
        RICHMOND LANE
        KNOCKMAREE
        PARK WEST ROAD
        HENRY ROAD
        FRIEL AVENUE
        LE BROCQUY AVENUE
        BANVILLE AVENUE
        REUBEN SQUARE
        ISLAND BRIDGE
        BELLEVUE
        LAUREL PLACE
        BULFIN COURT
        THE COPSE
        GATEWAY VIEW
        GATEWAY AVENUE
        GATEWAY GARDEN
        GATEWAY COURT
        GATEWAY MEWS
        GATEWAY PLACE
        GATEWAY CRESCENT
        BEECHLAWN DRIVE
        SALLOWOOD VIEW
        FORESTWOOD CLOSE
        POPPINTREE PARK LANE WEST
        HOLLYWELL
        SANTRY WAY
        AILESBURY WOOD
        ROSE GLEN MANOR
        BERKELEY TERRACE
        SAINT LUKE'S AVENUE
        KNOCK RIADA
        VERVILLE COURT
        NEWTOWN COURT
        VICTORIA TERRACE
        SUMMERVILLE
        EMMET CRESCENT
        THE GASWORKS
        CLONSHAUGH WOODS
        AILESBURY CLOSE
        DAKOTA COURT
        THORNHILL LANE
        COLLINS CLOSE
        BARNVILLE GREEN
        BARNVILLE WALK
        BUTLER'S PEIR
        SEVEN OAKS
        BRADOGUE COURT
        THE ISLAND
        SIMMONSCOURT
        SIMMONSCOURT SQUARE
        SHEA'S COURT
        MANOR STREET BUSINESS PARK
        NORTHUMBERLAND COURT
        GRANGE ABBEY ROAD
        COW'S LANE
        MAREWOOD CRESCENT
        MAREWOOD DRIVE
        MAREWOOD GROVE
        BARNEWALL DRIVE
        HOLLYTREE SQUARE
        ORCHARD PARK
        CASTLE VIEW
        BELGROVE PARK
        ORCHARD WAY
        ROE LANE
        CLANCARTHY COURT
        BOW BRIDGE PLACE
        ANNESLEY CLOSE
        HOLLYBROOK
        TIMBER MILLS
        THE PADDOCKS
        THE PADDOCKS
        ELLIS COURT
        ROYSTON VILLAGE
        ALONE WALK
        ALONE WALK
        LABRE PARK
        SHREWSBURY
        JAMESTOWN SQUARE
        EATON COURT
        EATON HALL
        CLEARSTREAM COURT
        SANDFORD CLOSE
        LUCKY LANE
        ORWELL WOODS
        MILLENNIUM WALKWAY
        BLOOM'S LANE
        RIVERMOUNT COTTAGES
        HORTON COURT
        ALL HALLOWS GREEN
        KYLEMORE WAY
        KINGSLAND LANE
        WOOD STREET
        WICKLOW LANE
        FORESTWOOD AVENUE
        SANDYHILL COURT
        SANDYHILL WAY
        BEAUMONT WOODS
        LARCH HILL
        THE VIEW
        THE SQUARE
        THE CRESCENT
        THE GREEN
        THE PARK
        PARK VIEW
        HAZEL LANE
        GARVILLE MEWS
        GARVILLE MEWS
        GREENORE COURT
        MILLVIEW COTTAGES
        SAINT HELEN'S TERRACE
        TYRREL'S LANE
        MILLENNIUM BRIDGE
        LIFFEY BRIDGE
        SEAFIELD CLOSE
        CARLTON COURT
        THE GABLES
        CEDAR BROOK
        CEDAR BROOK AVENUE
        CEDAR BROOK PLACE
        CEDAR BROOK WALK
        CEDAR BROOK WAY
        RATHBORNE AVENUE
        RATHBORNE CLOSE
        RATHBORNE COURT
        RATHBORNE DRIVE
        RATHBORNE GROVE
        RATHBORNE PLACE
        RATHBORNE WAY
        BYRNES LANE WEST
        SAINT ANTHONY'S PLACE
        COLLINS COURT
        NEWTOWN COURT WAY
        BELLS LANE
        SOUTH CIRCULAR ROAD
        VERNON COURT
        VERNON COURT
        GARVILLE LANE
        THE COURT
        THE COURT
        THE COURT
        BRIDGE STREET
        GRANGE LODGE AVENUE
        GRANGE LODGE COURT
        BEAU PARK AVENUE
        BEAU PARK CLOSE
        BEAU PARK MEWS
        BEAU PARK CRESCENT
        BEAU PARK ROAD
        BEAU PARK ROW
        BEAU PARK PLACE
        BEAU PARK SQUARE
        BEAU PARK STREET
        BEAU PARK TERRACE
        HOEY CLOSE
        HOEY COURT
        HOEY PLACE
        RAILWAY CLOSE
        RAILWAY COURT
        RAILWAY MEWS
        RAILWAY ROAD
        STATION WAY
        BELMAYNE AVENUE
        BELMAYNE PARK EAST
        BELMAYNE PARK NORTH
        BELMAYNE PARK SOUTH
        BELMAYNE PARK WEST
        CHURCHWELL AVENUE
        CHURCHWELL CLOSE
        CHURCHWELL CRESCENT
        CHURCHWELL DRIVE
        CHURCHWELL GROVE
        CHURCHWELL MEWS
        CHURCHWELL PLACE
        CHURCHWELL RISE
        CHURCHWELL ROAD
        CHURCHWELL SQUARE
        MAIN STREET
        MAIN STREET
        PARKVIEW CLOSE
        PARKVIEW DRIVE
        PARKVIEW GREEN
        PARKVIEW GROVE
        PARKVIEW ROAD
        PARKVIEW SQUARE
        SCRIBBLESTOWN AVENUE
        SCRIBBLESTOWN CLOSE
        SCRIBBLESTOWN GREEN
        SCRIBBLESTOWN GROVE
        SCRIBBLESTOWN PARK
        SCRIBBLESTOWN PLACE
        SCRIBBLESTOWN ROAD
        ROYAL CANAL AVENUE
        GRIFFITH HEIGHTS
        GRIFFITH CRESCENT
        KILSHANE COURT
        KILSHANE DRIVE
        HAZELCROFT TERRACE
        MANOR HOUSE VIEW
        TOLKA VALLEY VIEW
        BERACH LODGE
        SEAPARK
        THE LAURELS
        NEWBURY WOODS
        WILLSBOROUGH APARTMENTS
        SILLOGE CLOSE
        SILLOGE CRESCENT
        SILLOGE GREEN
        SILLOGE PARK
        SILLOGE PLACE
        SILLOGE WAY
        MAREWOOD COURT
        ISLAND VIEW
        ISLAND VIEW COURT
        BEREHAVEN PLACE
        BALCURRIS CLOSE
        BALCURRIS PARK EAST
        BALCURRIS PARK WEST
        SAINT PAPPIN'S STREET
        THE MEWS
        BROOKFIELD
        CHURCH LANE
        HERBERTON ROAD
        MAIN STREET
        HARCOURT LANE
        WOODLANDS
        SAINT PATRICK'S TERRACE
        HAMPTON LODGE
        THE SQUARE
        THOMAS STREET
        SEAN O' CASEY BRIDGE
        SAMUEL BECKETT BRIDGE`.split(/\n/);

        //https://www.wikiwand.com/en/List_of_census_towns_in_the_Republic_of_Ireland#/Table
        var towns =
        `Dublin
        Cork
        Limerick
        Galway
        Waterford
        Drogheda
        Wexford
        Sligo
        Clonmel
        Kilkenny
        Dundalk
        Bray
        Navan (An Uaimh)
        Ennis
        Tralee
        Carlow
        Naas
        Athlone
        Letterkenny
        Tullamore
        Killarney
        Arklow
        Cobh
        Castlebar
        Midleton
        Mallow
        Ballina
        Enniscorthy
        Wicklow
        Cavan
        Athy
        Longford
        Dungarvan
        Nenagh
        Trim
        New Ross
        Thurles
        Youghal
        Monaghan
        Buncrana
        Ballinasloe
        Fermoy
        Westport
        Carrick-on-Suir
        Kells (Ceannanus Mór)
        Birr
        Tipperary
        Carrickmacross
        Kinsale
        Listowel
        Clonakilty
        Cashel
        Macroom
        Castleblayney
        Kilrush
        Skibbereen
        Bundoran
        Templemore
        Clones
        Newbridge (Droichead Nua)
        Port Laoise (Portlaoise)
        Mullingar
        Greystones
        Balbriggan
        Leixlip
        Tramore
        Shannon
        Gorey
        Tuam
        Edenderry
        Bandon
        Passage West
        Loughrea
        Ardee
        Mountmellick
        Bantry
        Muine Bheag (Muinebeag, Bagenalstown)
        Boyle
        Ballyshannon
        Cootehill
        Ballybay
        Belturbet
        Lismore
        Kilkee
        Granard
        Swords
        Celbridge
        Malahide
        Maynooth
        Skerries
        Rush
        Kildare
        Portarlington
        Roscrea
        Ballybofey–Stranorlar
        Carrick-on-Shannon
        Tullow
        Athenry
        Monasterevin (Monasterevan)
        Mitchelstown
        Charleville (Rathluirc)
        Cahir
        Claremorris
        Clara
        Moate
        Ballinrobe
        Gort
        Donegal
        Carndonagh
        Bailieborough
        Castleisland
        Blarney
        Ballyhaunis
        Thomastown
        Kanturk
        Kenmare
        Killorglin
        Clifden
        Abbeyfeale
        Castlerea
        Dingle (An Daingean)
        Abbeyleix
        Ballaghaderreen
        Portlaw
        Mountrath
        Banagher
        Kilmallock
        Rathdrum
        Dunmanway
        Millstreet
        Graiguenamanagh–Tinnahinch (Graignamanagh)
        Moville
        Castlecomer–Donaguile
        Swinford (Swineford)
        Ballybunion
        Killybegs
        Cahersiveen (Caherciveen, Cahirciveen, Cahirsiveen)
        Ennistymon
        Carrigaline
        Ashbourne
        Laytown–Bettystown–Mornington
        Portmarnock
        Ratoath
        Lusk
        Dunboyne
        Donabate
        Clane
        Newcastle West
        Kinsealy–Drinan
        Roscommon
        Kilcock (Killcock)
        Sallins
        Blessington
        Oranmore
        Carrigtwohill (Carrigtohill)
        Kilcoole
        Duleek
        Dunshaughlin
        Kilcullen
        Rathcoole
        Tower
        Stamullen
        Kill
        Rathnew
        Enfield
        Courtown Harbour (Courtown, Ballinatray)
        Annacotty
        Kinnegad
        Newcastle
        Ballyjamesduff
        Sixmilebridge
        Ballina
        Newtownmountkennedy
        Athboy
        Rathangan
        Callan
        Kingscourt
        Virginia
        Prosperous
        Saggart
        Crosshaven
        Baltinglass
        Bunclody–Carrickduff
        Clogherhead
        Castleconnell
        Bearna
        Balrothery
        Enniskerry
        Newport
        Dunleer
        Newmarket-on-Fergus
        Tubbercurry (Tobercurry)
        Edgeworthstown (Meathas Truim, Mostrim)
        Ballivor
        Castlebridge
        Lifford
        Strandhill (Larass)
        Ballymahon
        Cloyne
        Dunmore East
        Moycullen (Maigh Cuilinn)
        Bunbeg–Derrybeg (An Bun Beag–Doirí Beaga)
        Rathkeale
        Rosslare Strand (Rosslare)
        Derrinturn
        Fethard
        Ballymote
        Rathcormac
        Portumna
        Rochfortbridge
        Ashford
        Termonfeckin
        Convoy
        Ardnacrusha (Castlebank)
        Castledermot
        Oldcastle
        Longwood
        Lanesborough–Ballyleague
        Portrane
        Collooney (Coloony)
        Aughrim
        Ferns
        Tullyallen
        Slane
        Ballisodare
        Manorhamilton
        Oughterard
        Foxford
        Killaloe
        Kilpedder
        Caherconlish
        Castlemartyr
        Muff
        Murroe (Moroe)
        Killucan and Rathwire
        Enniscrone (Inniscrone, Inishcrone)
        Claregalway (Baile Chláir)
        Ramelton
        Rathdowney (Rathdowny)
        Kilbeggan
        Piltown
        Dungloe (An Clochán Liath)
        Mooncoin
        Ferbane
        Watergrasshill
        Croom
        Raphoe
        Stradbally
        Askeaton
        Mullagh
        Kiltimagh
        Rosslare Harbour (or Ballygeary)
        Dromiskin
        Adare
        Kentstown
        Ballinroad
        Carnew
        Ballyragget
        Belmullet (Béal an Mhuirthead)
        Ballylinan
        Newtown Cunningham (Newtowncunningham)
        Whitegate
        Ballyconnell
        Crossmolina
        Killumney (Killumny)
        Carlingford
        Castlepollard
        Daingean (Philipstown)
        Castlebellingham–Kilsaran
        Kilmacanogue (Kilmacanoge)
        Kinlough
        Athgarvan
        Aghada–Farsid–Rostellan
        Johnstown
        Kilmeague (Kilmeage)
        Newmarket
        Kilworth
        Urlingford
        Milford
        Tinahely
        Borrisokane
        Tallow
        Newcastle
        Ardfinnan
        Buttevant
        Quin
        Mohill
        Charlestown–Bellahy
        Castletownbere
        Fountainstown
        Ballinamore
        Headford
        Caragh (Carragh)
        Rathvilly
        Ballymore Eustace
        Dromahane (Drommahane)
        Kilmacthomas (Kilmactomas)
        Kilcormac (Frankford)
        Glenties
        Coolaney
        Falcarragh (An Fál Carrach)
        Drumshanbo
        Brownstown
        Allenwood
        Durrow
        Patrickswell
        Milltown
        Drumlish
        Roundwood
        Summerhill
        Dunlavin
        Leighlinbridge
        Rosses Point
        Greencastle
        Scarriff (Scariff)
        Carraroe (An Cheathrú Rua)
        Collon
        Strokestown
        Knock
        Mucklagh
        Kilsheelan
        Ballyclerahan
        Passage East
        Ardfert
        Paulstown
        Castlefin
        Mountbellew (Mount Bellew)
        Bruff
        Kilfinane
        Rathmore
        Rhode
        Milltown Malbay (Miltown Malbay)
        Innishannon (Inishannon)
        Ballinagh
        Belgooly
        Moneenroe
        Cappoquin
        Newtownforbes
        Doneraile
        Avoca
        Dromahair
        Gowran
        Lisdoonvarna
        Suncroft
        Ardara
        Bennettsbridge
        Killeagh
        Louth
        Holycross
        Killenaule
        Borrisoleigh
        Ballineen and Enniskean
        Delvin
        Emyvale
        Coill Dubh (Blackwood)
        Donore
        Corofin
        Ballytore
        Freshford
        Kilmacrennan (Kilmacrennan)
        Ballon
        Cappamore
        Cratloe
        Tallanstown
        Balla
        Glenealy
        Loughshinny
        Robertstown
        Craughwell
        Pallaskenry
        Kildalkey (Kildalky)
        Tulla
        Ballygar
        Schull (Skull)
        Kilmurry
        Johnstownbridge
        Calverstown
        Ballycannan
        Borris
        Manorcunningham (Manor)
        Lahinch
        Straffan
        Clonmellon
        Lixnaw
        Shinrone
        Carlanstown
        Clonee (Clonee Village)
        Hospital
        Ballyheigue
        Clonlara (Cloonlara)
        Kilmacow (Killmacow)
        Taghmon
        Killenard
        Ballyhaise
        Kinvara
        Julianstown–Whitecross
        Newport
        Elphin
        Cloghan
        Killygordon (Killygordan)
        Hacketstown
        Kilrane
        Riverstick
        Pallasgreen (Pallas Grean)
        Kilmessan
        Knockbridge
        St Johnston
        Keel–Dooagh
        Kildrum
        Grange
        Dunmore
        Glin
        Killala
        Whitechurch
        Fahan
        Grenagh
        Aherla (Rathard)
        Piercetown (Piercestown)
        Tarbert
        Corofin (Corrofin)
        Dromcolliher (Drumcollogher)
        Two-Mile Borris (Twomileborris)
        Glanworth
        Rivermeade
        Foynes
        Bruree
        Ballygarvan
        Rosscarbery (Roscarbery)
        Ballyduff
        Shercock
        Ballingarry
        Fenit
        Roosky (Rooskey)
        Courtmacsherry
        Kilkishen
        Clonaslee
        Rathmullan (Rathmullen)
        Cloughjordan (Cloghjordan)
        Churchtown
        Doon
        Tyrrellspass
        Lackaghbeg (Lackagh, Lacagh)
        Moylough
        Omeath
        Ballycanew
        Glenamaddy
        Gormanston
        Ring (An Rinn)
        Carrignavar
        Slieverue (Slieveroe)
        Keenagh (Kenagh)
        Bridgend (Bridge End)
        Clogheen
        Firies (*Fieries*)
        Leitrim
        Cliffoney
        Mullinahone
        Ballyoulster
        Ringaskiddy (Loughbeg)
        The Ballagh
        Ballycotton
        Borris-in-Ossory
        Bellanode
        Johnstown
        Clonmany
        Conna
        Drimoleague
        Mountcharles
        Portroe
        Crusheen
        Burnfoot
        Grahormac
        Waterville–Spunkane
        Ballymurn
        Ballyliffin
        Barntown
        Spa
        Coolagary
        Tinure
        Ballyroan
        Glen
        Oldtown
        Ladytown
        Naul
        Ballincar
        Knockglass
        Meenlaragh (Mín Lárach)
        Gweedore (Bun na Leaca)
        Ardmore
        Ballinakill
        Castletownroche
        Ballymore
        Garristown
        Dromod (Drumod)
        Coachford
        Kilmihil (Kilmihill)
        Ballymakeera (Baile Mhic Íre)
        Clonbulloge (Clonbullogue)
        Louisburgh
        Ballinagar
        Frenchpark
        Stradbally
        Ballylongford
        Bweeng
        Castletown
        Shrule
        Tinryland (Tinriland)
        Crocknamurleog (Cnoc na Muirleog)
        Shanagarry
        Abbeydorney
        Ballyhooly
        Campile
        Creeslough
        Littleton
        Kildimo
        Kilberry
        Newtown
        Moyvane (Newtownsandes)
        Kilmore Quay
        Camolin
        Ballinabrannagh
        Clarinbridge
        Nurney
        Carrowkeel
        Athea
        Bridgetown
        Oylegate (Oilgate)
        Carrigallen
        Fennagh
        Kilnaleck
        O'Brien's Bridge–Montpelier (O'Briensbridge)
        Cloonboo (Cluain Bú)
        Arvagh (Arva)
        Kildysart (Killadysert)
        Multyfarnham (Multyfarnam)
        Dunkineely
        Geashill
        Riverstown
        Saleen
        Timoleague
        Kilkelly
        Coolgreany
        Drumconrath (Drumcondra)
        Scotstown
        Cappawhite
        Kilcummin
        Fiddown
        Milltown
        Killeshandra (Killashandra)
        Balbradagh
        Murrintown (Murntown)
        Smithborough (Smithboro)
        Goresbridge
        Kinnitty
        Clogh–Chatsworth
        Nobber
        Lawcus
        Crossbarry
        Ballyboghil
        Ranafast (Rann na Feirste, Rannafast, Rinnafarset)
        Palatine
        Tievebane
        Ballindine
        Cloughduv (Cloghduff)
        Bansha
        Carney
        Gorteen (Gurteen)
        Emly (Emlybeg)
        Glaslough (Glasslough)
        Baltimore
        Dripsey (Model Village)
        Narraghmore
        Aglish
        Knockraha
        Shillelagh
        Laragh
        Clonard
        Loch an Iúir (Loughanure)
        Shanbally
        Carrigans
        Collinstown
        Farran
        Killimor
        Cheekpoint
        Durrus
        Ballysax
        Boherbue
        Clondulane
        Ballybrittas
        Ballylanders
        Newbliss
        Clonroche
        Duncannon
        Newcastle
        Mogeely
        Banteer
        Burtonport (Ailt an Chorráin)
        Jenkinstown
        Templetuohy
        Churchbay
        Ballygawley
        Fethard-on-Sea
        Ballintogher
        Ballyporeen
        Dunfanaghy
        Kilmainham
        Ballysimon
        Oola
        Toomevara (Toomyvara)
        Moneygall
        Rockcorry
        Ballinalee
        Furbo (Furbogh, Na Forbacha)
        Lissycasey
        Knockcroghery
        Danescastle
        Gortnahoe (Gortnahoo)
        Rathtoe
        Myshall
        Ballinaclash
        Kildorrery
        Ballinlough
        Annascaul
        Kildangan
        Kilmeade
        Fedamore
        Rathmolyon
        Ardskeagh
        Kilronan (Cill Rónáin)
        Monivea
        Newtown
        Broadford
        Rosscahill
        Shanagolden
        Ballingarry
        Bangor Erris
        Castle Ellis
        Castlelyons
        Kilmurry
        Ardagh
        Silvermines
        Ballynacargy
        Mungret
        Ballycullane
        Cloonfad
        Crookstown
        Glenbeigh (Glenbei)
        Butlersbridge
        Carrick (An Charraig)
        Woodford
        Kells
        Kill
        Manor Kilbride
        Clongeen
        Villierstown
        Clarina
        Puckane (Puckaun)
        Doonbeg
        Turlough
        Ballydehob
        Dromina
        Golden
        Glencullen
        Inniskeen (Inishkeen)
        Knocklong
        Ballyclogh
        Causeway
        Culdaff
        Eyrecourt
        Kilcloon
        Ballyhogue
        Inistioge
        Mullinavat
        Adamstown
        Ballyvaughan
        Sneem
        Killavullen
        Oulart
        Gneeveguilla (Gneevgullia)
        Annagry (Anagaire)
        Clashmore
        Drumkeeran
        Union Hall (Unionhall)
        Milford
        Pollagh (Pullough)
        Spiddal (An Spidéal)
        Kilcar (Cill Charthaigh)
        Drumsna
        Castlemagner
        Newtown
        Clonegal (Clonegall)
        Easky
        Emo
        Roundstone
        Baylin
        Castlegregory
        Mulranny
        Athleague
        Redcross
        Leap
        Pettigo(–Tullyhommon[n 7])
        Ballingeary (Béal Átha an Ghaorthaidh)
        Galbally
        Annaghdown
        Ballycastle
        Barndarrig
        Liscarroll
        Blacklion
        Beaufort
        Carrigart (Carraig Airt)
        Tullaghan
        Quigley's Point (*Quigleys Point*)
        Raharney (Raharny)
        Kilmoganny
        Kilteel
        Belcarra
        Croagh
        Beaulieu
        Kernanstown
        Dundrum
        Kilfenora
        Ballycumber
        Bunratty
        Dromore West
        Killinierin
        Stratford
        Mountcollins
        Grangemore
        Knightstown
        Kilteely
        Kinsaley
        The Swan
        Glencolmcille (Glencolumbkille, Gleann Cholm Cille)
        Swanlinbar
        Brosna
        Ballintra
        Belmont
        Bracknagh
        Duagh
        Dunhill
        Gleneely
        Killashee
        Ballyhack
        Ballydesmond
        Lemybrien
        Shannonbridge
        Ahascragh
        Ballyfarnan
        Monard
        Inagh
        Loughglynn (Loughglinn)
        Bridebridge
        Bree
        Halfway
        Knocknagree
        Legan
        Milltown
        Glassan
        Rathcoole
        Dunderrow
        Gortahork (Gort an Choirce)
        Killeigh
        Laghey (Laghy)
        Errill (Erril)
        Kilbrittain (Killbrittain)
        Tulsk
        Ballinspittle
        Kildavin
        Kilmeaden
        Letterfrack
        Ballyroe
        Ballyagran
        Clonygowan
        Ballinameen
        Clondrohid
        Clontuskert
        Castlemaine
        Castletownshend (Castletownsend)
        Donard
        Keadue (Keadew)
        Lisronagh
        Dunderry
        Bonniconlon (Bunnyconnelan West)
        Newbawn
        Kilgarvan
        Quilty
        Annagassan
        Carrigkerry
        Crossakeel
        Cong
        Reardnogy (Rearcross)
        Whitegate
        Kilbrin
        Ballyforan
        Brittas
        Ballyhahill
        Bohola
        Rosegreen
        Clontibret
        Kilmaine (Kilmain)
        Killurin
        Lough Gowna
        Bellavary
        Inchigeelagh
        Shanballymore
        Threemilehouse (Three Mile House, Cabragh)
        Lahardane
        Williamstown
        Ballynonty
        Mountshannon
        The Commons
        Tournafulla (*Toornafulla*)
        Drumkeen
        Castletown Geoghegan
        Aughnacliffe
        Donaskeigh
        Ballynoe
        Maddenstown
        Oram
        Coolboy
        Knocktopher
        Bellanagare
        Knockananna
        Kilmyshall
        Ballycolla
        Ballinalack
        Ballintober
        Ballyhale
        Drangan
        Arthurstown
        Lyre
        Ballymacarbry
        Liscannor
        Ballymacoda
        Mullaghmore
        Kilflynn
        Ballyedmond
        Cromane
        Dromineer
        Feakle
        Portmagee
        Malin
        Baltray
        Kilcrohane
        Balreask
        Coonagh`.split(/\n/);

        var corecounties =
        `Dublin
        Cork
        Limerick
        Galway
        Waterford
        Louth
        Wexford
        Sligo
        Tipperary
        Kilkenny
        Louth
        Wicklow
        Meath
        Clare
        Kerry
        Carlow
        Kildare
        Westmeath
        Donegal
        Offaly
        Kerry
        Wicklow
        Cork
        Mayo
        Cork
        Cork
        Mayo
        Wexford
        Wicklow
        Cavan
        Kildare
        Longford
        Waterford
        Tipperary
        Meath
        Wexford
        Tipperary
        Cork
        Monaghan
        Donegal
        Galway
        Cork
        Mayo
        Tipperary
        Meath
        Offaly
        Tipperary
        Monaghan
        Cork
        Kerry
        Cork
        Tipperary
        Cork
        Monaghan
        Clare
        Cork
        Donegal
        Tipperary
        Monaghan
        Kildare
        Laois
        Westmeath
        Wicklow
        Dublin (Fingal)
        Kildare
        Waterford
        Clare
        Wexford
        Galway
        Offaly
        Cork
        Cork
        Galway
        Louth
        Laois
        Cork
        Carlow
        Roscommon
        Donegal
        Cavan
        Monaghan
        Cavan
        Waterford
        Clare
        Longford
        Dublin (Fingal)
        Kildare
        Dublin (Fingal)
        Kildare
        Dublin (Fingal)
        Dublin (Fingal)
        Kildare
        Laois
        Tipperary
        Donegal
        Leitrim
        Carlow
        Galway
        Kildare
        Cork
        Cork
        Tipperary
        Mayo
        Offaly
        Westmeath
        Mayo
        Galway
        Donegal
        Donegal
        Cavan
        Kerry
        Cork
        Mayo
        Kilkenny
        Cork
        Kerry
        Kerry
        Galway
        Limerick
        Roscommon
        Kerry
        Laois
        Roscommon
        Waterford
        Laois
        Offaly
        Limerick
        Wicklow
        Cork
        Cork
        Kilkenny
        Donegal
        Kilkenny
        Mayo
        Kerry
        Donegal
        Kerry
        Clare
        Cork
        Meath
        Meath
        Dublin (Fingal)
        Meath
        Dublin (Fingal)
        Meath
        Dublin (Fingal)
        Kildare
        Limerick
        Dublin (Fingal)
        Roscommon
        Kildare
        Kildare
        Wicklow
        Galway
        Cork
        Wicklow
        Meath
        Meath
        Kildare
        Dublin (South Dublin)
        Cork
        Meath
        Kildare
        Wicklow
        Meath
        Wexford
        Limerick
        Westmeath
        Dublin (South Dublin)
        Cavan
        Clare
        Tipperary
        Wicklow
        Meath
        Kildare
        Kilkenny
        Cavan
        Cavan
        Kildare
        Dublin (South Dublin)
        Cork
        Wicklow
        Wexford
        Louth
        Limerick
        Galway
        Dublin (Fingal)
        Wicklow
        Tipperary
        Louth
        Clare
        Sligo
        Longford
        Meath
        Wexford
        Donegal
        Sligo
        Longford
        Cork
        Waterford
        Galway
        Donegal
        Limerick
        Wexford
        Kildare
        Tipperary
        Sligo
        Cork
        Galway
        Westmeath
        Wicklow
        Louth
        Donegal
        Clare
        Kildare
        Meath
        Meath
        Longford
        Dublin (Fingal)
        Sligo
        Wicklow
        Wexford
        Louth
        Meath
        Sligo
        Leitrim
        Galway
        Mayo
        Clare
        Wicklow
        Limerick
        Cork
        Donegal
        Limerick
        Westmeath
        Sligo
        Galway
        Donegal
        Laois
        Westmeath
        Kilkenny
        Donegal
        Kilkenny
        Offaly
        Cork
        Limerick
        Donegal
        Laois
        Limerick
        Cavan
        Mayo
        Wexford
        Louth
        Limerick
        Meath
        Waterford
        Wicklow
        Kilkenny
        Mayo
        Laois
        Donegal
        Cork
        Cavan
        Mayo
        Cork
        Louth
        Westmeath
        Offaly
        Louth
        Wicklow
        Leitrim
        Kildare
        Cork
        Kildare
        Kildare
        Cork
        Cork
        Kilkenny
        Donegal
        Wicklow
        Tipperary
        Waterford
        Wicklow
        Tipperary
        Cork
        Clare
        Leitrim
        Mayo
        Cork
        Cork
        Leitrim
        Galway
        Kildare
        Carlow
        Kildare
        Cork
        Waterford
        Offaly
        Donegal
        Sligo
        Donegal
        Leitrim
        Kildare
        Kildare
        Laois
        Limerick
        Kerry
        Longford
        Wicklow
        Meath
        Wicklow
        Carlow
        Sligo
        Donegal
        Clare
        Galway
        Louth
        Roscommon
        Mayo
        Offaly
        Tipperary
        Tipperary
        Waterford
        Kerry
        Kilkenny
        Donegal
        Galway
        Limerick
        Limerick
        Kerry
        Offaly
        Clare
        Cork
        Cavan
        Cork
        Kilkenny
        Waterford
        Longford
        Cork
        Wicklow
        Leitrim
        Kilkenny
        Clare
        Kildare
        Donegal
        Kilkenny
        Cork
        Louth
        Tipperary
        Tipperary
        Tipperary
        Cork
        Westmeath
        Monaghan
        Kildare
        Meath
        Clare
        Kildare
        Kilkenny
        Donegal
        Carlow
        Limerick
        Clare
        Louth
        Mayo
        Wicklow
        Dublin (Fingal)
        Kildare
        Galway
        Limerick
        Meath
        Clare
        Galway
        Cork
        Wexford
        Kildare
        Kildare
        Clare
        Carlow
        Donegal
        Clare
        Kildare
        Westmeath
        Kerry
        Offaly
        Meath
        Meath
        Limerick
        Kerry
        Clare
        Kilkenny
        Wexford
        Laois
        Cavan
        Galway
        Meath
        Mayo
        Roscommon
        Offaly
        Donegal
        Carlow
        Wexford
        Cork
        Limerick
        Meath
        Louth
        Donegal
        Mayo
        Donegal
        Sligo
        Galway
        Limerick
        Mayo
        Cork
        Donegal
        Cork
        Cork
        Wexford
        Kerry
        Galway
        Limerick
        Tipperary
        Cork
        Dublin (Fingal)
        Limerick
        Limerick
        Cork
        Cork
        Kerry
        Cavan
        Limerick
        Kerry
        Roscommon
        Cork
        Clare
        Laois
        Donegal
        Tipperary
        Cork
        Limerick
        Westmeath
        Galway
        Galway
        Louth
        Wexford
        Galway
        Meath
        Waterford
        Cork
        Kilkenny
        Longford
        Donegal
        Tipperary
        Kerry
        Leitrim
        Sligo
        Tipperary
        Kildare
        Cork
        Wexford
        Cork
        Laois
        Monaghan
        Kilkenny
        Donegal
        Cork
        Cork
        Donegal
        Tipperary
        Clare
        Donegal
        Wexford
        Kerry
        Wexford
        Donegal
        Wexford
        Kerry
        Offaly
        Louth
        Laois
        Limerick
        Dublin (Fingal)
        Kildare
        Dublin (Fingal)
        Sligo
        Cork
        Donegal
        Donegal
        Waterford
        Laois
        Cork
        Westmeath
        Dublin (Fingal)
        Leitrim
        Cork
        Clare
        Cork
        Offaly
        Mayo
        Offaly
        Roscommon
        Waterford
        Kerry
        Cork
        Laois
        Mayo
        Carlow
        Donegal
        Cork
        Kerry
        Cork
        Wexford
        Donegal
        Tipperary
        Limerick
        Kildare
        Cork
        Kerry
        Wexford
        Wexford
        Carlow
        Galway
        Kildare
        Donegal
        Limerick
        Wexford
        Wexford
        Leitrim
        Carlow
        Cavan
        Clare
        Galway
        Cavan
        Clare
        Westmeath
        Donegal
        Offaly
        Sligo
        Cork
        Cork
        Mayo
        Wexford
        Meath
        Monaghan
        Tipperary
        Kerry
        Kilkenny
        Kildare
        Cavan
        Meath
        Wexford
        Monaghan
        Kilkenny
        Offaly
        Kilkenny
        Meath
        Kilkenny
        Cork
        Dublin (Fingal)
        Donegal
        Carlow
        Donegal
        Mayo
        Cork
        Tipperary
        Sligo
        Sligo
        Tipperary
        Monaghan
        Cork
        Cork
        Kildare
        Waterford
        Cork
        Wicklow
        Wicklow
        Meath
        Donegal
        Cork
        Donegal
        Westmeath
        Cork
        Galway
        Waterford
        Cork
        Kildare
        Cork
        Cork
        Laois
        Limerick
        Monaghan
        Wexford
        Wexford
        Tipperary
        Cork
        Cork
        Donegal
        Louth
        Tipperary
        Cork
        Sligo
        Wexford
        Sligo
        Tipperary
        Donegal
        Meath
        Wexford
        Limerick
        Tipperary
        Offaly
        Monaghan
        Longford
        Galway
        Clare
        Roscommon
        Wexford
        Tipperary
        Carlow
        Carlow
        Wicklow
        Cork
        Roscommon
        Kerry
        Kildare
        Kildare
        Limerick
        Meath
        Clare
        Galway
        Galway
        Tipperary
        Limerick
        Galway
        Limerick
        Tipperary
        Mayo
        Wexford
        Cork
        Clare
        Limerick
        Tipperary
        Westmeath
        Limerick
        Wexford
        Roscommon
        Cork
        Kerry
        Cavan
        Donegal
        Galway
        Kilkenny
        Waterford
        Wicklow
        Wexford
        Waterford
        Limerick
        Tipperary
        Clare
        Mayo
        Cork
        Cork
        Tipperary
        Dublin (Dún Laoghaire–Rathdown)
        Monaghan
        Limerick
        Cork
        Kerry
        Donegal
        Galway
        Meath
        Wexford
        Kilkenny
        Kilkenny
        Wexford
        Clare
        Kerry
        Cork
        Wexford
        Kerry
        Donegal
        Waterford
        Leitrim
        Cork
        Cork
        Offaly
        Galway
        Donegal
        Leitrim
        Cork
        Laois
        Carlow
        Sligo
        Laois
        Galway
        Westmeath
        Kerry
        Mayo
        Roscommon
        Wicklow
        Cork
        Donegal
        Cork
        Limerick
        Galway
        Mayo
        Wicklow
        Cork
        Cavan
        Kerry
        Donegal
        Leitrim
        Donegal
        Westmeath
        Kilkenny
        Kildare
        Mayo
        Limerick
        Louth
        Carlow
        Tipperary
        Clare
        Offaly
        Clare
        Sligo
        Wexford
        Wicklow
        Limerick
        Kildare
        Kerry
        Limerick
        Dublin (Fingal)
        Laois
        Donegal
        Cavan
        Kerry
        Donegal
        Offaly
        Offaly
        Kerry
        Waterford
        Donegal
        Longford
        Wexford
        Cork
        Waterford
        Offaly
        Galway
        Roscommon
        Tipperary
        Clare
        Roscommon
        Cork
        Wexford
        Cork
        Cork
        Longford
        Galway
        Westmeath
        Cork
        Cork
        Donegal
        Offaly
        Donegal
        Laois
        Cork
        Roscommon
        Cork
        Carlow
        Waterford
        Galway
        Kildare
        Limerick
        Offaly
        Roscommon
        Cork
        Roscommon
        Kerry
        Cork
        Wicklow
        Roscommon
        Tipperary
        Meath
        Mayo
        Wexford
        Kerry
        Clare
        Louth
        Limerick
        Meath
        Mayo
        Tipperary
        Clare
        Cork
        Roscommon
        Dublin (South Dublin)
        Limerick
        Mayo
        Tipperary
        Monaghan
        Mayo
        Offaly
        Cavan
        Mayo
        Cork
        Cork
        Monaghan
        Mayo
        Galway
        Tipperary
        Clare
        Tipperary
        Limerick
        Donegal
        Westmeath
        Longford
        Tipperary
        Cork
        Kildare
        Monaghan
        Wicklow
        Kilkenny
        Roscommon
        Wicklow
        Wexford
        Laois
        Westmeath
        Roscommon
        Kilkenny
        Tipperary
        Wexford
        Cork
        Waterford
        Clare
        Cork
        Sligo
        Kerry
        Wexford
        Kerry
        Tipperary
        Clare
        Kerry
        Donegal
        Louth
        Cork
        Meath
        Limerick`.split(/\n/);

        var addLine2 =
        `The River
        The Place
        The Sea
        The Road
        The Avenue
        The Forest
        The Square
        The Lake
        The Woods
        The Beach
        The Park
        The Farm
        The Waterfall
        The Pond
        The Garden`.split(/\n/);

        var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

        function genLetter(){
            var lettersLength = letters.length;
            return letters.charAt(Math.floor(Math.random() * lettersLength));
        }
        function genNumber(){
            return Math.floor(Math.random() * 10);
        }
        // merge boys and girls names-remove duplication
        // maybe could have used (must check!):
        // = Array.from(new Set(bNames.concat(...gNames)))
        var fNames = [...new Set([...bNames, ...gNames])];

        // set up protytype for random selection from array
        Array.prototype.sample = function () {
            return this[Math.floor(Math.random() * this.length)];
        }

        // set up array shuffle using Fisher-Yates method
        Array.prototype.shuffle = function () {
            var i = this.length, j, temp;
            if (i == 0) return this;
            while (--i) {
                j = Math.floor(Math.random() * (i + 1));
                temp = this[i];
                this[i] = this[j];
                this[j] = temp;
            }
            return this;
        }

        // various fenctions to generate random data
        module.exports = {
            getRandomName: function() {
                return fNames.sample().trim() + " " + sNames.sample().trim();
            },
            getTitle: function(){
                return titles.sample().trim();
            },
            getFirstName: function(){
                return fNames.sample().trim();
            },
            getLastName: function(){
                return sNames.sample().trim();
            },
            getEmail: function(){
                return emails.sample().trim();
            },
            getMobile: function(){
                var mobile = "";
                for(var i = 0; i < 10; i++)
                {
                    mobile = mobile + Math.floor(Math.random() * 10);
                }
                return mobile;
            },
            getStreet: function(){
                var streetNo = Math.floor(Math.random() * 10000);
                return streetNo + " " + streets.sample().trim();
            },
            getTownandCounty: function(){
                var countytownIndex = Math.floor(Math.random() * towns.length);
                return towns[countytownIndex].trim() + "/" + corecounties[countytownIndex].trim();
            },
            getaddLine2: function(){
                return addLine2.sample().trim();
            },
            getEircode: function(){
                return genLetter() + genNumber() + genNumber() + " " + genLetter() + genLetter() + genNumber() + genNumber();
            },
        };
        
        // shuffle the boys and girls names (and surnames ... sure why not!)
        fNames.shuffle(); sNames.shuffle();

        //export { getRandomName };