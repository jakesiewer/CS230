module.exports = {
    database: {
        url: "mongodb+srv://adminUser:Irelandtoamerica@cluster0.7auld.mongodb.net/test?retryWrites=true&w=majority"
    }
}