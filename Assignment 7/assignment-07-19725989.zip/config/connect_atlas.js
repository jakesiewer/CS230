module.exports = {
    database: {
        url: "mongodb+srv://adminUser:Irelandtoamerica@cluster0.7auld.mongodb.net/Assignment7?retryWrites=true&w=majority"
    }
}